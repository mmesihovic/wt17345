// admin se loguje sa Adna a password je tucak


const express = require ('express');
const bodyParser= require('body-parser');
const fs= require('fs');
const app= express();


const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const sequelize = require('./public/baza.js');
const Korisnik = sequelize.import(__dirname+"/public/korisnikModel.js");
const Rola = sequelize.import(__dirname+"/public/role.js");
const Podaci = sequelize.import(__dirname+"/public/podaci.js");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use("/", express.static('public'));

const bcrypt = require('bcrypt-nodejs');
const salt = 10;
const greska = 'Neovlasten pristup';

// var sifra = bcrypt.hash("tucak",null,null,function(err,hash){
//     //console.log(hash);
//     //console.log("sifra");
// })

const session = require("express-session");
app.use(session({
    secret: 'adna',
    resave: true,
    saveUninitialized: true
 }));
 

Rola.sync().then(function()
{
    Rola.findOrCreate({where: {id: 1}, defaults: {naziv: 'Admin'}});
    Rola.findOrCreate({where: {id: 2}, defaults: {naziv: 'Student'}});
    Rola.findOrCreate({where: {id: 3}, defaults: {naziv: 'Nastavnik'}});
    Podaci.sync();
    Korisnik.sync().then(function()
    {
        bcrypt.hash('tucak', null,null,function(err,hash) {
            Korisnik.findOrCreate({where: {ID: '1'}, defaults: {username: 'Adna', password: hash.toString(), RolaId: 1}}); 
            Korisnik.findOrCreate({where: {ID: '2'}, defaults: {username: 'Ajna', password: hash.toString(), RolaId: 2}}); 
            Korisnik.findOrCreate({where: {ID: '3'}, defaults: {username: 'Jen', password: hash.toString(), RolaId: 3}});   
        });
    });
});




app.get('/',function(req,res){
    res.sendFile(__dirname + '/index.html');  
});

app.get('/statistika',function(req,res){
    if(req.session.dozvola === 2)    
        res.sendFile(__dirname + '/public/statistika.html'); 
    else
        res.send(permissionError);    
});
app.get('/komentari',function(req,res){

    if(req.session.dozvola === 2)    
    res.sendFile(__dirname + '/public/unosKomentara.html');   
    else
    res.send(permissionError);  
    
});
app.get('/listaKorisnika',function(req,res){

    if(req.session.dozvola != 1)
    {
        res.send(permissionError);
        res.end();
    }
    Podaci.findAll(
        {
            include: [Korisnik],
        }
    ).then(function(results){
        var ispis = '';
        var redovi = [];
        for(i = 0; i < results.length;i++)
        {
            //i ovdje trazis
        }
    });
   
});
app.get('/unosSpiska',function(req,res){

    if(req.session.dozvola === 3)    
        res.sendFile(__dirname + '/public/unosSpiska.html');  
    else
        res.send(permissionError);    
   
});
app.get('/bitbucket',function(req,res){

    if(req.session.dozvola === 3)    

        res.sendFile(__dirname + '/public/bitbucketPozivi.html');  
    else
        res.send(permissionError);    
   
});
app.get('/nastavnik',function(req,res){

    if(req.session.dozvola === 3)    
    
        res.sendFile(__dirname + '/public/nastavnik.html');    
    else
        res.send(permissionError);    
   
});
app.post('/unosSpiska',function(req,res){
    var objekat = req.body.objekat;
    var x = req.body.x;
    
    fs.appendFile('spisak'+x+'.txt',objekat,function(err){
        if(err) throw err;
        //res.json({message:"Uspješno dodan red",data:novaLinija});
    });
 });
 
 app.post('/login',function(req,res){

    //res.sendFile(__dirname + '/public/login.html'); 
   console.log("ušlo u post login");
    
  var podaci = req.body;

  console.log(podaci);
 
  var username = podaci.username.replace('<','').replace('>','').replace('SELECT','').replace('select','');
  var password = podaci.password.replace('<','').replace('>','').replace('SELECT','').replace('select','');
  console.log(username);
  console.log(password);
    Korisnik.findOne({
        
        where: {
            
          username: username
        }
      }).then(function(results){
        if(!results)
        {
           // console.log("Uslo u if :D");
            res.send('Nije pronadjen korisnik sa ovim korisnickim imenom');
            res.end();
        }
        else{
           var k = results.dataValues;
           bcrypt.compare(password, k.password, function(err, rezultat) {
            if (err) throw err;

            if(rezultat === true)
            {
               req.session.dozvola = korisnik.RolaId;
               if(k.RolaId==1)
                    res.sendFile(__dirname + '/public/RolaAdmin.html');
               if(k.RolaId == 2)
                    res.sendFile(__dirname + '/public/RolaStudent.html');
               if(k.RolaId == 3)
                    res.sendFile(__dirname + '/public/RolaNastavnik.html');
            }
        })
    }
});
 });


app.post('/komentar',function(req,res){
    fs.writeFile('marksS'+req.body.spirala + req.body.index + '.json', JSON.stringify(req.body.sadrzaj), function(error){
        if(error)
        {
            res.status(500).json({
                message:"Podaci nisu u trazenom formatu!",
                data:null
            });
            return;
        }
        res.json({
            message:"Uspješno kreirana datoteka!",
            data:JSON.stringify(req.body.sadrzaj)
        });

    })
})



app.post('/lista',function(req,res){
    fs.writeFile('spisak'+ req.body.godina + '.txt', JSON.stringify(req.body.nizRepozitorija), function(error){
        if(error)
        {
            res.status(500).json({
                message:"Podaci nisu u traženom formatu!",
                data:null
            });
            return;
        }
        res.json({
            message:"Lista uspješno kreirana",
            data:JSON.stringify(req.body.nizRepozitorija)
        });

    })
})


app.post('/izvjestaj',function(req,res){
    fs.writeFile('izvjestajS'+ req.body.spirala + req.body.index + '.txt', JSON.stringify(req.body.index), function(error){
        if(error)
        {
            res.status(500).json({
                message:"Podaci nisu u traženom formatu!",
                data:null
            });
            return;
        }
        res.json({
            message:"Izvjestaj uspjesno kreiran",
            data:JSON.stringify(req.body.index)
        });

    })
})


app.post('/bodovi',function(req,res){
  
})


app.post('/register',function(req,res){
  
    console.log("ušlo u post reg");
    //var podaci11 = req.body;
    
   // console.log(podaci11);
   console.log(req.body['imeprezime1']);
   
        if(req.body['imeprezime1'] != ''){
            console.log(req.body.password);
            bcrypt.hash(req.body.password, salt,null,function(err,hash) {
            Podaci.create({imePrezime:req.body['imeprezime1'].replace(/</g,'').replace(/>/g,''), 
                fakultetskiMail:req.body['fakultetskimail'].replace(/</g,'').replace(/>/g,''),
                maksimalanBrojGrupa:req.body['maxbrojgrupa'].replace(/</g,'').replace(/>/g,''),
                regexZaValidaciju:req.body['regex'].replace(/</g,'').replace(/>/g,''),
                trenutniSemestar:req.body['trenutni'].replace(/</g,'').replace(/>/g,''),
                akademskaGodina:req.body['tak'].replace(/</g,'').replace(/>/g,''),
                verified:false,
            }).then(function(zapis){
                console.log('nesto');
                            Korisnik.create({
                                username:req.body.korisnickoime.replace(/</g,'').replace(/>/g,''),
                                password:hash.toString(),
                                Podaci:zapis.id,
                                RolaId:3
                            });
                            res.send(zapis);
                        })
                        .catch(function(err){
                            res.send(err);
                        });
                    });

        }
       else if(req.body['imeprezime']!='')
        {
            bcrypt.hash(req.body.passsword, saltRounds).then(function(err,hash) {
                Podaci.create({imePrezime:req.body['imeprezime'].replace(/</g,'').replace(/>/g,''), 
                                    brojIndexa:req.body['index'].replace(/</g,'').replace(/>/g,''),
                                    grupa:req.body['grupa'].replace(/</g,'').replace(/>/g,''),
                                    verified:null,
                                    bitbucketUrl:req.body['bitbucket'].replace(/</g,'').replace(/>/g,''),
                                    bitbucketSsh:req.body['ssh'].replace(/</g,'').replace(/>/g,''),
                                    nazivRepozitorija:req.body['repozitorij'].replace(/</g,'').replace(/>/g,''),
                            })
                            .then(function(zapis){
                                Korisnik.create({
                                    passsword:hash.toString(),
                                    username:req.body['imeprezime'].replace(/</g,'').replace(/>/g,''),
                                    PodaciId:zapis.id,
                                    RolaId:2
                                });
                                res.send(zapis);
                            })
                            .catch(function(err){
                                res.send(err);
                            });
                        });
        }
        else
        {
            res.send('Nije dobar format');
        }
});



app.listen(8080);