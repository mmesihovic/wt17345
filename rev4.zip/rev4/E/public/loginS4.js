function prikaziLogin()
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("prikaz").innerHTML = ajax.responseText;
    }
    ajax.open("GET", "/", true);
    ajax.send();
}
function statistika()
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("citavastranica").innerHTML = ajax.responseText;
    }
    ajax.open("GET", "/statistika", true);
    ajax.send();
}

function lista()
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("citavastranica").innerHTML = ajax.responseText;
    }
    ajax.open("GET", "/listaKorisnika", true);
    ajax.send();
}

function komentari()
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("citavastranica").innerHTML = ajax.responseText;
    }
    ajax.open("GET", "/komentari", true);
    ajax.send();
}

function spisak()
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("citavastranica").innerHTML = ajax.responseText;
    }
   // ajax.open("GET", "http://localhost:3000/unosSpiska", true);
   ajax.open("GET", "/unosSpiska", true);
    ajax.send();
}


function bitbucket()
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("citavastranica").innerHTML = ajax.responseText;
    }
    ajax.open("GET", "/bitbucket", true);
    ajax.send();
}

function nastavnik()
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("citavastranica").innerHTML = ajax.responseText;
    }
    ajax.open("GET", "/nastavnik", true);
    ajax.send();
}


function loginajSe()
{
    var ajax = new XMLHttpRequest();
    var username = document.getElementById('user').value;
    var password = document.getElementById('pass').value;

    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("citavastranica").innerHTML = ajax.responseText;
        }
    }

    ajax.open("POST","/login",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify({username:username,password:password}));
}