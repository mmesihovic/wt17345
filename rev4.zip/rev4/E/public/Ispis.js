function IspisiP(vrijednost)
{
    debugger;
    if(!vrijednost)
       { //Poruke.ispisiGreske()
        var mjesto = document.getElementById("komentari");
        //mjesto.innerHTML = "Greska";
        postaviIdDiva(mjesto);
       }

    

}