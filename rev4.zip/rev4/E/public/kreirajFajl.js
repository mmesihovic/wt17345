var KreirajFajl = (function(){

    function validirajKomentar(spirala,index,sadrzaj)
    {
        return true;
    }


    return{
        kreirajKomentar : function(spirala, index, sadrzaj, fnCallback){
            var ajax1 = new XMLHttpRequest();
            var js1;

            ajax1.onreadystatechange = function()
            {
                
                if(ajax1.readyState == 4 && ajax1.status == 200)
                {
                    fnCallback(null, ajax1.responseText);
                    
                }
                else
                {
                    fnCallback(ajax1.status, ajax1.responseText);
                }
            }
            var json=true;
            //sadrzaj = JSON.stringify(sadrzaj);
          for (var i=0;i<sadrzaj.length; i++)
            {
                if(!(sadrzaj[i].hasOwnProperty('sifra_studenta') && sadrzaj[i].hasOwnProperty('tekst') && sadrzaj[i].hasOwnProperty('ocjena')))
                {
                    json = false;
                }
            }
            
            if(typeof(spirala)== 'string' && typeof(index) =='string' && spirala.length >= 1 && index.length >= 1 && json )
            {
                console.log("i ovo je ok");
                var obj = {
                    spirala: spirala,
                    index: index,
                    sadrzaj: sadrzaj
                }
                
                ajax1.open("POST","/komentar",true);
                ajax1.setRequestHeader("Content-Type","application/json");
                ajax1.send(JSON.stringify(obj));
            }

            else
                fnCallback(-1, 'Neispravni parametri');
            
        },

        kreirajListu : function(godina, nizRepozitorija, fnCallback){

            var ajax1 = new XMLHttpRequest();
            var nizRep = [];

            console.log(nizRep);
            console.log(js1);

            ajax1.onreadystatechange = function()
            {
                if(ajax1.readyState == 4 && ajax1.status == 200)
                {
                    fnCallback(null, ajax1.responseText);
                   
                }
                else
                {
                    fnCallback(ajax1.status, ajax1.responseText);
                }
            }

            if(typeof(godina)=='string' && godina.length>=1 && nizRepozitorija.length >= 1)
            {
                for(var i = 0; i<nizRepozitorija.length; i++) 
                { 
                    if(nizRepozitorija[i].includes(godina))
                    {
                        nizRep.push(nizRepozitorija[i]);
                    }
                    var js1 = {
                        godina: godina,
                        nizRepozitorija: nizRep 
                    }

                   

                    ajax1.open("POST","/lista",true);
                    ajax1.setRequestHeader("Content-Type","application/json");
                    ajax1.send(JSON.stringify(js1));
                

                }
            }

                else
                {
                    fnCallback(-1,"Neispravni parametri");
                }


        },

        kreirajIzvjestaj :  function(spirala,index,fnCallback)
        {

            var ajax1 = new XMLHttpRequest();
            var js1;

            ajax1.onreadystatechange = function()
            {
                if(ajax1.readyState == 4 && ajax1.status == 200)
                {
                    fnCallback(null, ajax1.responseText);
                    var element = {
                        spirala:spirala,
                        index: index
                    };
                    js1 = JSON.stringify(element);
                }
                if(ajax1.readyState == 4 && ajax1.status == 404)
                {
                    fnCallback(ajax1.status,ajax1.responseText);
                }

                if(!validirajKomentar(spirala,index))
                {
                    fnCallback(-1,"Neispravni parametri");
                }

                ajax1.open("POST","/izvjestaj",true);
                ajax1.setRequestHeader("Content-Type","application/json");
                ajax1.send(js1);
            }
        },

        kreirajBodove : function(spirala,index,fnCallback)
        {

            var ajax1 = new XMLHttpRequest();
            var js1;

            ajax1.onreadystatechange = function()
            {
                if(ajax1.readyState == 4 && ajax1.status == 200)
                {
                    fnCallback(null, ajax1.responseText);
                    var element = {
                        spirala:spirala,
                        index: index
                    };
                    js1 = JSON.stringify(element);
                }
                if(ajax1.readyState == 4 && ajax1.status == 404)
                {
                    fnCallback(ajax1.status,ajax1.responseText);
                }

                if(!validirajKomentar(spirala,index))
                {
                    fnCallback(-1,"Neispravni parametri");
                }

                ajax1.open("POST","/bodovi",true);
                ajax1.setRequestHeader("Content-Type","application/json");
                ajax1.send(js1);
            }
        }

    }
})();