function spisak() {
    var str = document.getElementById("tekst").value;
    var res = str.split("\n");
    var NemaDuplih = true;
    var IspravniIndeksi = true;
    var broj = document.getElementById("broj").value;
   
    
    for (var i = 0; i<res.length ; i++)
    {
        var a = res[i].split(",");
       
      	var jelok = hasDuplicates(a);
        if(jelok) 
        { 
            NemaDuplih = false;
            break; 
		}
        else 
        {
        for(var j = 0; j<a.length; j++)
        {
            IspravniIndeksi = validirajIndeks(a[j]);
            if(IspravniIndeksi == false) {  break; }
        }
        }
    }
    if(NemaDuplih && IspravniIndeksi)
     {
        var ajax = new XMLHttpRequest();
        var objekat = [];        
        for (var k=0; k<res.length;k++)
        {
            var manjiNizJSONa = []; // element objekat
            var elementMNJ; //element manjiNIzJSONa
            var a = res[k].split(",");
            for(var h=0; h<a.length;h++)
            {
                //elementMNJ = JSON.stringify(x[h]);
                elementMNJ = a[h];
                manjiNizJSONa.push(elementMNJ);
            }
            objekat.push(manjiNizJSONa);

        }
         //document.getElementById("dugme").innerHTML = "sveok";
         ajax.open("POST", "/unosSpiska", true);
         ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
         ajax.send("x="+broj+"&objekat="+JSON.stringify(objekat));

     }
    else
    {
        document.getElementById("dugme").innerHTML = "Nije ok"; 			
    }
  
}


function validirajIndeks(index) {

    var regexIndex = /^1[0-9]{4}$/g;
    
        if(regexIndex.test(index))
        {
            return true;
        }
        return false;
 
}

function hasDuplicates(array) {
    var valuesSoFar = Object.create(null);
    for (var i = 0; i < array.length; ++i) {
        var value = array[i];
        if (value in valuesSoFar) {
            return true;
        }
        valuesSoFar[value] = true;
    }
    return false;
}

    
    
