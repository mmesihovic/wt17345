const Sequelize = require("sequelize");
const sequelize = require("./baza.js");

const Podaci = sequelize.define('Podaci',{

    imePrezime: Sequelize.STRING(30),
    brojIndexa: Sequelize.STRING(30),
    grupa: Sequelize.STRING(5),
    akademskaGodina: Sequelize.STRING(10),
    bitbucketUrl: Sequelize.STRING,
    bitbucketSsh: Sequelize.STRING,
    nazivRepozitorija: Sequelize.STRING(15),
    fakultetskiMail: Sequelize.STRING(30),
    maksimalanBrojGrupa: Sequelize.INTEGER,
    regexZaValidaciju: Sequelize.STRING(15),
    trenutniSemestar: Sequelize.STRING(15),
    verified: Sequelize.BOOLEAN
})

module.exports = function(sequelize,DataTypes){
    return Podaci;
}