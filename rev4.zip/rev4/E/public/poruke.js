var Poruke=(function(){
    
    var ispisiGreske = function ()
    {
        //debugger;
       var mjesto = document.getElementById("komentari");
       // postaviIdDiva(mjesto);
        //idDivaPoruka.innerHTML = "Greska";
        mjesto.innerHTML= "";

        for(var i=0; i<porukeZaIspis.length;i++)
            mjesto.innerHTML = mjesto.innerHTML + "<br />" + porukeZaIspis[i];
        
        if(porukeZaIspis.length == 0) mjesto.innerHTML = "";

    }
    
    var postaviIdDiva = function (id)
    {
        idDivaPoruka = id;
    }
    
    var dodajPoruku = function (brojPoruka)
    {
        //debugger;
        var dodaj = moguceporuke[brojPoruka];
        if(!porukeZaIspis.includes(dodaj)) porukeZaIspis.push(dodaj);

    }
    var ocistiGresku = function (brojBrisi)
    {
        var brisi = moguceporuke[brojBrisi];
        var ind = porukeZaIspis.indexOf(brisi);
        if(porukeZaIspis.includes(brisi))
            porukeZaIspis.splice(index,1);

    }
    var idDivaPoruka;
    var moguceporuke=["Email koji ste napisali nije validan fakultetski email",
                      "Index kojeg ste napisali nije validan",
                    "Nastavna grupa koju ste napisali nije validna",
                    "Akademska godina koju ste napisali nije validna",
                    "Password nije validan",
                    "Password nije isti",
                    "BitbucketURL koji ste unijeli nije validan",
                    "BitbucketSSH koji ste unijeli nije validan",
                    "Naziv repozitorija koji ste unijeli nije validan",
                    "Ime i prezime koje ste unijeli nije validno"]
    var porukeZaIspis = [];

    return{
        ispisiGreske: ispisiGreske,
        postaviIdDiva: postaviIdDiva,
        dodajPoruku: dodajPoruku,
        ocistiGresku: ocistiGresku
    }




}());