function registrujNastavnika(){
  
    var ajax = new XMLHttpRequest();
    var imePrezs = document.getElementById('imeprezime1').value;
    //var rijeci= imePrezime.split(" ");
    //var ime = rijeci[0], prezime=rijeci[1];
    var username = document.getElementById('korisnickoime').value;
    var pass = document.getElementById('password1').value;

    var mail = document.getElementById('fakultetskimail').value;
    var akGod = document.getElementById('tak').value;
    
    var regex = document.getElementById('regex').value;
    var sem = document.getElementById('trenutni').value;
    var grupe = document.getElementById('maxbrojgrupa').value;

    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("citavastranica").innerHTML = ajax.responseText;
        }
    }

    ajax.open("POST","/register",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify({username:imePrezs,brojIndexa:null,grupa:null,akademskaGodina:akGod,bitbucketUrl:null,bitbucketSsh:null, nazivRepozitorija:null,fakultetskiMail:mail,maksimalanBrojGrupa:grupe,regexZaValidaciju:regex,trenutniSemestar:sem,verified:"false",password:pass}));


  }