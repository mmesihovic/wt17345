

//function getValidacija(){
   // debugger;
    //var inputemail = document.getElementById("email").value;
    //var inputindex = document.getElementById("index").value;
    //var inputgrupa = document.getElementById("grupa").value;
    //var inputakgod = document.getElementById("akgod").value;
    //var inputpassword = document.getElementById("password").value;
    //var inputpotvrda = document.getElementById("potvrda").value;
    //var inputbitbucket = document.getElementById("bitbucket").value;
    //var inputssh = document.getElementById("ssh");
    //var inputrep = document.getElementById("repozitorij");
    //var inputimeprezime = document.getElementById("imeprezime").value;

var Validacija = (function(){
    //debugger;
    var maxGrupa=7;
    var trenutniSemestar=0;
    

    var validirajFakultetski = function (email)
    {
        var regexEmail = /^[a-zA-Z0-9]+@(etf\.unsa)\.ba$/g ;
    
        if(regexEmail.test(email))
            {
                Poruke.ocistiGresku(0);
                Poruke.ispisiGreske();
                return true;
            }
        else
        {
            Poruke.dodajPoruku(0);
            Poruke.ispisiGreske();
            return false;
        }
        
    }
    
    
    var validirajIndex = function (index)
    {
        //debugger;
        var regexIndex = /^1[0-9]{4}$/g;
    
        if(regexIndex.test(index))
            {
                Poruke.ocistiGresku(1);
                Poruke.ispisiGreske();
                return true;
            }
        else
            {
                Poruke.dodajPoruku(1);
                Poruke.ispisiGreske();
                return false;
            }
    }
    
    var validirajGrupu = function (grupa)
    {
        if(grupa>=1 && grupa<=7)
        {
            Poruke.ocistiGresku(2);
            Poruke.ispisiGreske();
            return true;
        }
    else
        {
            Poruke.dodajPoruku(2);
            Poruke.ispisiGreske();
            return false;
        }
    }
    
    var validirajAkGod = function (god)
    {
        var regexAkGod = /20[0-9][0-9][/]20[0-9][0-9]/g;
    
        if(regexAkGod.test(god))
        {
            Poruke.ocistiGresku(3);
            Poruke.ispisiGreske();
            return true;
        }
    else
        {
            Poruke.dodajPoruku(3);
            Poruke.ispisiGreske();
            return false;
        }
    }
    
    var validirajPassword = function (pass)
    {
        var regexPassword = /^[A-Za-z\d]{7,20}$/g;
        if(regexPassword.test(pass))
        {
            Poruke.ocistiGresku(4);
            Poruke.ispisiGreske();
            return true;
        }
    else
        {
            Poruke.dodajPoruku(4);
            Poruke.ispisiGreske();
            return false;
        }
    }
    
    var validirajPotvrdu = function (pass,pot)
    {
        if(pass==pot)
        {
            Poruke.ocistiGresku(5);
            Poruke.ispisiGreske();
            return true;
        }
    else
        {
            Poruke.dodajPoruku(5);
            Poruke.ispisiGreske();
            return false;
        }
    }
    
    var validirajBitbucketURL = function (url)
    {
        var regexURL = /^https:\/\/[a-z]+@bitbucket\.org\/username2\/[A-Za-z]+\.git $/g;
    
        if(regexURL.test(url))
        {
            Poruke.ocistiGresku(6);
            Poruke.ispisiGreske();
            return true;
        }
    else
        {
            Poruke.dodajPoruku(6);
            Poruke.ispisiGreske();
            return false;
        }
    
    }
    
    var validirajBitbucketSSH = function (ssh)
    {
        var regexSSH = /git@bitbucket\.org:[A-Za-z]+\/[A-Za-z]+\.git$/g;
    
        if(regexSSH.test(ssh))
        {
            Poruke.ocistiGresku(7);
            Poruke.ispisiGreske();
            return true;
        }
    else
        {
            Poruke.dodajPoruku(7);
            Poruke.ispisiGreske();
            return false;
        }
    }
    
    var validirajNazivRepozitorija = function (naziv)
    {
        var regexRep = /^(wtProjekat|wtprojekat)[0-9]{5}$/g;
       // if (reg === null) reg = regexRep;
        if(regexRep.test(naziv))
        {
            Poruke.ocistiGresku(8);
            Poruke.ispisiGreske();
            return true;
        }
    else
        {
            Poruke.dodajPoruku(8);
            Poruke.ispisiGreske();
            return false;
        }
    }
    
    var validirajImeiPrezime = function (imeprezime)
    {
        //var regeximeprezime = /[A-Z-'-Ž-Ć-Č-Š][a-z-'-ž-ć-č-š]{2,11}\s[A-Z-Ć-Č-Š][a-ć-č-š-z]{2,11}/g;
        var regeximeprezime = /^([A-ZŠĐŽĆČ]{1,1}[a-zA-Z-'ŠĐŽĆČšđžćč]{2,12})(( [A-ZŠĐŽĆČ]{1,1}[a-zA-Z-'ŠĐŽĆČšđžćč]{2,12})+)?$/g;
        if(regeximeprezime.test(imeprezime))
        {
            Poruke.ocistiGresku(9);
            Poruke.ispisiGreske();
            return true;
        }
    else
        {
            Poruke.dodajPoruku(9);
            Poruke.ispisiGreske();
            return false;
        }
    }



    var postaviMaxGrupa = function(max)
    {
        if(ma>0 && ma<8)
        {
             maxGrupa = max;
             return true;
        }
        return false;
        
    }

    var postaviTrenSemestar = function(r)
    {
        if(r==0 || r==1)
           {
            trenutniSemestar=r;
            return true;
           }
        return false;
         
    }
    
    return{
        validirajFakultetski: validirajFakultetski,
        validirajIndex: validirajIndex,
        validirajGrupu: validirajGrupu,
        validirajAkGod: validirajAkGod,
        validirajPassword: validirajPassword,
        validirajPotvrdu: validirajPotvrdu,
        validirajBitbucketURL: validirajBitbucketURL,
        validirajBitbucketSSH: validirajBitbucketSSH,
        validirajNazivRepozitorija: validirajNazivRepozitorija,
        validirajImeiPrezime: validirajImeiPrezime,
        postaviMaxGrupa: postaviMaxGrupa,
        postaviTrenSemestar: postaviTrenSemestar
    }
}());
//return Validacija;
//}
