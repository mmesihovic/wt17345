var BitbucketApi= (function(){
    var tokenn;
    var imaBranch;
    
    return {

    dohvatiAccessToken: function(key, secret, fnCallback){
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() 
        {
            if (ajax.readyState == 4 && ajax.status == 200)
            {
                tokenn=JSON.parse(ajax.responseText).access_token;
                fnCallback(null,tokenn);
            }
            else if (ajax.readyState == 4)
                fnCallback(ajax.status,null);
            else if (key==null || secret==null)
                fnCallback(-1, "Key ili secret nisu pravilno proslijeđeni!");
        }

        ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
        ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+":"+secret));
        ajax.send("grant_type="+encodeURIComponent("client_credentials"));
    },

   dohvatiRepozitorije:function(token,godina,naziv,branch,fnCallback)
    {
        var ajax = new XMLHttpRequest();
        var error;
        var data;
        console.log("prvi");
        
        ajax.onreadystatechange = function(){
            if (ajax.readyState == 4 && ajax.status == 200)
            {
                //console.log("drugi");
                
                var odg = JSON.parse(ajax.responseText).values;
                var nizData=[];
                
                for(var i=0;i<odg.length;i++)
                {
                   
                    brisi=false;
                    if(!(odg[i].created_on.substr(0,4)>=godina && odg[i].created_on.substr(0,4)<=godina+1)) brisi=true;
                   
                    function pomfun(x){
                        BitbucketApi.dohvatiBranch(token,odg[i].links.branches.href,branch,function(err,dat){
                            if(!dat)brisi=true;
                            if(pom==null) brisi=true;
                            if(!brisi){
                             for(var j=0;j<x.length;j++){
                                 if(x[j].name=="ssh") nizData.push(x[j].href);
                             }
                            }
                            console.log({data:dat});
                            console.log({x:x}); 
                            console.log({i:i,odg:odg.length});
                            if(i==odg.length){
                                error=null;
                                data=nizData;
                                fnCallback(error,data)
                            }
                        });
                     }
                     pomfun(odg[i].links.clone);
                    }
               
                
            }
            else if (ajax.readyState == 4)
            {
                error=ajax.status;
                data=null;
                fnCallback(error,data);
            }
            
    }
    ajax.open("GET",'https://api.bitbucket.org/2.0/repositories/?role=member&q=name~"'+naziv+'"&pagelen=100');
    ajax.setRequestHeader("Authorization", 'Bearer ' + token);
    ajax.send();
    },

    dohvatiBranch: function(token, url, naziv, fnCallback) {
        token=tokenn;
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function(){
            if (ajax.readyState==4 && ajax.status==200){
                var podaci = JSON.parse(ajax.responseText);
                var ima=false;
                for (var i=0;i<podaci.values.length;i++)
                {
                    if(podaci.values[i].name==naziv) ima=true;
                }
                if (ima) fnCallback(null,true);
                else fnCallback(null,false);  
            }
            else if (ajax.readyState==4) 
                console.log(ajax.status, null);
        }
        ajax.open("GET",url);
        ajax.setRequestHeader("Authorization", 'Bearer '+ token);
        ajax.send();
    }
    }
    
    


})();