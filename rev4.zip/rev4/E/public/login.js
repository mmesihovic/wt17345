function pokaziStudenta() {
    //var d = document.getElementById("komentari");
   // d.style.display = "none";
    var x = document.getElementById("formaregistracijastudenta");
    var y = document.getElementById("formaregistracijaprofesora");
    //if (x.style.display === "none") {
        x.style.display = "block";
        y.style.display = "none";
    //}
}

function pokaziProfesora() {
    //var d = document.getElementById("komentari");
    //d.style.display = "none";
    var x = document.getElementById("formaregistracijastudenta");
    var y = document.getElementById("formaregistracijaprofesora");
    //if (y.style.display === "none") {
        y.style.display = "block";
        x.style.display = "none";
    //}
}