function zamjena1()
{
	var ajax = new XMLHttpRequest();
	ajax.onreadystatechange = function() {
	if (ajax.readyState == 4 && ajax.status == 200)
		document.getElementById("polje").innerHTML = ajax.responseText;
	if (ajax.readyState == 4 && ajax.status == 404)
		document.getElementById("polje").innerHTML = "Greska: nepoznat URL";
}

ajax.open("GET", "login.html", true);
ajax.send();
}

function zamjena2()
{
	var ajax = new XMLHttpRequest();
	ajax.onreadystatechange = function() {
	if (ajax.readyState == 4 && ajax.status == 200)
		document.getElementById("polje").innerHTML = ajax.responseText;
	if (ajax.readyState == 4 && ajax.status == 404)
		document.getElementById("polje").innerHTML = "Greska: nepoznat URL";
}

ajax.open("GET", "unoskomentara.html", true);
ajax.send();
}

function zamjena3()
{
	var ajax = new XMLHttpRequest();
	ajax.onreadystatechange = function() {
	if (ajax.readyState == 4 && ajax.status == 200)
		document.getElementById("polje").innerHTML = ajax.responseText;
	if (ajax.readyState == 4 && ajax.status == 404)
		document.getElementById("polje").innerHTML = "Greska: nepoznat URL";
}

ajax.open("GET", "statistika.html", true);
ajax.send();
}

function zamjena4()
{
	var ajax = new XMLHttpRequest();
	ajax.onreadystatechange = function() {
	if (ajax.readyState == 4 && ajax.status == 200)
		document.getElementById("polje").innerHTML = ajax.responseText;
	if (ajax.readyState == 4 && ajax.status == 404)
		document.getElementById("polje").innerHTML = "Greska: nepoznat URL";
}

ajax.open("GET", "unosSpiska.html", true);
ajax.send();
}

function zamjena5()
{
	var ajax = new XMLHttpRequest();
	ajax.onreadystatechange = function() {
	if (ajax.readyState == 4 && ajax.status == 200)
		document.getElementById("polje").innerHTML = ajax.responseText;
	if (ajax.readyState == 4 && ajax.status == 404)
		document.getElementById("polje").innerHTML = "Greska: nepoznat URL";
}

ajax.open("GET", "nastavnik.html", true);
ajax.send();
}

function zamjena6()
{
	var ajax = new XMLHttpRequest();
	ajax.onreadystatechange = function() {
	if (ajax.readyState == 4 && ajax.status == 200)
		document.getElementById("polje").innerHTML = ajax.responseText;
	if (ajax.readyState == 4 && ajax.status == 404)
		document.getElementById("polje").innerHTML = "Greska: nepoznat URL";
}

ajax.open("GET", "bitbucketPozivi.html", true);
ajax.send();
}

function zamjena7()
{
	var ajax = new XMLHttpRequest();
	ajax.onreadystatechange = function() {
	if (ajax.readyState == 4 && ajax.status == 200)
		document.getElementById("polje").innerHTML = ajax.responseText;
	if (ajax.readyState == 4 && ajax.status == 404)
		document.getElementById("polje").innerHTML = "Greska: nepoznat URL";
}

ajax.open("GET", "listaKorisnika.html", true);
ajax.send();
}