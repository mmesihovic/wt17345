const Sequelize = require("sequelize");
const sequelize = new Sequelize("novabaza","root","root",{host:"172.30.85.9	",dialect:"mysql"});
//const sequelize = new Sequelize("novabaza","root","",{host:"localhost",dialect:"mysql"});
module.exports = sequelize;