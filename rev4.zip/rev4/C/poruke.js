var Poruke=(function(){
  var idDivaPoruka;
  var mogucePoruke=["Email koji ste napisali nije validan fakultetski email",
                    "Indeks kojeg ste napisali nije validan",
                    "Nastavna grupa koju ste napisali nije validna",
                    "Akademska godina koju ste napisali nije validna",
                    "Password koji ste unijeli nije validan",
                    "Passwordi koje unesete moraju biti identicni",
                    "Bitbucket URL koji ste unijeli nije validan",
                    "Bitbucket SSH koji ste unijeli nije validan",
                    "Naziv repozitorija koji ste unijeli nije validan",
                    "Ime i prezime koje ste unijeli nisu validni"];
  var porukeZaIspis=[];
  var idDiva;
  return{
    ispisiGreske: function ispisiGreske()
    {
      document.getElementById(idDiva).innerHTML = porukeZaIspis.join("<br>");
    },
    postaviIdDiva: function postaviIdDiva(id)
    {
      idDiva = id;
    },
    dodajPoruku: function dodajPoruku(broj)
    {
      if (broj >= 0 && broj < 10) {
        if (porukeZaIspis.indexOf(mogucePoruke[broj]) != -1) {
          porukeZaIspis.push(mogucePoruke[broj]);
        }
      }
    },
    ocistiGresku: function ocistiGresku(broj)
    {
      if (broj >= 0 && broj < 10) {
        var pozicija = porukeZaIspis.indexOf(mogucePoruke[broj]);
        if (pozicija != -1) {
          porukeZaIspis.splice(pozicija, 1);
        }
      }
    }
  }
}());
