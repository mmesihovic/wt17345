//username: admin, sifra: admin

const express = require('express');
const session = require("express-session");
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const path = require('path');
const fs = require('fs');
const mysql = require('mysql');
const mysql2 = require('mysql2');
var bcrypt = require('bcryptjs');
const clientSession = require('client-sessions');
const Sequelize = require('sequelize');
const sequelize = require('./public/db/mojaBaza.js');
const korisnik = sequelize.import(__dirname+"/public/db/korisnik.js");
const rola = sequelize.import(__dirname+"/public/db/rola.js");
const licni_podaci = sequelize.import(__dirname + "/public/db/licniPodaci.js");
var app = express();
var xssFilters = require('xss-filters');
app.use(session({
    secret : 'sifrica',
    resave : true,
    saveUninitialized : true
}));
const Op = Sequelize.Op;
licni_podaci.sync();
rola.sync().then(function(nesta){
    rola.findOrCreate({where: {Rid:1}, defaults:{naziv: 'Administrator'}})
    rola.findOrCreate({where: {Rid:2}, defaults:{naziv: 'Student'}})
    rola.findOrCreate({where: {Rid:3}, defaults:{naziv: 'Nastavnik'}})
});

rola.hasOne(korisnik, {as:'rola', foreignKey: 'rolaId'});
licni_podaci.hasOne(korisnik,{foreignKey:'licniId'});

korisnik.sync().then(function(nestaopet){
    korisnik.findOrCreate({where:{id:1}, defaults:{korisnickoIme:'admin', sifra:'$2a$10$BRmkJs9.9xdaPJ1QVSTudu1bh7AgN0grMsrqNEtkYWW4B9bZr2Qc2',rolaId:1,licniId:null}})
});




app.use(bodyParser.json());
app.use(cookieParser());
//app.use(express.static('./'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/static', express.static(path.join(__dirname,'public')));
app.get('/',function(req,res){
    res.sendFile(__dirname + '/public/index.html'); 
   
});

app.get('/static/statistika',function(req,res){
    if(req.session.permisija==2){
    res.sendFile(__dirname + '/public/statistika.html'); 
    }
    else{
        res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
    }
   
});


app.get('/static/nastavnik',function(req,res){
    if(req.session.permisija==3){
    res.sendFile(__dirname + '/public/nastavnik.html'); 
    }
    else{
        res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
    }
   
});
app.get('/static/unoskomentara',function(req,res){
    if(req.session.permisija==2){
    res.sendFile(__dirname + '/public/unoskomentara.html'); 
    }
    else{
        res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
    }
   
});
app.get('/static/unosSpiska',function(req,res){
    if(req.session.permisija==3){
    res.sendFile(__dirname + '/public/unosSpiska.html'); 
    }
    else{
        res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
    }
   
});
app.get('/static/bitbucketPozivi',function(req,res){
    if(req.session.permisija==3){
    res.sendFile(__dirname + '/public/bitbucketPozivi.html'); 
    }
    else{
        res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
    }
   
});

app.post('/unosSpiska', function(req,res){
    if(req.session.permisija==2){
    var bod = req.body;

    var indeksii = bod.tekstArea.toString();
 
    var brojSpirale = bod.brojBox.toString();

    if(indeksii.toString()==""){
        greska = true;
        ispisiGresku = "Unijeti indekse";
    }
    if(brojSpirale==""){
        greska = true;
        ispisiGresku = "Unijeti broj spirale";
    }
    var brojReda;
    var indeks="";
    var validniString = indeksii;
    var greska = false;
    let redPoRed = indeksii.split('\n');
    var jsonVrijednost = "[";
    var ispisiGresku;
    
    for(var i = 0;i < redPoRed.length;i++)
    {
        var nizIndexa = redPoRed[i].split(',');
        if(nizIndexa.length!=6){
            greska = true;
            brojReda = parseInt(i) + 1;
            ispisiGresku = "U redu " + brojReda + " nema dovoljno indeksa.";
            break;
        }
        var mojNiz = [];
        for(var j=0;j<nizIndexa.length;j++){
            var novii = nizIndexa[j];
            if(novii.length<1 || novii[0]!="1" ){
                greska = true;
                ispisiGresku = "Indeks " + novii + " nije validan.";
                break;
            }
            mojNiz.push(novii);      
        }
        var ind;
        var ind2;
        for(var jj = 0; jj<nizIndexa.length;jj++){
            ind = nizIndexa[jj];
            var prebroji = 0;
            for(var jj2 = jj + 1; jj2<nizIndexa.length;jj2++){
                ind2 = nizIndexa[jj2];
                if(ind2 == ind){
                    prebroji++;
                }
            }
            if(prebroji>0){
               greska=true;
               brojReda = parseInt(i) + 1;
               ispisiGresku = "U redu " + brojReda.toString() + " se pojavljuju isti indeksi";
               break;
            }
        }
        var reeed = "[";
        for(var k = 0; k< nizIndexa.length;k++){
            if(k!= nizIndexa.length-1){
                
            reeed = reeed + '"' + nizIndexa[k] + '",';
            }
            else{
                reeed = reeed +'"' + nizIndexa[k] + '"]';
            }
        }
        jsonVrijednost = jsonVrijednost + reeed;
        if(i!=redPoRed.length-1){
            jsonVrijednost = jsonVrijednost + ",";
        
        }
    }
    jsonVrijednost = jsonVrijednost + "]";
           
        if(greska==true){
            res.send(ispisiGresku);
        }
        else{
            fs.appendFile('spisakS' + brojSpirale + '.json', jsonVrijednost,function(err){
                if(err) throw err;
                res.end("Indeksi su dodani");
            });
        }
    }
    else{
        res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!",data:null}));
    }
                    
              
});


app.post('/komentar',function(req,res){
    if(req.session.permisija==3){
    let bod = req.body;
    var datotekica = 'markS' + bod['spirala'] + bod['index'] + '.json';

    var indeks = bod['index'];
    var spp = bod['spirala'];
    var sad = bod['sadrzaj'];
 
    var nadjiGreskuSadrzaja= false;
    sad.replace("},{", "|");
    var ss = sad.split('|');
    for(var i = 0; i < ss.length; i ++)
        {
 

            if(ss[i].includes('tekst')==false || ss[i].includes('sifra_studenta')==false ||  ss[i].includes('ocjena')==false) 
                {
                    nadjiGreskuSadrzaja = true;
                }
            }
                   // sadrzaj.sifra_studenta[0]=="" || sadrzaj.tekst[0]==""|| sadrzaj.ocjena[0]==""
    if(spp.length<1 || indeks.length <1 || nadjiGreskuSadrzaja==true)
    {
       
        res.json({message:"Podaci nisu u traženom formatu!",data:null});
        
    }
    else{
       
        fs.appendFile(datotekica, sad,function(err){
            res.json({message:"Uspješno kreirana datoteka!",data:bod['sadrzaj']});
        });
        
    }
}
else{
    res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!",data:null}));
}
});
app.post('/lista',function(req,res){
    if(req.session.permisija==3){
    var bod = req.body;
    
    var god = bod['godina'];
    var niz = bod['nizRepozitorija'];

    var kljucevi = Object.keys(bod);
    if(!kljucevi.includes('godina') || !kljucevi.includes('nizRepozitorija')){
        res.json({message:"Podaci nisu u traženom formatu", data:null});
    }
    var datotekica = 'spisak' + bod['godina'] + '.txt';
    var niz2 = "";

    var link;
    var brojRedova = 0;
    var niz11 = niz.replace("[","");
    var niz111 = niz11.replace("]","");
    var niz22 = niz111.replace("\'","|");
    var niz1 = niz22.split(',');
    for(var i = 0; i< niz1.length;i++){
        link = niz1[i];
        //console.log(niz1[i] + "  " + link + "  godina:  " + god);
        if(link.includes(god) == true){
            var konacni = "";
            for(var j=0;j<link.length;j++){
                if(j>0 && j<link.length-1){
                    konacni = konacni + link[j];
                }
            }
            niz2 = niz2 + konacni + "\n";
            brojRedova++;
        }
    }
    if(god.length<1 || niz.length<1){
        res.json({message:"Podaci nisu u traženom formatu!", data:null });

    }
    else{
        fs.writeFile(datotekica, niz2, function(err){
            res.json({message:"Lista uspješno kreirana!",data:brojRedova});
        });
    }
}
else{
    res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!",data:null}));
}
});
app.post('/izvjestaj',function(req,res){
    if(req.session.permisija==3){
    let bod = req.body;
    let datotekica = 'izvjestajS' + bod['spirala'] + bod['index'] + '.txt';

    //console.log("Datotekica    "+ datotekica);

    let spp = bod['spirala'];
    let indeks = bod['index'];

    let ime = path.join(__dirname+ "/spisakS"+ spp+".json");
    let spisak = './spisakS'+ spp + '.json';
    let p = "./";
    let nadjeniFajl;
    let sadrzajDatoteke;
    let traziIndeks;
    let jedanRed;
    let konacniKomentari="";
    let finalniNiz = "";
    var nekiBrojac = 0;
    fs.readdir(p, function(err,files){
        
            if(files.includes('spisakS'+ spp + '.json')){
                nadjeniFajl = 'spisakS'+ spp + '.json';
               // console.log("Nadjeni fajl    " + nadjeniFajl);
                //console.log(err);
                fs.readFile(ime,  function(err,data){
                    //console.log(err);
                    if(err){
                         throw err;
                     }
                         sadrzajDatoteke = data.toString();
                         //console.log("Sadrzaj   " + sadrzajDatoteke);
                         var s1 = sadrzajDatoteke.replace(/[[]/g,"");
                         
                         var s2 = s1.replace(/["]/g, "");
                         
                        var s3 = s2.replace(/[\]]/g, "|");
                        
                        var sviRedovi = s3.split("|,");
                         var broj;
                         var elReda;
                         var jedanRed;
                        // res.json({message:"sveukupno  " + s3  + "Sadrzaj1   " + jedanRed[0] + " sadrzaj 4  " +jedanRed[1] });
                         for(var i = 0; i<sviRedovi.length;i++){
                             jedanRed = sviRedovi[i];
                             elReda = jedanRed.split(',');
                             for(var j = 1; j<elReda.length;j++){
                                 traziIndeks = elReda[j];
                                 if(traziIndeks == indeks && j!=elReda.length-1){
                                     if(j==1){
                                         broj = "A";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     if(j==2){
                                         broj = "B";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     if(j==3){
                                         broj = "C";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     if(j==4){
                                         broj = "D";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     if(j==5){
                                         broj = "E";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     
                                 }
                                 if(traziIndeks == indeks && j==jedanRed.length-1){
                                     konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj;
                                 }
                             }
                            
                            
                            var nazivvv = "";
                            var konn = konacniKomentari.split(",");
                            for(var k = 0; k<konn.length-1;k++){
                                var trazeni = konn[k];
                                var trazeni2 = trazeni.split('|');
                                var indeksic = trazeni2[0];
                                var sifrica = trazeni2[1];
                                var sadrzaaaj;
                                var jsonOblik;
                                var sadrzaaaj1;

                                var br=0 ;
                               
                                if(files.includes('markS'+ spp + indeksic + '.json' )){
                                    
                                    fs.readFile('./markS'+spp+indeksic+'.json',function(err,data){
                                        if(err){
                                            throw err;
                                        }
                                        //console.log("Datoteka se zove " + spp + indeksic + "////");
                                        sadrzaaaj = data.toString();
                                        
                                        var s5 = sadrzaaaj.replace(/[[{]/g, "");
                                        
                                        var s6 = s5.replace(/[}]]/g, "");
                                        //console.log("varijabla s6:  " + s6 + "\n");
                                       
                                        sadrzaaaj1 = s6.split('},');
                                        //console.log("varijabla sadrzaaaj1:  " + sadrzaaaj1[0] + "\n");
                                        var brojRedaBroj;
                                        if(sifrica=="A"){
                                            brojRedaBroj = 0;
                                        }
                                        if(sifrica=="B"){
                                            brojRedaBroj = 1;
                                        }
                                        if(sifrica=="C"){
                                            brojRedaBroj = 2;
                                        }
                                        if(sifrica=="D"){
                                            brojRedaBroj = 3;
                                        }
                                        if(sifrica=="E"){
                                            brojRedaBroj = 4;
                                        }
                                        
                                            var nesto = sadrzaaaj1[brojRedaBroj];
                                            //console.log("To nesto" + nesto + "Sifrica   " + sifrica + "brojreda broj   " + brojRedaBroj);
                                            var nesto1 = nesto.split(',');
                                            
                                                var nesto2 = nesto1[1];
                                                var nesto3 = nesto2.split(':');
                                                var nesto4 = nesto3[1].replace(/[']/g, "");
                                                
                                        
                                        
                                        nekiBrojac++;
                                        if(nesto4==""&& nekiBrojac <  5) {
                                            finalniNiz = finalniNiz + "\r\n" + "##########"+ "\r\n";
                                        }
                                        else if(nesto4!= "" && nekiBrojac <  5){
                                            finalniNiz = finalniNiz+ nesto4 + "\r\n" + "##########" + "\r\n";
                                        }
                                        else if(nekiBrojac==5){
                                            finalniNiz = finalniNiz+ nesto4;
                                            fs.appendFile('izvjestajS'+spp+indeks,finalniNiz ,function(err){
                                                if(err) throw err;
                                                
                                                res.setHeader('Content-disposition', 'attachment; filename='+'izvjestajS'+spp+indeks+'.txt');
                                                res.setHeader('Content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                                                
                                                res.download('izvjestajS'+spp+indeks+'.txt');
                                
                                            })
                                        }
                                        else{
                                            
                                        }
                                       
                                        
                                    });
                                }
                               
                            }

                        }


                 });
            }
        
   
    });
}
else{
    res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!",data:null}));
}
    
    
    
});
app.post('/register',function(req,res){
    var bod = req.body;
    var imePrezimeS = xssFilters.inHTMLData(bod.imePrezimeS);
    var index = xssFilters.inHTMLData(bod.brojIndexa);
    var grupa = xssFilters.inHTMLData(bod.grupa);
    var akademskaGodina = xssFilters.inHTMLData(bod.akademskaGodina);
    var usernameS = xssFilters.inHTMLData(bod.usernameS);
    var passwordS = xssFilters.inHTMLData(bod.passwordS);
    var confirmPassS = xssFilters.inHTMLData(bod.confirmPassS);
    var bitBucketUrl = xssFilters.inHTMLData(bod.bitBucketUrl);
    var bitbucketSsh = xssFilters.inHTMLData(bod.bitbucketSsh);
    var nazivRepozitorija = xssFilters.inHTMLData(bod.nazivRepozitorija);
    var fakultetskiMail = xssFilters.inHTMLData(bod.fakultetskiMail);

    var imePrezimeN = xssFilters.inHTMLData(bod.imePrezimeN);
    var usernameN = xssFilters.inHTMLData(bod.usernameN);
    var passwordN = xssFilters.inHTMLData(bod.passwordN);
    var confirmPassN = xssFilters.inHTMLData(bod.confirmPassN);
    var maksimalniBrojGrupa = xssFilters.inHTMLData(bod.maksimalniBrojGrupa);
    var regexZaValidaciju = xssFilters.inHTMLData(bod.regexZaValidaciju);
    var trenutniSemestar = xssFilters.inHTMLData(bod.trenutniSemestar);

    var akGodina = xssFilters.inHTMLData(bod.akGodina);

    var rolaa = xssFilters.inHTMLData(bod.rolaa);
    
    if(rolaa=="student"){
        if(passwordS === confirmPassS){
            bcrypt.hash(passwordS, 10, function(err, hash){
                licni_podaci.create({                    
                    imePrezime:imePrezimeS,
                    brojIndexa:index,
                    grupa:grupa,
                    akademskaGodina:akademskaGodina,
                    bitbucketUrl:bitBucketUrl,
                    bitbucketSsh:bitbucketSsh,
                    nazivRepozitorija:nazivRepozitorija,
                    fakultetskiMail:fakultetskiMail,
                    maksimalniBrojGrupa:maksimalniBrojGrupa,
                    regexZaValidaciju:regexZaValidaciju,
                    trenutniSemestar: trenutniSemestar,
                    verified : null
                 }).then(function(nestooo){
              
                    korisnik.create({
                        korisnickoIme:usernameS,
                        sifra:hash,
                        licniId:nestooo.Lid,
                        rolaId:2
                       
            });
            res.send(JSON.stringify({message:"Unesen novi student!", data:nestooo }));
            //res.send("Moze moze");
                }).catch(function(err){
                    res.send(err);
                });
            });
        }
        else{
            res.json({message:"Nije ista šifra!", data:null});         }
    }
    else if(rolaa=="nastavnik"){
        if(passwordN === confirmPassN){
            bcrypt.hash(passwordN, 10, function(err, hash){
                licni_podaci.create({
                    imePrezime:imePrezimeN,
                    brojIndexa:index,
                    grupa:grupa,
                    akademskaGodina:akGodina,
                    bitbucketUrl:bitBucketUrl,
                    bitbucketSsh:bitbucketSsh,
                    nazivRepozitorija:nazivRepozitorija,
                    fakultetskiMail:fakultetskiMail,
                    maksimalniBrojGrupa:maksimalniBrojGrupa,
                    regexZaValidaciju:regexZaValidaciju,
                    trenutniSemestar: trenutniSemestar,
                    verified : false
                 }).then(function(nestooo){
                    korisnik.create({
                        korisnickoIme:usernameN,
                        sifra:hash,
                        licniId:nestooo.Lid,
                        rolaId:3
            });
            //res.send("Moze moze");
            res.send(JSON.stringify({message:"Unesen novi nastavnik!", data:nestooo }));
                }).catch(function(err){
                    res.send(err);
                });
            });
        }
        
        else{
        
            res.json({message:"Nije ista šifra!", data:null});       }
    }
    else{
        res.json({message:"Korisnik nije nastavnik ni student!", data:null});  
    }

});
app.post('/login',function(req,res){
    var bod = req.body;
    var kime = xssFilters.inHTMLData(bod.korisnickoIme);
    var sifra = xssFilters.inHTMLData(bod.sifra);
    korisnik.findOne({
        where:{
            korisnickoIme:kime
        }
    }).then(function(lista){
        if(lista!=null){
            var novi = lista.dataValues;
           bcrypt.compare(sifra, novi.sifra, function(err,podaci){
                if(err) throw err;
                if(podaci==true){
                    if(novi.rolaId==1){
                        req.session.permisija=novi.rolaId;
                        res.json({message:"Ovo je admin!", data:novi});
                       
                    }
                    else{
                        licni_podaci.findOne({
                            where:{
                                Lid: novi.licniId
                               
                            }
                            
                        }).then(function(p){
                            if(p.verified == null || p.verified == true){
                           
                                req.session.permisija = novi.rolaId;
                                res.json({message:"Ovo nije admin!", data:novi});
                                
                                    }
                                    else{
                                        res.json({message:"Nije verifikovan!", data:null});
                                        res.end();
                                    }
                        })
                    }
                    
                    
                   
                
            }
            else{
                res.json({message:"Password nije tačan!", data:null});
                res.end();
                }
            })

        }
        else{
            res.json({message:"Pogešno korisničko ime!", data:null});
            res.end();
            
        }
       
    })
});

app.get('/listaKorisnika',function(req,res){
    if(req.session.permisija == 1){
    var korisnikk ;
    var ajdi;
    var kime=[];
    var k; 
    var konacni=''; 
        licni_podaci.findAll({
            where:{
                Lid: {
                    [Op.gte]: 1
                  }
            }
            
        }).then(function(listaa){
            
            if(listaa.length!=0){
                korisnik.findAll({
                    where:{
                        id: {
                            [Op.gte]: 1
                          }
                    }
                }).then(function(l){
                  
                    res.send(JSON.stringify({data:listaa, korisnici:l}));
                    
                });
                

                
            }
           
            else{
                res.send(JSON.stringify({message:"Ne postoji nijedan korisnik u listi!"}));
            }
            
        })
    }
    else{
        res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
    }
      
       
       
});

app.get('/listaKorisnika/:pretragaText',function(req,res){
    if(req.session.permisija==1){
    var pretragaText = xssFilters.inHTMLData(req.params.pretragaText);
    var ajdi;
    var ajdi1;
    var ajdi2;
  
    
    korisnik.findOne({
        where:{
            korisnickoIme: pretragaText
            }
    }).then(function(fun){
        if(fun!=null){
       
           ajdi = fun.korisnickoIme;
            ajdi1 = fun.licniId;
            ajdi2 = fun.rolaId;
            licni_podaci.findOne({
                where:{
                    Lid: ajdi1
                    }
            }).then(function(novi){
         
                res.send(JSON.stringify({message:"Podaci za traženog korisnika su prikazani ispod!", data:ajdi2, licni: novi,ime:ajdi}));
            });
           // res.send(JSON.stringify({message:"Podaci za traženog korisnika su prikazani ispod!", data:fun}));
        }
        else{
            res.send(JSON.stringify({message:"Korisnik nije u bazi!",data:null}));
            
        }
    });
}
else{
    res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
}
   



});

app.get('/verify/:a',function(req,res){
    if(req.session.permisija==1){
    var ajdi = req.params.a;
    var ime;
    var idd;
  
    licni_podaci.findOne({
        where: 
        { 
            Lid: ajdi
        }
    }).then(function(rez){
        if(rez!=null){
            rez.update({
                verified:true
            })
            res.send(JSON.stringify({message:"Korisnik " +" je sada verificiran!" }))
        }
        else{
            res.send(JSON.stringify({message:"Korisnika nema u bazi!"}));
        }
    })
}
else{
    res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
}
});
app.get('/unverify/:ajdi',function(req,res){
    if(req.session.permisija==1){
    var ajdi = req.params.ajdi;
    var ime;
    var idd;
    
    licni_podaci.findOne({
        where: 
        { 
            Lid: ajdi
        }
    }).then(function(rez){
        if(rez!=null){
            ime = rez.imePrezime;
            rez.update({
                verified:false
            })
            res.send(JSON.stringify({message:"Korisnik " +" je sada odverificiran!" }))
        }
        else{
            res.send(JSON.stringify({message:"Korisnika nema u bazi!"}));
        }
    })
}
else{
    res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!"}));
}
});
app.post('/bodovi',function(req,res){
    if(req.session.permisija==3){
    let bod = req.body;
    let datotekica = 'izvjestajS' + bod['spirala'] + bod['index'] + '.txt';

    let spp = bod['spirala'];
    let indeks = bod['index'];

    let ime = path.join(__dirname+ "/spisakS"+ spp+".json");
    let spisak = './spisakS'+ spp + '.json';
    let p = "./";
    let nadjeniFajl;
    let sadrzajDatoteke;
    let traziIndeks;
    let jedanRed;
    let konacniKomentari="";
    let finalniNiz = "";
    var nekiBrojac = 0;
    var ocjeneZbir = 0;
    fs.readdir(p, function(err,files){
        
            if(files.includes('spisakS'+ spp + '.json')){
                nadjeniFajl = 'spisakS'+ spp + '.json';
               // console.log("Nadjeni fajl    " + nadjeniFajl);
                //console.log(err);
                fs.readFile(ime,  function(err,data){
                    //console.log(err);
                    if(err){
                         throw err;
                     }
                         sadrzajDatoteke = data.toString();
                         //console.log("Sadrzaj   " + sadrzajDatoteke);
                         var s1 = sadrzajDatoteke.replace(/[[]/g,"");
                         
                         var s2 = s1.replace(/["]/g, "");
                         
                        var s3 = s2.replace(/[\]]/g, "|");
                        
                        var sviRedovi = s3.split("|,");
                         var broj;
                         var elReda;
                         var jedanRed;
                        // res.json({message:"sveukupno  " + s3  + "Sadrzaj1   " + jedanRed[0] + " sadrzaj 4  " +jedanRed[1] });
                         for(var i = 0; i<sviRedovi.length;i++){
                             jedanRed = sviRedovi[i];
                             elReda = jedanRed.split(',');
                             for(var j = 1; j<elReda.length;j++){
                                 traziIndeks = elReda[j];
                                 if(traziIndeks == indeks && j!=elReda.length-1){
                                     if(j==1){
                                         broj = "A";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     if(j==2){
                                         broj = "B";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     if(j==3){
                                         broj = "C";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     if(j==4){
                                         broj = "D";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     if(j==5){
                                         broj = "E";
                                         konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj + ",";
                                     }
                                     
                                 }
                                 if(traziIndeks == indeks && j==jedanRed.length-1){
                                     konacniKomentari = konacniKomentari + elReda[0] + "|"+ broj;
                                 }
                             }
                            
                            
                            var nazivvv = "";
                            var konn = konacniKomentari.split(",");
                            for(var k = 0; k<konn.length-1;k++){
                                var trazeni = konn[k];
                                var trazeni2 = trazeni.split('|');
                                var indeksic = trazeni2[0];
                                var sifrica = trazeni2[1];
                                var sadrzaaaj;
                                var jsonOblik;
                                var sadrzaaaj1;

                                var br=0 ;
                               
                                if(files.includes('markS'+ spp + indeksic + '.json' )){
                                    
                                    fs.readFile('./markS'+spp+indeksic+'.json',function(err,data){
                                        if(err){
                                            throw err;
                                        }
                                        //console.log("Datoteka se zove " + spp + indeksic + "////");
                                        sadrzaaaj = data.toString();
                                        
                                        var s5 = sadrzaaaj.replace(/[[{]/g, "");
                                        
                                        var s6 = s5.replace(/[}]]/g, "");
                                        //console.log("varijabla s6:  " + s6 + "\n");
                                       
                                        sadrzaaaj1 = s6.split('},');
                                        //console.log("varijabla sadrzaaaj1:  " + sadrzaaaj1[0] + "\n");
                                        var brojRedaBroj;
                                        if(sifrica=="A"){
                                            brojRedaBroj = 0;
                                        }
                                        if(sifrica=="B"){
                                            brojRedaBroj = 1;
                                        }
                                        if(sifrica=="C"){
                                            brojRedaBroj = 2;
                                        }
                                        if(sifrica=="D"){
                                            brojRedaBroj = 3;
                                        }
                                        if(sifrica=="E"){
                                            brojRedaBroj = 4;
                                        }
                                        
                                            var nesto = sadrzaaaj1[brojRedaBroj];
                                            //console.log("To nesto" + nesto + "Sifrica   " + sifrica + "brojreda broj   " + brojRedaBroj);
                                            var nesto1 = nesto.split(',');
                                            
                                                var nesto2 = nesto1[2];
                                                var nesto3 = nesto2.split(':');
                                                var nesto4 = nesto3[1].replace(/[']/g, "");
                                                ocjeneZbir = ocjeneZbir + parseFloat(nesto4);
                                        
                                       
                                        
                                    });
                                }
                               
                            }

                        }
                        var konacneOcjene = Math.trunc(ocjeneZbir/5);
                        res.send(JSON.stringify({poruka: "Student " + indeks + " je ostvario u prosjeku " + konacneOcjene + " mjesto."}));


                 });
            }
        
   
    });
}
else{
    res.send(JSON.stringify({message:"Nemate dozvolu za pristup ovoj stranici!",data:null}));
}


});
app.listen(process.env.PORT||3000);