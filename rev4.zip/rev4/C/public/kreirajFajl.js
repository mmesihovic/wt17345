var KreirajFajl=(function(){
    var indeksic;
    var spiralaa;

   
    var generisiIzvjestaj = function(){
        indeksic = document.getElementById("indeks").value;
        spiralaa = document.getElementById("spirala").value;
        KreirajFajl.kreirajIzvjestaj(spiralaa,indeksic,fnCallback(error,data));
    }
    var generisiBodove = function(){
        indeksic = document.getElementById("indeks").value;
        spiralaa = document.getElementById("spirala").value;
        KreirajFajl.kreirajBodove(spiralaa,indeksic,fnCallback(error,data));
    }
    var generisiKomentar = function(){
        var indeksic = document.getElementById("indexMoj").value;
        var spiralaa = document.getElementById("unosSpirale").value;

        var kom1 = document.getElementById("komentar1").value;
        var kom2 = document.getElementById("komentar2").value;
        var kom3 = document.getElementById("komentar3").value;
        var kom4 = document.getElementById("komentar4").value;
        var kom5 = document.getElementById("komentar5").value;

        var o1 = document.getElementById("ocjena1").value;
        var o2 = document.getElementById("ocjena2").value;
        var o3 = document.getElementById("ocjena3").value;
        var o4 = document.getElementById("ocjena4").value;
        var o5 = document.getElementById("ocjena5").value;

        var s1 = document.getElementById("sifra1").value;
        var s2 = document.getElementById("sifra2").value;
        var s3 = document.getElementById("sifra3").value;
        var s4 = document.getElementById("sifra4").value;
        var s5 = document.getElementById("sifra5").value;

        var saadrzaj = "[{'sifra_studenta':'" + s1 + "','tekst:':'" + kom1 + "','ocjena':" + o1 + "}," 
        + "{'sifra_studenta':'" + s2 + "','tekst':'" + kom2 + "','ocjena':" + o2 + "},"
        + "{'sifra_studenta':'" + s3 + "','tekst':'" + kom3 + "','ocjena':" + o3 + "},"
        + "{'sifra_studenta':'" + s4 + "','tekst':'" + kom4 + "','ocjena':" + o4 + "},"
        + "{'sifra_studenta':'" + s5 + "','tekst':'" + kom5 + "','ocjena':" + o5 + "}]";


        function fun_fun(error,data){
            if(data!=null && error==null){
                
                    if(data!=null){
                        if(data!=null && !error){
                           alert("Kreirana datoteka!");
                        }
                        else{
                            alert("Greška! Datoteka nije kreirana!");
           
                        }
                    
                    
                }
            }
        }
        KreirajFajl.kreirajKomentar(spiralaa,indeksic,saadrzaj,fun_fun);
        
    }
return {
    generisiKomentar:generisiKomentar,
    generisiIzvjestaj:generisiIzvjestaj,
    generisiBodove:generisiBodove,

kreirajKomentar : function(spirala, index, sadrzaj, fnCallback){
    var sp = spirala;
    var ind = index;
    var sadr = sadrzaj.toString();
    
    var xmlhttp = new XMLHttpRequest();
   
    xmlhttp.onreadystatechange = function(){
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
                { 
                    error = null;
                    data = xmlhttp.responseText;
                    if(data!=null){
                        
                        fnCallback(error,data)
                         }
                }
                else{
                    error = xmlhttp.status;
                    data = xmlhttp.responseText;
                } 
                alert(JSON.parse(data).message);               
            }
            var nadjiGreskuSadrzaja= false;
            sadr.replace("},{", "|");
            var ss = sadr.split('|');
            for(var i = 0; i < ss.length; i ++)
                    {
                        if(ss[i].includes('tekst')==false || ss[i].includes('sifra_studenta')==false ||  ss[i].includes('ocjena')==false) 
                        {
                           nadjiGreskuSadrzaja = true;
                        }
                    }
            if(sp.length<1 || ind.length <1 || nadjiGreskuSadrzaja==true){
                error = -1;
                data = 'Neispravni parametri';
                fnCallback(error,data);
        
            }
            else{
                xmlhttp.open("POST", "/komentar",true);
                xmlhttp.setRequestHeader("Content-Type", "application/json");
                xmlhttp.send(JSON.stringify({spirala :spirala, index:index, sadrzaj:sadrzaj}));
            }
},
kreirajListu : function(godina, nizRepozitorija, fnCallback){
    var g = godina;
    var niz = nizRepozitorija;   
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
                {               
                    error = null;
                    data = xmlhttp.responseText;
                    if(data!=null){fnCallback(error,data)}
                    }
                
                else{
                    error = xmlhttp.status;
                    data = xmlhttp.responseText;
                }    
                alert(JSON.parse(data).message);         
            }
        
        if(godina.length<1 || nizRepozitorija.length<1){
            error = -1;
            data = "Neispravni parametri";
            fnCallback(error,data);
        }
            else{

                xmlhttp.open("POST", "/lista",true);
                xmlhttp.setRequestHeader("Content-Type", "application/json");
                xmlhttp.send(JSON.stringify({godina: godina, nizRepozitorija: nizRepozitorija}));       
    }
   
},
kreirajIzvjestaj : function(spirala,index, fnCallback){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
                {                 
                    error = null;
                    data = xmlhttp.responseText;
            if(data!=null){fnCallback(error,data);}
                }
                else{error = xmlhttp.status;
                    data = xmlhttp.responseText;}
                    alert(JSON.parse(data).message);
                    
                }
        
    
        if(index.length<1 || index == null || spirala == null){
            error = -1;
            data = "Neispravni parametri";
            fnCallback(error,data);
        }
        else{
            xmlhttp.open("POST", "/izvjestaj",true);
            xmlhttp.setRequestHeader("Content-Type", "application/json");
            xmlhttp.send(JSON.stringify({spirala: spirala, index: index}));
        }
},
kreirajBodove : function(spirala,index, fnCallback){
  
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
                {                 
                    error = null;
                    data = xmlhttp.responseText;
            if(data!=null){
                fnCallback(error,data);}
                }
                else{error = xmlhttp.status;
                    data = xmlhttp.responseText;}   
                    alert(JSON.parse(data).message);                
                } 
        if(index.length<1 || index == null || spirala == null){
            error = -1;
            data = "Neispravni parametri";
            
            fnCallback(error,data);
        }
        else{
            xmlhttp.open("POST", "/bodovi",true);
            xmlhttp.setRequestHeader("Content-Type", "application/json");
            xmlhttp.send(JSON.stringify({spirala: spirala, index: index}));
        }
   // var text = "{'spirala':" + spirala + "',,'index':'" + index+ "'}";
       // xmlhttp.send(JSON.stringify({spirala:spirala,index:index}));
    }
}
})();