function uradiSubmit(){
                
  //var brojRedova = document.getElementById('tekst').rows;
    var brojSpirale = document.getElementById('brojBox').value;
    let textArea = document.getElementById('tekst').value;
    
    if(textArea==""){
        alert("Unijeti spisak indeksa!");
    }
    if(brojSpirale==""){
        alert("Unijeti broj spirale!");
    }
    var brojReda = 0;
    var indeks="";
    var validniString = textArea;
    var greska = false;
    let redPoRed = textArea.split('\n');
    var jsonVrijednost = [];
    //document.getElementById("tekst").value.split('\n');
    
    for(var i = 0;i < redPoRed.length;i++){
        if(redPoRed[i].length!=35) {
            greska = true;
            brojReda = i+1;
            alert("Greska u redu " + brojReda.toString);
        }
        else{
            var redic = redPoRed[i];
            var mojNiz = new StringArray(6);
            for(var j=0;j<redPoRed[i].length;j++){
                if(redic[j]==","){
                    indeks = "";
                }
                else{
                indeks = indeks + redic[i];
                if(indeks.length==5 && indeks.slice(0,1)=="1" && provjeriJeLiBroj(indeks)==true){
                    mojNiz.push(indeks);
                    if(mojNiz.length==6){
                        for(var k=0;k<mojNiz.length;k++){
                            var provjeri = mojNiz[k];
                            var prebroji = mojNiz.count(provjeri);
                            if(prebroji!=1){
                               greska=true;
                            }
                            else{
                                greska = false;
                                finalniJSON.push(indeks);
                            }
                        }
                    }
                    }
                    else{
                        greska = true;
                    }
                }
            }
        }
        
    }
    if(greska==true){
        alert('Nije kreirano.');
    }
    else{
        var data = []
    data.table = []
    for (var k1=0; k1 <finalniJSON.length ; k1+6){
       var obj = {
           X : finalniJSON[k1],
           A : finalniJSON[k1+1],
           B : finalniJSON[k1+2],
           C : finalniJSON[k1+3],
           D : finalniJSON[k1+4],
           E : finalniJSON[k1+5]
       }
       data.table.push(obj)
    }
    fs.writeFile ("spisakS"+brojSpirale+".json", JSON.stringify(data), function(err) {
        if (err) throw err;
        alert('Datoteka je kreirana');
        }
    );
       var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {
        if (ajax.status == 200){
            error = null;
            data = ajax.responseText;
        }
        else{
            error = ajax.status;
            data = ajax.responseText;
        }
    }
    ajax.open("POST", "/unesiSpisak", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify({brojSpirale: brojSpirale, sadrzaj: data}));
    var fs = require('fs');

    
}
}
    function provjeriJeLiBroj(broj){
        var provjeri = broj.toString;
        for(var i=0; i<provjeri.length;i++){
            if(provjeri[i]<"0" || provjeri[i]>"9"){
                return false;
            }
        }
        return true;
    }