const Sequelize = require("sequelize");
//const sequelize = require("./mojaBaza.js");



module.exports = function(sequelize,DataTypes){
    const rola = sequelize.define('rola',{
        Rid:{
             type:Sequelize.INTEGER,
             autoIncrement:true,
             primaryKey:true,
             field:'Rid'
         },
         naziv:{
             type:Sequelize.STRING,
             field:'naziv'
         }
     });
    return rola;
}