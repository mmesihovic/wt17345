//korisnicko ime sifra
const Sequelize = require("sequelize");
//const sequelize = require("./mojaBaza.js");


module.exports = function(sequelize, DataTypes){
    const korisnik = sequelize.define('korisnik', {
        id:{
             type: Sequelize.INTEGER, 
             autoIncrement:true,
             primaryKey: true,
             field: 'id'
         },
         korisnickoIme: {
             type: Sequelize.STRING,
             field: 'korisnickoIme',
             allowNull: false
         },
         sifra: {
             type: Sequelize.STRING,
             field:'sifra',
             allowNull: false
         }
         
     });
    return korisnik;
    
}