const Sequelize = require("sequelize");
const sequelize = new Sequelize(
    'heroku_1639ca22011cd1c',
    'b03ae78b45a35a',
    '6a4103c0',
    {
        host:'us-cdbr-iron-east-05.cleardb.net',
        dialect:'mysql',
        pool: {
            max: 10,
            min: 0,
            aquire: 30000,
            idle:10000
        }
    }
);

module.exports = sequelize;