const Sequelize = require("sequelize");
//const sequelize = require("./mojaBaza.js");

module.exports = function(sequelize,DataTypes){
    const licni_podaci = sequelize.define('licni_podaci',{
        Lid:{
             type:Sequelize.INTEGER,
             autoIncrement: true,
             primaryKey:true,
             field:'Lid'
         },
     
         imePrezime: {
             type: Sequelize.STRING,
             field: 'imePrezime',
             allowNull: true
         },
         brojIndexa: {
             type: Sequelize.STRING,
             field:'brojIndeksa',
             allowNull: true
         },
         grupa:{
     
          type: Sequelize.STRING,
          field: 'grupa',
          allowNull: true
         },
         akademskaGodina:{
             type: Sequelize.STRING,
             field:'akademskaGodina',
             allowNull: true
         },
         bitbucketUrl: {
             type:Sequelize.STRING,
             field:'bitbucketUrl',
             allowNull: true
         },
         bitbucketSsh: {
             type :Sequelize.STRING,
             field:'bitbucketSsh',
             allowNull: true
         },
         nazivRepozitorija: {
             type: Sequelize.STRING,
             field: 'nazivRepozitorija',
             allowNull: true
         },
         fakultetskiMail: {
             type: Sequelize.STRING,
             field:'fakultetskiMail',
             allowNull: true
         },
         maksimalniBrojGrupa:{
             type:Sequelize.INTEGER,
             field:'maksimalniBrojGrupa',
             allowNull: true
         },
         regexZaValidaciju:{
             type:Sequelize.STRING,
             field:'regexZaValidaciju',
             allowNull: true
         },
         
         trenutniSemestar: {
             type : Sequelize.STRING,
             field: 'trenutniSemestar',
             allowNull: true
         },
         verified: {
             type: Sequelize.BOOLEAN,
             field:'verified',
             allowNull: true
         }
     });
        return licni_podaci;

}