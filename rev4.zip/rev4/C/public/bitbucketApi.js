var BitbucketApi = (function(){
return {
dohvatiAccessToken: function(key, secret, fnCallback){},
dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback){},
dohvatiBranch: function(token, url, naziv, fnCallback){}
}
})();