

 function otvoriLogin(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("glavniDio").innerHTML = ajax.responseText;
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";
    }
    ZatvoriSve();
    ajax.open("GET", "static/login.html", true);
    ajax.send();
    }
     //otvoriLogin: otvoriLogin;
var zadnjiKorisnik="student";
    function otvoriStatistiku(){
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {
            if (ajax.readyState == 4 && ajax.status == 200)
                document.getElementById("glavniDio").innerHTML = ajax.responseText;
            if (ajax.readyState == 4 && ajax.status == 404)
                document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";

                alert(JSON.parse(res).message);
        }
        ajax.open("GET", "static/statistika", true);
        ajax.send();
        }
    
        function otvoriUnosKomentara(){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("glavniDio").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";

                    alert(JSON.parse(res).message);

            }
            ajax.open("GET", "static/unoskomentara", true);
            ajax.send();
            }
         
    
        function otvoriunosSpiska(){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("glavniDio").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";

                    alert(JSON.parse(res).message);
            }
            ajax.open("GET", "static/unosSpiska", true);
            ajax.send();
            }
            function otvoriNastavnika(){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                    if (ajax.readyState == 4 && ajax.status == 200)
                        document.getElementById("glavniDio").innerHTML = ajax.responseText;
                    if (ajax.readyState == 4 && ajax.status == 404)
                        document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";

                        alert(JSON.parse(res).message);
                }
                ajax.open("GET", "static/nastavnik", true);
                ajax.send();
            }
            function otvoriBitBucketPozive(){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                    if (ajax.readyState == 4 && ajax.status == 200)
                        document.getElementById("glavniDio").innerHTML = ajax.responseText;
                    if (ajax.readyState == 4 && ajax.status == 404)
                        document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";

                        alert(JSON.parse(res).message);
                }
                ajax.open("GET", "static/bitbucketPozivi", true);
                ajax.send();
            }
            function registujStudenta(){
              var   n = document.getElementById('containerNastavnik');
               var  s = document.getElementById('containerStudent');
                n.style.display = "none";
                s.style.display = "block";
                zadnjiKorisnik = "student";
            }
            function registrujNastavnika(){
             var   n = document.getElementById('containerNastavnik');
              var  s = document.getElementById('containerStudent');
              zadnjiKorisnik = "nastavnik";
                n.style.display = "block";
                s.style.display = "none";
            }
            function registracija(){
                var xmlhttp = new XMLHttpRequest();
                var  n = document.getElementById('containerStudent');
                var rolaa;
                if(zadnjiKorisnik=="student"){
                 
                     rolaa = "student";
                    var imePrezimeS = document.getElementById('imePrezimeS').value;
                var brojIndexa = document.getElementById('index').value;
                var grupa = document.getElementById('grupa').value;
                var akademskaGodina = document.getElementById('akGodina').value;
                var bitBucketUrl = document.getElementById('bitBucketUrl').value;
                var bitbucketSsh = document.getElementById('bitBucketSsh').value;
                var nazivRepozitorija = document.getElementById('nazivRepozitorija').value;
                var passwordS = document.getElementById('passwordS').value;
                var passwordN = null;
                var confirmPassN = null;
                var confirmPassS = document.getElementById('confirmPassS').value;
                var usernameS = document.getElementById('usernameS').value;
                var usernameN = null;
                var imePrezimeN = null;
                var fakultetskiMail = null;
                var maksimalniBrojGrupa = null;
                var regexZaValidaciju = null;
                var trenutniSemestar = null;
               // var verifed=null;

                }
                else {
                    rolaa = "nastavnik";
                    var imePrezimeS = null;
                    var brojIndexa = null;
                    var grupa = null;
                    var akGodina = document.getElementById('akademskaGodina').value;
                    var akademskaGodina = null;
                    var bitBucketUrl = null;
                    var bitbucketSsh = null;
                    var nazivRepozitorija = null;
                    var passwordS =null;
                    var passwordN = document.getElementById('passwordN').value;
                    var confirmPassN = document.getElementById('confirmPassN').value;
                    var confirmPassS = null;
                    var usernameS = null;
                    var usernameN = document.getElementById('usernameN').value;
                    var imePrezimeN = document.getElementById('imePrezimeN').value;
                    var fakultetskiMail = document.getElementById('fakultetskiMail').value;
                    var maksimalniBrojGrupa = document.getElementById('maxGrupa').value;
                    var regexZaValidaciju = document.getElementById('validniRegex').value;
                    var trenutniSemestar = document.getElementById('trenutniSemestar').value;
                    //var verifed=false;
                }
                xmlhttp.onreadystatechange=function(){
                    if(xmlhttp.readyState == 4  && xmlhttp.status == 200){
                        alert(JSON.parse(xmlhttp.responseText).message);
                        document.getElementById("glavniDio").innerHTML = "";
                    }
                    else if(xmlhttp.readyState==4 && xmlhttp.status!=200){
                        document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";
                    }
                }
               
                xmlhttp.open("POST", "/register", true);
                xmlhttp.setRequestHeader("Content-Type", "application/json");
                xmlhttp.send(JSON.stringify({imePrezimeS:imePrezimeS,akGodina:akGodina,rolaa:rolaa,confirmPassN:confirmPassN,passwordN:passwordN,brojIndexa:brojIndexa,grupa:grupa,akademskaGodina:akademskaGodina,bitBucketUrl:bitBucketUrl,bitbucketSsh:bitbucketSsh,nazivRepozitorija:nazivRepozitorija,passwordS:passwordS,confirmPassS:confirmPassS,usernameS:usernameS,usernameN:usernameN,imePrezimeN:imePrezimeN,fakultetskiMail:fakultetskiMail,maksimalniBrojGrupa:maksimalniBrojGrupa,regexZaValidaciju:regexZaValidaciju,trenutniSemestar:trenutniSemestar}));
                
            }
            function  ZatvoriSve(){
                document.getElementById("statistikaMeni").style.visibility = "hidden";
                document.getElementById("unosKomentaraMeni").style.visibility = "hidden";
                document.getElementById("loginMeni").style.visibility = "visible";
                document.getElementById("listaKorisnikaMeni").style.visibility = "hidden"; 
                document.getElementById("unosSpiskaMeni").style.visibility = "hidden";
                document.getElementById("nastavnikMeni").style.visibility = "hidden";
                document.getElementById("bitbucketMeni").style.visibility = "hidden";
            }
         function LoginPocetni(){
                var xmlhttp = new XMLHttpRequest();
                var korisnickoIme = document.getElementById('korisnicko_ime').value;
                var sifra = document.getElementById('sifra').value;
                
                xmlhttp.onreadystatechange = function(){
                    if(xmlhttp.readyState === 4 && xmlhttp.status === 200){

                        var odgovor = (xmlhttp.responseText);
                    if(JSON.parse(odgovor).data!=null){

                        if(JSON.parse(odgovor).data.rolaId == 2){
                            document.getElementById("statistikaMeni").style.visibility = "visible";
                            document.getElementById("unosKomentaraMeni").style.visibility = "visible";
                            document.getElementById("loginMeni").style.visibility = "visible";
                            document.getElementById("listaKorisnikaMeni").style.visibility = "hidden"; 
                            document.getElementById("unosSpiskaMeni").style.visibility = "hidden";
                            document.getElementById("nastavnikMeni").style.visibility = "hidden";
                            document.getElementById("bitbucketMeni").style.visibility = "hidden";
                        }
                        else if(JSON.parse(odgovor).data.rolaId == 3){
                            document.getElementById("unosSpiskaMeni").style.visibility = "visible";
                            document.getElementById("nastavnikMeni").style.visibility = "visible";
                            document.getElementById("bitbucketMeni").style.visibility = "visible";
                            document.getElementById("loginMeni").style.visibility = "visible";
                            document.getElementById("statistikaMeni").style.visibility = "hidden";
                            document.getElementById("unosKomentaraMeni").style.visibility = "hidden";
                            document.getElementById("listaKorisnikaMeni").style.visibility = "hidden";
                        }
                        else if(JSON.parse(odgovor).data.rolaId == 1){
                            document.getElementById("listaKorisnikaMeni").style.visibility = "visible";
                            document.getElementById("loginMeni").style.visibility = "visible";

                            document.getElementById("statistikaMeni").style.visibility = "hidden";
                            document.getElementById("unosKomentaraMeni").style.visibility = "hidden";  
                            document.getElementById("unosSpiskaMeni").style.visibility = "hidden";
                            document.getElementById("nastavnikMeni").style.visibility = "hidden";
                            document.getElementById("bitbucketMeni").style.visibility = "hidden";
                        }
                        document.getElementById("glavniDio").innerHTML = "";
                    }
                        else{
                            var alert1 = JSON.parse(odgovor).message;
                            if(alert1!="Password nije tačan!") {
                                ZatvoriSve();
                                document.getElementById("glavniDio").innerHTML = "";
                                alert(JSON.parse(odgovor).message);
                            }
                            else{
                            alert(JSON.parse(odgovor).message);
                            }
                            
                        }
                        
                    }
                   
                    
                    
                }
                xmlhttp.open("POST", "/login", true);
                    xmlhttp.setRequestHeader("Content-Type", "application/json");
                    xmlhttp.send(JSON.stringify({korisnickoIme:korisnickoIme, sifra:sifra}));
            }
          function otvoriListuKorisnika(){
                var ajax = new XMLHttpRequest();
                
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    var odgovor = (ajax.responseText);
                    var licniPodaci = JSON.parse(odgovor).data;
                    var korisnici = JSON.parse(odgovor).korisnici;
            
                    var konacni = '<table id = "tabelicaKorisnika"><tr><td>ID</td><td><a id = "tabelaImeprezime">Ime i prezime</a></td><td><a id="tabelaKorisnickoIme">Korisničko ime</a></td><td>Verify</td></tr>';
                    var niz = [];
                    for(i=0;i<licniPodaci.length;i++){
                        for(j=0;j<korisnici.length;j++){
                            if(licniPodaci[i].Lid==korisnici[j].licniId){
                                var jedanRed = '<tr><td>' + korisnici[j].id + '</td>' + '<td>' + licniPodaci[i].imePrezime + '</td>' + '<td>' + korisnici[j].korisnickoIme +'</td>';
                                if(licniPodaci[i].verified == true){
                                    jedanRed = jedanRed + '<td><button id="unverifyBtn" onClick="unverify(' + korisnici[j].licniId + ')">Unverify</button></td>';
                                    niz.push(jedanRed);
                                }
                                else if(licniPodaci[i].verified == false){
                                    jedanRed = jedanRed + '<td><button id="verifyBtn" onClick="verify(' + korisnici[j].licniId + ')">Verify</button></td>';
                                    niz.push(jedanRed);
                                }
                                else{
                                    licniPodaci[i] = jedanRed + '<td></td>';
                                    niz.push(jedanRed);
                                }
                               
                            }
                        }
                    }
                    var ispis= '';
            for(i = 0;i<niz.length;i++){
                
                ispis = ispis + niz[i];
               
            }
            konacni = konacni + ispis + '</table><br><br>';
            konacni = konacni + '<input type= "text" id ="pretragaText"> <br>';
            konacni = konacni + '<button id = "pretragaBtn" onclick = traziKorisnika()>Traži</button>';
                   
                    document.getElementById("glavniDio").innerHTML = konacni;
                }
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";
            }
           
           ajax.open("GET", "/listaKorisnika" , true);
            ajax.send();
            }

            function traziKorisnika(){
                var xmlhttp = new XMLHttpRequest();
                var pretragaText = document.getElementById('pretragaText').value;
                xmlhttp.onreadystatechange = function(){
                    if(xmlhttp.status == 200 && xmlhttp.readyState == 4){
                        var odg = xmlhttp.responseText;
                        var kor = JSON.parse(odg).data;
                        var lic = JSON.parse(odg).licni;
                        var imee = JSON.parse(odg).ime;

                        var konacni = '<input id="pretragaText"><button id="traziiBtn" onclick=traziKorisnika()>Traži</button>';
                        konacni = konacni + '<br><br><table id="tabelicaKorisnika"><tr><td>Username</td><td>Rola</td><td>Verified</td></tr>';
                        konacni = konacni + '<tr><td>'+ imee + '</td><td>';
                        if(kor=='2'){
                           konacni = konacni + 'student'+'</td></tr></table>'  ;
                           document.getElementById('glavniDio').innerHTML = konacni;
                        } 
                        else if(kor=='3'){
                            konacni = konacni + 'nastavnik'+'</td>';
                            if(lic.verified==false){
                               konacni = konacni + '<td><button id="verifyBtn" onClick="verify(' + kor + ')">Verify</button></td></tr></table>'  ;
                            }
                            else{
                                konacni = konacni + '<td><button id="unverifyBtn" onClick="unverify(' + kor + ')">Unverify</button></td></tr></table>'  ;
                              
                            }
                            document.getElementById('glavniDio').innerHTML = konacni;
                         } 
                         else{
                           alert("Korisnik ne postoji!");
                           otvoriListuKorisnika();
                         }
                         //alert(JSON.parse(odg).message);
                        
                    }
                    if(xmlhttp.status == 404 && xmlhttp.readyState == 4){
                        document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";
                    }
                }
              
                xmlhttp.open("GET", "/listaKorisnika/" +pretragaText , true);
                xmlhttp.send();
            }
            function verify(ajdi)
            {
              
                var a = ajdi;
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200){
                        var res = xmlhttp.responseText;
                       
                        alert(JSON.parse(res).message);
                        otvoriListuKorisnika();

                    }
                    if(xmlhttp.status == 404 && xmlhttp.readyState == 4){
                        document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";
                    }
                }
                xmlhttp.open("GET","/verify/"+a,true);
                xmlhttp.send();
            }
            function unverify(ajdi)
            {
              
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200){
                        var res = xmlhttp.responseText;
                        alert(JSON.parse(res).message);
                        otvoriListuKorisnika();
                    }
                    if(xmlhttp.status == 404 && xmlhttp.readyState == 4){
                        document.getElementById("glavniDio").innerHTML = "Error: Nepoznat URL!";
                    }
                }
                var a = ajdi;
                xmlhttp.open("GET","/unverify/"+a,true);
                xmlhttp.send();
            }


           
           
           