var Validacija = (function() {

  var maxGrupa = 7;
  var trenutniSemestar = 0; // 0 za zimski, 1 za ljetni semestar
  Poruke.postaviIdDiva("poljeGreske")
  return {
    validirajFakultetski: function validirajFakultetski(fakultetskiMail)
    {
      var regEx = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

      if (!regEx.test(fakultetskiMail)) {
        Poruke.dodajPoruku(0);
        Poruke.ispisiGreske();
        return false;
      }

      var domena = fakultetskiMail.slice(-11, 0);
      if (domena == "etf.unsa.ba") {
        Poruke.ocistiGresku(0);
        Poruke.ispisiGreske();
      }
      else {
        Poruke.dodajPoruku(0);
        Poruke.ispisiGreske();
      }
      return domena == "etf.unsa.ba";
    },
    validirajIndex: function validirajIndex(index)
    {
      var indexString = index.toString();
      if (indexString.length == 5 && indexString.slice(0, 1) == "1") {
        Poruke.ocistiGresku(1);
      } else {
        Poruke.dodajPoruku(1);
      }
      Poruke.ispisiGreske();
      return indexString.length == 5 && indexString.slice(0, 1) == "1";
    },
    validirajGrupu: function validirajGrupu(brojGrupe)
    {
      if (brojGrupe >= 1 && brojGrupe <= maxGrupa) {
        Poruke.ocistiGresku(2);
      } else {
        Poruke.dodajPoruku(2);
      }
      Poruke.ispisiGreske();
      return brojGrupe >= 1 && brojGrupe <= maxGrupa;
    },
    validirajAkGod: function validirajAkGod(akGodina)
    {
      // 20AB/20CD CD za 1 veci od AB
      // ako je zimski AB je trenutna godina, ako je ljetni CD je trenutna godina
      if (akGodina.slice(0, 2) != "20") {
        Poruke.dodajPoruku(3);
        Poruke.ispisiGreske();
        return false;
      }

      var datumGodina = new Date();
      datumGodina = datumGodina.getFullYear();
      var narednaGodina = datumGodina + 1;
      var prethodnaGodina = datumGodina - 1;

      if (trenutniSemestar == 0) {
        if (akGodina.slice(0, 4) == datumGodina.toString() && akGodina.slice(4, 5) == "/" && akGodina.slice(5, 9) == narednaGodina.toString()) {
          Poruke.ocistiGresku(3);
        } else {
          Poruke.dodajPoruku(3);
        }
        Poruke.ispisiGreske();
        return akGodina.slice(0, 4) == datumGodina.toString() && akGodina.slice(4, 5) == "/" && akGodina.slice(5, 9) == narednaGodina.toString();
      }
      if (akGodina.slice(0, 4) == prethodnaGodina.toString() && akGodina.slice(4, 5) == "/" && akGodina.slice(5, 9) == datumGodina.toString()) {
        Poruke.ocistiGresku(3);
      } else {
        Poruke.dodajPoruku(3);
      }
      Poruke.ispisiGreske();
      return akGodina.slice(0, 4) == prethodnaGodina.toString() && akGodina.slice(4, 5) == "/" && akGodina.slice(5, 9) == datumGodina.toString();
    },
    validirajPassword: function validirajPassword(password)
    {
      if (password.length < 7 || password.length > 20) {
        Poruke.dodajPoruku(4);
        Poruke.ispisiGreske();
        return false;
      }

      var maloSlovo = false;
      var velikoSlovo = false;
      var broj = false;

      for (var i = 0; i < niz.length; i++) {
        if (password.charCodeAt(i) >= 65 && password.charCodeAt(i) <= 90) {
          velikoSlovo = true;
        }
        else if (password.charCodeAt(i) >= 97 && password.charCodeAt(i) <= 122) {
          maloSlovo = true;
        }
        else if (password.charCodeAt(i) >= 48 && password.charCodeAt(i) <= 57) {
          broj = true;
        }
      }

      if (maloSlovo && velikoSlovo && broj) {
        Poruke.ocistiGresku(4);
        Poruke.ispisiGreske();
        return true;
      }
      Poruke.dodajPoruku(4);
      Poruke.ispisiGreske();
      return false;
    },
    validirajPotvrdu: function validirajPotvrdu(sifra1, sifra2)
    {
      if (!validirajPassword(sifra1) || !validirajPassword(sifra2)) {
        Poruke.dodajPoruku(5);
        Poruke.ispisiGreske();
        return false;
      }
      if (sifra1 == sifra2) {
        Poruke.ocistiGresku(5);
      } else {
        Poruke.dodajPoruku(5);
      }
      Poruke.ispisiGreske();
      return sifra1 == sifra2;
    },
    validirajBitbucketURL: function validirajBitbucketURL(urlRepo)
    {
      if (urlRepo.slice(0, 8) != "https://") {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      // mora postojati username
      if (urlRepo.charAt(8) == '@') {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      var niz = urlRepo.split("@");
      if (niz.length != 2) { // samo jedan @ moze biti u urlu
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      // https://username

      var username = niz[0].slice(8, niz[0].length);
      // posto za username nema ogranicenja, jedino je bitno da nije prazan
      if (username == "") {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      // @ postojanje znaka @ je vec provjereno, ali treba se uvjeriti da je na odgovarajucem mjestu

      if (urlRepo.charAt(8 + username.length) != '@') {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      // bitbucket.org/

      if (niz[1].slice(0, 14) != "bitbucket.org/") {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      // samo cemo provjeriti da postoji neki username2

      if (niz[1].charAt(14) == "/") {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      var noviNiz = niz[1].split("/");

      if (noviNiz.length != 3) {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      // provjeravamo postoji li username2, znam da je ovo dupla provjerava
      // medjutim neka je
      if (noviNiz[1] == "") {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      // provjeravamo sami kraj urla
      if (urlRepo.slice(-4, 0) != ".git") {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
        return false;
      }

      var nazivRepozitorija = noviNiz[2].slice(0, noviNiz[2].length - 4);
      if (validirajNazivRepozitorija(regEx, nazivRepozitorija)) {
        Poruke.ocistiGresku(6);
      } else {
        Poruke.dodajPoruku(6);
      }
      Poruke.ispisiGreske();
      return validirajNazivRepozitorija(regEx, nazivRepozitorija);
    },
    validirajBitbucketSSH: function validirajBitbucketSSH(adresaRepo)
    {
      // git@bitbucket.org:
      if (adresaRepo.slice(0, 18) != "git@bitbucket.org:") {
        Poruke.dodajPoruku(7);
        Poruke.ispisiGreske();
        return false;
      }

      var niz = adresaRepo.slice(18, adresaRepo.length).split("/");

      if (niz.length != 2) {
        Poruke.dodajPoruku(7);
        Poruke.ispisiGreske();
        return false;
      }

      if (niz[0] == "") {
        Poruke.dodajPoruku(7);
        Poruke.ispisiGreske();
        return false;
      }

      if (adresaRepo.charAt(18 + niz[0].length) != '/') {
        Poruke.dodajPoruku(7);
        Poruke.ispisiGreske();
        return false;
      }

      if (adresaRepo.slice(-4, 0) != ".git") {
        Poruke.dodajPoruku(7);
        Poruke.ispisiGreske();
        return false;
      }

      var nazivRepozitorija = niz[1].slice(0, niz[1].length - 4);
      if (validirajNazivRepozitorija(regEx, nazivRepozitorija)) {
        Poruke.ocistiGresku(7);
      } else {
        Poruke.dodajPoruku(7);
      }
      Poruke.ispisiGreske();
      return validirajNazivRepozitorija(regEx, nazivRepozitorija);
    },
    validirajNazivRepozitorija: function validirajNazivRepozitorija(regEx, nazivRepo)
    {
      if (regEx == null) {
        regEx=/^(wtProjekat1\d\d\d\d)|(wtprojekat1\d\d\d\d)$/g
      }
      if (regEx.test(nazivRepo)) {
        Poruke.ocistiGresku(8);
      } else {
        Poruke.dodajPoruku(8);
      }
      Poruke.ispisiGreske();
      return regEx.test(nazivRepo);
    },
    validirajImeiPrezime: function validirajImeiPrezime(imeIPrezime)
    {
      var niz = imeIPrezime.split(" ");

      if (niz.length != 2) {
        Poruke.dodajPoruku(9);
        Poruke.ispisiGreske();
        return false;
      }

      if ((niz[0].charCodeAt(0) >= 97 && niz[0].charCodeAt(0) <= 122) || (niz[1].charCodeAt(0) >= 97 && niz[1].charCodeAt(0) <= 122)) {
        Poruke.dodajPoruku(9);
        Poruke.ispisiGreske();
        return false;
      }

      // č, ć, dž, đ, š, ž, lj, nj
      if (niz[0].charCodeAt(0) == 269 || niz[0].charCodeAt(0) == 263 || niz[0].charCodeAt(0) == 454 || niz[0].charCodeAt(0) == 273
          || niz[0].charCodeAt(0) == 353 || niz[0].charCodeAt(0) == 382 || niz[0].charCodeAt(0) == 457 || niz[0].charCodeAt(0) == 460
          || niz[0].charCodeAt(0) == 39 || niz[0].charCodeAt(0) == 45) {
            Poruke.dodajPoruku(9);
            Poruke.ispisiGreske();
        return false;
      }

      if (niz[1].charCodeAt(0) == 269 || niz[1].charCodeAt(0) == 263 || niz[1].charCodeAt(0) == 454 || niz[1].charCodeAt(0) == 273
          || niz[1].charCodeAt(0) == 353 || niz[1].charCodeAt(0) == 382 || niz[1].charCodeAt(0) == 457 || niz[1].charCodeAt(0) == 460
          || niz[1].charCodeAt(0) == 39 || niz[1].charCodeAt(0) == 45) {
            Poruke.dodajPoruku(9);
            Poruke.ispisiGreske();
        return false;
      }

      for (var i = 0; i < niz[0].length; i++) {
        if ((niz[0].charCodeAt(i) < 65 || niz[0].charCodeAt(i) > 90) && (niz[0].charCodeAt(i) < 97 || niz[0].charCodeAt(i) > 122)
            && niz[0].charCodeAt(i) != 269 && niz[0].charCodeAt(i) != 263 && niz[0].charCodeAt(i) != 454 && niz[0].charCodeAt(i) != 273
            && niz[0].charCodeAt(i) != 353 && niz[0].charCodeAt(i) != 382 && niz[0].charCodeAt(i) != 457 && niz[0].charCodeAt(i) != 460) {
              Poruke.dodajPoruku(9);
              Poruke.ispisiGreske();
          return false;
        }
      }

      for (var i = 0; i < niz[1].length; i++) {
        if ((niz[1].charCodeAt(i) < 65 || niz[1].charCodeAt(i) > 90) && (niz[1].charCodeAt(i) < 97 || niz[1].charCodeAt(i) > 122)
            && niz[1].charCodeAt(i) != 269 && niz[1].charCodeAt(i) != 263 && niz[1].charCodeAt(i) != 454 && niz[1].charCodeAt(i) != 273
            && niz[1].charCodeAt(i) != 353 && niz[1].charCodeAt(i) != 382 && niz[1].charCodeAt(i) != 457 && niz[1].charCodeAt(i) != 460
            && niz[1].charCodeAt(i) != 39 && niz[1].charCodeAt(i) != 45) {
              Poruke.dodajPoruku(9);
              Poruke.ispisiGreske();
          return false;
        }
      }

      // bar jedna rijec od 3 do 12 slova
      if ((niz[0].length < 3 && niz[1].length < 3) || (niz[0].length > 12 && niz[1].length > 12)) {
        Poruke.dodajPoruku(9);
        Poruke.ispisiGreske();
        return false;
      }
      Poruke.ocistiGresku(9);
      Poruke.ispisiGreske();

      return true;
    },
    postaviMaxGrupa: function postaviMaxGrupa(maxGr)
    {
      maxGrupa = maxGr;
    },
    postaviTrenSemestar: function postaviTrenSemestar(trSem)
    {
      trenutniSemestar = trSem;
    }
  }
}());
