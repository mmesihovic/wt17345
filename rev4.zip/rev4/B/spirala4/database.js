var Sequelize = require("sequelize");
var sequelize = new Sequelize('projekatWT', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
      max: 10,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  });
  var database={};
  database.Sequelize = Sequelize;  
  database.sequelize = sequelize;
  database.korisnik = sequelize.import(__dirname+'/korisnik.js');
  database.role = sequelize.import(__dirname+'/rola.js');
  database.licniPodaci = sequelize.import(__dirname+'/licniPodaci.js');
  database.korisnik.belongsTo(database.role,{foreignKey:'id_role'});
  database.korisnik.belongsTo(database.licniPodaci,{foreignKey:'id_licniPodaci'});
module.exports = database;