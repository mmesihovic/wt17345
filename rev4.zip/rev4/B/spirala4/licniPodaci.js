var Sequelize = require("sequelize");
module.exports = function(sequelize,DataTypes){
    var LicniPodaci = sequelize.define("licniPodaci",{
        ime_i_prezime: Sequelize.STRING,
        korisnicko_ime:{type:Sequelize.STRING},
        email: Sequelize.STRING,
        grupa: Sequelize.INTEGER,
        ssh: Sequelize.STRING,
        url: Sequelize.STRING,
        semestar: Sequelize.INTEGER,
        godina: Sequelize.STRING,
        index: Sequelize.STRING,
        regex: Sequelize.STRING,
        nazivRepozitorija: Sequelize.STRING,
        max_broj_grupa: Sequelize.INTEGER
    })
    return LicniPodaci;
};
