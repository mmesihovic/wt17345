//Username i password za administratora
//meho1, meho1
var express = require('express');
var bodyParser = require('body-parser');
var fs = require('fs');
var bcrypt = require('bcrypt');
var db = require('./database.js');
var session = require('express-session');
var app = express();
app.use(session({
    secret: 'nesto',
    resave: true,
    saveUninitialized: true
 }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(__dirname));
app.get('/',function(req,res){
    res.sendFile(__dirname +'/login.html',function(err){
        if(err) throw err;
    });
});
app.get('/login',function(req,res){
    res.sendFile(__dirname +'/login.html',function(err){
        if(err) throw err;
    });
});
app.get('/statistika',function(req,res){
    if(req.session.role == 'student'){
        res.sendFile(__dirname +'/statistika.html',function(err){
            if(err) throw err;
        });
    }
});
app.get('/unoskomentara',function(req,res){
    if(req.session.role == 'student'){
        res.sendFile(__dirname +'/unoskomentara.html',function(err){
            if(err) throw err;
        });
    }
    
});
app.get('/unosSpisaka',function(req,res){
    if(req.session.role == 'nastavnik'){
        res.sendFile(__dirname +'/unosSpisaka.html',function(err){
            if(err) throw err;
        });
    }
});
app.post('/zadatak4service',function(req,res){

        var saveNizNizova =[];
        var saveNiz=[];

        var bodyZ = req.body.textAreaid;
        var tempNizIndexa = bodyZ.split('\n');
        for(var i=0; i<tempNizIndexa.length; i++){
            var tempIndexi = tempNizIndexa[i].split(',');
            saveNiz=[];
            if(tempIndexi.length!=6){
                 res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
                 res.end(JSON.stringify({poruka:'Neispravan format'})); 
                 return;
                 
            }
            for(var j=0; j<6;j++){
                    for(var u=j+1;u<6;u++)
                    if(tempIndexi[j]==   tempIndexi[u]) { 
                          res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
                          res.end(JSON.stringify({poruka:'red '+(i+1).toString()+' nema sve razlicite indexe'}));
                          return;
                        }                
                        
                    saveNiz.push(tempIndexi[j]);
                }
                saveNizNizova.push(saveNiz);
          
    }
        fs.appendFile('spisakS'+req.body.brojSpirale+'.json',JSON.stringify(saveNizNizova),function(err){
        if(err) throw err;
    }); 
        res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
        res.end(JSON.stringify({x:'sve ok'})); 
			
}); 

app.post('/komentar',function(req,res){})
app.post('/lista',function(req,res){})
app.post('/izvjestaj',function(req,res){})
app.post('/bodovi',function(req,res){})


//spirala 4 zadatak 1 i 2

function initialDatabaseData(){ 
    //na samom pocetku imamo 3 korisnika meho1,meho2,meho3 (administrator,nastavnik,student) i za sva tri password je "meho1"
    db.role.create({rola:'administrator'}).then(function(k){
    });
    db.role.create({rola:'nastavnik'}).then(function(k){
    });
    db.role.create({rola:'student'}).then(function(k){
    });
    db.korisnik.create({username:'meho1',password:'$2a$10$jazh1qdHk4jw//7MGbViUeIP6j11i9IIoE7H6iH3oZg2thW5Ud1Qi',id_role:1});
    db.korisnik.create({username:'meho2',password:'$2a$10$jazh1qdHk4jw//7MGbViUeIP6j11i9IIoE7H6iH3oZg2thW5Ud1Qi',id_role:2,verified:true});
    db.korisnik.create({username:'meho3',password:'$2a$10$jazh1qdHk4jw//7MGbViUeIP6j11i9IIoE7H6iH3oZg2thW5Ud1Qi',id_role:3})
}



db.sequelize.sync({force:true}).then(function(){
    initialDatabaseData();
});

app.use(session({
    secret: 'nesto',
    resave: true,
    saveUninitialized: true
 }));

app.post('/login',function(req,res){
    var kriptovaniPW;
    bcrypt.hash(req.body.password, 10, function(err, hash) {
        kriptovaniPW=hash;
        db.korisnik.findAll({
            where: {username: req.body.email},
            attributes: ['id_role','username', 'password','verified']
        }).then(korisnici => {
            console.log('ISPISO DA BOG DA',korisnici[0].dataValues.verified, korisnici[0].dataValues.id_role);
            if(korisnici[0].dataValues.verified == null && korisnici[0].dataValues.id_role == 2) {
                res.status(401).end('Nije jos verifikovan nastavnik');
                console.log('uso');
                return;
            }
           
                bcrypt.compare(req.body.password, korisnici[0].dataValues.password, function(err, resH) {
                    if(resH) {                         
                        db.role.findAll({
                        where:{id:korisnici[0].dataValues.id_role},
                        attributes:['rola']
                   }).then(uloga => {
                        switch(uloga[0].dataValues.rola){
                            case 'administrator':
                                req.session.role = uloga[0].dataValues.rola;
                                fs.readFile(__dirname+'/listaKorisnika.html','utf8',function(err,data){
                                    if(err) throw err;
                                    var tempData ={
                                        rola:'administrator',
                                        stranica:data
                                    };
                                    res.writeHead(200,{'Content-type':'application/json'});
                                    res.end(JSON.stringify( tempData));
                                });
                            break;
                            case 'student':
                                req.session.role = uloga[0].dataValues.rola;
                                fs.readFile(__dirname+'/statistika.html','utf8',function(err,data){
                                    if(err) throw err;
                                    var tempData = {
                                        rola:'student',
                                        stranica:data
                                    };
                                    res.writeHead(200,{'Content-type': 'application/json'});
                                    res.end(JSON.stringify( tempData));
                                });
                            break;
                            case 'nastavnik':
                                req.session.role = uloga[0].dataValues.rola;
                                fs.readFile(__dirname+'/nastavnik.html','utf8',function(err,data){
                                    if(err) throw err;
                                    var tempData = {
                                        rola:'nastavnik',
                                        stranica:data
                                    };

                                    res.writeHead(200,{'Content-type': 'application/json'});
                                    res.end(JSON.stringify(tempData));
                                });
                            break;
                
                        }

                    }).catch(function(err){
               res.send(err);
           });     
        } 
        else res.redirect('/');
          });
    
        });
  });
});

//zadatak 3 spirala 4
app.post('/registrujNastavnika',function(req,res){
    bcrypt.hash(req.body.password, 10, function(err, hash) {
           db.licniPodaci.create({
               ime_i_prezime: req.body.ime_i_prezime,
               korisnicko_ime:req.body.korisnicko_ime,
               email: req.body.email,
               grupa: req.body.grupa,
               ssh: req.body.ssh,
               url: req.body.url,
               semestar: req.body.semestar,
               godina: req.body.godina,
               index: req.body.index,
               regex: req.body.regex,
               nazivRepozitorija: req.body.nazivRepozitorija,
               max_broj_grupa: req.body.max_broj_grupa 
                 
           }).then(function(ubaceniRed){
               db.korisnik.create({
                   username:req.body.korisnicko_ime, 
                   password:hash,
                   id_role:2,
                   id_licniPodaci:ubaceniRed.dataValues.id
               }).then(function(ubaceniKorisnik){
                    res.status(200).send('nastavik registrovan!!');
               })
           }
       );
 });

 
});
app.post('/registrujStudenta',function(req,res){
    bcrypt.hash(req.body.password, 10, function(err, hash) {
        db.licniPodaci.create({
            ime_i_prezime: req.body.ime_i_prezime,
            korisnicko_ime:req.body.korisnicko_ime,
            email: req.body.email,
            grupa: req.body.grupa,
            ssh: req.body.ssh,
            url: req.body.url,
            semestar: req.body.semestar,
            godina: req.body.godina,
            index: req.body.index,
            regex: req.body.regex,
            nazivRepozitorija: req.body.nazivRepozitorija,
            max_broj_grupa: req.body.max_broj_grupa 
                
        }).then(function(ubaceniRed){
            db.korisnik.create({
                username:req.body.korisnicko_ime, 
                password:hash,
                id_role:3,
                id_licniPodaci:ubaceniRed.dataValues.id
            }).then(function(ubaceniKorisnik){
                res.status(200).send('Student je registrovan');
            })
        }
    );
});
 
});

//zadatak 4 spirala 4
app.post('/pretraga',function(req,res){
    if(req.session.role=='administrator'){
        db.korisnik.findAll({
            where: {username: req.body.korisnicko_ime}
        }).then(sviKorisnici => {
            var tempNiz =[];
            var tempData;
            for(var i = 0; i < sviKorisnici.length; i++){
                tempData={
                    username:sviKorisnici[i].username,
                    verified:sviKorisnici[i].verified,
                    id_role:sviKorisnici[i].id_role
                };

                tempNiz.push(tempData);
            }    
            res.writeHead(200,{'Content-type': 'application/json'});
            res.end(JSON.stringify( tempNiz));
            
          })
    }else res.status(401).end('<a href="index.html"> nemate pristup</a>');
    
});

app.post('/verifikuj',function(req,res){
    if(req.session.role=='administrator'){
     
          
        db.korisnik.update(
            {verified: true },
          
            { where: { username: req.body.korisnicko_ime } }
          )
            .then(result =>{
                res.status(200).end('verifikacija uspjesna, rezulatat ='+result);
            }
                
            )
            .catch(err =>{
                res.status(401).end(err);
            }
               
            ) 


    }
    else res.status(401).end('<a href="index.html">Nije moguce pristupiti!</a>');
    
});
app.post('/skiniVerifikaciju',function(req,res){
    if(req.session.role =='administrator'){
          db.korisnik.update(
            {verified: false},
            {where:{ username: req.body.korisnicko_ime } }
        )
        .then(result =>{
           res.status(200).end('un-verifikacija uspjesna, rezulatat ='+result);
        }
                
        )
        .catch(err =>{
        res.status(401).end(err);
        }
               
        ) 
    }
    else res.status(401).end('Error'); 
});
app.get('/sviKorsnici',function(req,res){
    if(req.session.role == 'administrator'){
        db.korisnik.findAll().then(sviKorisnici => {
            var tempNiz =[];
            var tempData;
            for(var i=0; i<sviKorisnici.length; i++){
                tempData={
                    username:sviKorisnici[i].username,
                    verified:sviKorisnici[i].verified,
                    id_role:sviKorisnici[i].id_role
                };

                tempNiz.push(tempData);
            }
            res.writeHead(200,{'Content-type': 'application/json'});
            res.end(JSON.stringify( tempNiz));
            
          })
    }
    else res.status(401).end('Error');
    
});
app.listen(3000);
 