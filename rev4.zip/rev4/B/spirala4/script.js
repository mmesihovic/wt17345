function openNav(stranica){
    var ajax=new XMLHttpRequest();
    ajax.onreadystatechange=function(){
        console.log('test');
        if (ajax.readyState === 4 && ajax.status === 200)
            $("#mainPart").load(stranica);           
         if (ajax.readyState === 4 && ajax.status === 404)
            $("#mainPart").load("Greska: nepoznat URL");
    }
    if(stranica == '/login'){
        document.getElementById("komentari").style.display = "none";
        document.getElementById("statistika").style.display = "none";
        document.getElementById("unosSpiska").style.display = "none";
    }
    ajax.open("GET",stranica,true);
    ajax.send();
}