const express = require('express');
const app = express();
const url = require('url');
var KreirajFajl =  (function(){
    return{
        kreirajKomentar : function(spirala,indeks,sadrzaj,fnCallback){
            var ajax=new XMLHttpRequest();
            var tempKomentar= {
                spirala:spirala,
                indeks:indeks,
                sadrzaj:sadrzaj
            };
            ajax.onreadystatechange = function(){
                if(ajax.readyState < 4){
                    fnCallback(ajax.status,ajax.responseText);
                }
                if(ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null,ajax.responseText);
                }
                if(tempKomentar.spirala.length <= 1 && tempKomentar.indeks.length <= 1){
                    if(Object.prototype.toString.call(sadrzaj) === '[object Array]'
                    && Object.keys(sadrzaj) < 3 
                    && sadrzaj.hasOwnProperty('sifra_studenta') 
                    && sadrzaj.hasOwnProperty('tekst')
                    && sadrzaj.hasOwnProperty('ocjena')){
                        fnCallback(-1,"Parametrni su neispravni");

                    }
                }
            }
            
            ajax.open("POST","3000/komentar",true);
            ajax.setRequestHeader('Content-Type','application/json');
            ajax.send(JSON.stringify(tempKomentar));
            
        },
        kreirajListu: function(godina,nizRepozitorija,fnCallback){
            var ajax=new XMLHttpRequest();
            var tempLista = {
                godina:godina,
                nizRepozitorija:nizRepozitorija
            };
            ajax.onreadystatechange = function(){
                if(ajax.readyState == 4){  
                    fnCallback(ajax.status,ajax.responseText);
                }
                if(ajax.readyState == 4 & ajax.status == 200){
                    fnCallback(null,ajax.responseText);  
                }
                if(tempLista.godina.length < 1  && tempLista.nizRepozitorija.length < 1){
                    fnCallback(-1,"Parametrni su neispravni");
                }
            }
            ajax.open("POST","3000/lista",true);
            ajax.setRequestHeader('Content-Type','application/json');
            ajax.send(JSON.stringify(tempLista));
        },
        kreirajIzvjestaj:function(spirala,indeks,fnCallback){
            var ajax=new XMLHttpRequest();
            var tempIzvjestaj = {
                spirala:spirala,
                indeks:indeks
            };
            ajax.onreadystatechange = function(){
                if(ajax.readyState == 4 ){
                    fnCallback(ajax.status,ajax.responseText); 
                }
                if(ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null,ajax.responseText);  
                }
                if(x.indeks.length <1  && x.spirala.length<1){
                    fnCallback(-1,"Parametri su neispravni");
                }
            }
            ajax.open("POST","3000/izvjestaj",true);
            ajax.setRequestHeader('Content-Type','application/json');
            ajax.send(JSON.stringify(tempIzvjestaj));  
        },
        kreirajBodove:function(spirala,indeks,fnCallback){
            var ajax=new XMLHttpRequest();
            var tempBod = {
                spirala:spirala,
                indeks:indeks
            };
            ajax.onreadystatechange = function(){
                if(ajax.readyState ==4){
                    fnCallback(ajax.status,ajax.responseText);
                }
                if(ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null,ajax.responseText); 
                }
                if(x.indeks.length < 1  && tempBod.spirala.length < 1){
                    fnCallback(-1,"Parametri su neispravni");
                }   
            }


            ajax.open("POST","3000/bodovi",true);
            ajax.setRequestHeader('Content-Type','application/json');
            ajax.send(JSON.stringify(tempBod));  
        }
    }
})();


