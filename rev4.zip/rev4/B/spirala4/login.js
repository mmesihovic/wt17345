var x = document.getElementById("regNastavikaDiv");
var y = document.getElementById("regStudentaDiv");
function registrujNastavnika() {
 
    if (x.style.display == "none" || x.style.display == "") {
    	y.style.display = "none";
        x.style.display = "inline-block";
    } 
}
function registrujStudenta() {

    if (y.style.display == "none") {
    	x.style.display = "none";
        y.style.display = "inline-block";
    } 
}
function validirajImePrezimeNastavnika(){
	var imeprezime = document.getElementById("imeprezimeinputnastavnik").value;

    document.getElementById("imeValidateLabel").innerHTML =  ""

	if(imeprezime == ""){
		
		document.getElementById("imeValidateLabel").innerHTML = "Unesite ime i prezime nastavnika!"
	}
	else if(!Validacija.validirajImeiPrezime(imeprezime)){
	   document.getElementById("imeValidateLabel").innerHTML = "Unesite ispravno ime i prezime nastavnika!"

	}
}
function validirajMailNastavnika(){
	var mail = document.getElementById("mailInput").value;
	document.getElementById("mailLabel").innerHTML = "";
	if(!Validacija.validirajFakultetski(mail)){
		document.getElementById("mailLabel").innerHTML = "Email neispravno unesen!";
	}
}
function validirajPassword(){
	var pass = document.getElementById("passwordNastavnika").value;
	document.getElementById("passValidateNastavik").innerHTML = "";
	if(!Validacija.validirajPassword(pass)){
		document.getElementById("passValidateNastavik").innerHTML = "Neispravno unesen password!"
	}
}
function validacijaStudentPass(){
	
	var pass = document.getElementById("passStudent").value;
	document.getElementById("passStudentValLabel").innerHTML = "";
	if(!Validacija.validirajPassword(pass)){
		document.getElementById("passStudentValLabel").innerHTML = "Neispravno unesen password!"
	}
}
function validirajPotvrduPassworda(){
	var potPass = document.getElementById("passwordNastavnika").value;
	var pass = document.getElementById("passwordPotvrdaInput").value;
	document.getElementById("passwordPotvrdaLabel").innerHTML="";
	if(!Validacija.validirajPotvrdu(potPass,pass)){
		document.getElementById("passwordPotvrdaLabel").innerHTML="Neispravno potvrden password!";
	}
}
function validirajImePrezimeStudenta(){
	var imeprezime = document.getElementById("imeprezimeinputstudent").value;

    document.getElementById("imeprezStduentaVal").innerHTML =  ""

	if(imeprezime == ""){
		
		document.getElementById("imeprezStduentaVal").innerHTML = "Unesite ime i prezime nastavnika!"
	}
	else if(!Validacija.validirajImeiPrezime(imeprezime)){
	   document.getElementById("imeprezStduentaVal").innerHTML = "Unesite ispravno ime i prezime nastavnika!"

	}
}
function validirajIndexStudenta(){
	var index = document.getElementById("indexStudenta").value;
	document.getElementById("indexValLabel").innerHTML = "";
	if(!Validacija.validirajIndex(index)){
		document.getElementById("indexValLabel").innerHTML = "Neispravno unesen broj indexa!";
	}
}

function validirajPotvrduPassStudenta(){
	var potPass = document.getElementById("studentPassPotvrdaInput").value;
	var pass = document.getElementById("passStudent").value;
	document.getElementById("passPotvrdaStudentValLabel").innerHTML="";
	if(!Validacija.validirajPotvrdu(potPass,pass)){
		document.getElementById("passPotvrdaStudentValLabel").innerHTML="Neispravno potvrden password!";
	}
}
function validirajStudentSSH(){
	document.getElementById("bitbucketValLabel").innerHTML ="";
	var sshString = document.getElementById("sshInput").value;
	var korIme = document.getElementById("korisnickoImeInput").value;
	var repoz = document.getElementById("nazivRepozInput").value;
	Validacija.korisnickoIme = korIme;
	Validacija.nazivRepozitorija = repoz;
	if(korIme == "") {
		document.getElementById("bitbucketValLabel").innerHTML ="Morate unijeti korisnicko ime iznad!";
	}
	
	else if(!Validacija.validirajNazivRepozitorija(null, repoz)){
		document.getElementById("bitbucketValLabel").innerHTML ="Moreate unijeti ispravan naziv repozitorija iznad!";
	}
	else if(!Validacija.validirajBitbucketSSH(sshString)){
		document.getElementById("bitbucketValLabel").innerHTML ="Neispravno unesen SSH! Provjerite korisnicko ime i naziv repozitorija";
	}
}
function validirajKorisnickoIme(){
	var username = document.getElementById("korisnickoImeInput").value;
	document.getElementById("korImeLabelStudent").innerHTML = "";
	if(username=="") {
		document.getElementById("korImeLabelStudent").innerHTML = "Unesite korisnicko ime!";
	}
}
function validirajNazivRepoz(){
	var repoz = document.getElementById("nazivRepozInput").value;
	document.getElementById("nazivRepozValLabel").innerHTML = "";
	if(!Validacija.validirajNazivRepozitorija(null,repoz))
		document.getElementById("nazivRepozValLabel").innerHTML = "Neispravno unesen naziv repozitorija!";
}

function validirajAkGod(){
	if(!x.style.display == "" ){
		var akGod = document.getElementById("akGodNast").value;
		document.getElementById("akgodNastLabel").innerHTML = "";
		if(!Validacija.validirajAkGod(akGod)){
		document.getElementById("akgodNastLabel").innerHTML = "Niste unjieli ispravan format akademske godine 20AB/20CD!";
	}
	}
	var akGod = document.getElementById("akGodInput").value;
	document.getElementById("akGodLabelVal").innerHTML = "";
	if(akGod == "")document.getElementById("akGodLabelVal").innerHTML = "Unesite akademsku godinu!";
	else if(!Validacija.validirajAkGod(akGod)){
		document.getElementById("akGodLabelVal").innerHTML = "Niste unjieli ispravan format akademske godine 20AB/20CD!";
	}
}
function validirajStudentURL(){
	var url = document.getElementById("bitcuketURLInput").value;
	document.getElementById("bitbucketURLValLabel").innerHTML ="";
	if(!Validacija.validirajBitbucketURL(url)){
		document.getElementById("bitbucketURLValLabel").innerHTML ="Niste unijeli ispravan bit bucket URL!";
	}
}
function maxBrojGrupa(){
	Validacija.maxGrupa = document.getElementById("maxG").value;
}

function validirajBrojGrupeStudenta(){
	var broj = document.getElementById("brGrupeStudenta").value;
	document.getElementById("brGrupeLabel").innerHTML = "";
	if(!Validacija.validirajGrupu(broj)){
		document.getElementById("brGrupeLabel").innerHTML = ("Broj grupa je preko maksimalnog broja 7");
	}
}