function submit(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function(){
        if (ajax.status == 200 && ajax.readyState == 4){
            var JSONObject = ajax.responseText;
            var temp = JSON.parse(JSONObject).poruka;
            if(temp!=null) alert(temp);
            else alert("Kreirali ste fajl!");
        }
        if (ajax.status == 404 && ajax.readyState == 4)alert("Greska!!!!");

    }
    var body={
        inputNum:document.getElementById('inputNum').value,
        textArea:document.getElementById('textArea').value
    }
    ajax.open("POST","/zadatak4service",true);
    ajax.setRequestHeader("Content-Type","application/json");
    ajax.send(JSON.stringify(body));
}