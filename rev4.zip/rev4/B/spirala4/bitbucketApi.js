var BitbucketApi = (function(){
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
                if(ajax.readyState == 4 && ajax.status != 200){
                    fnCallback(ajax.status,null);
                }
                if(ajax.readyState == 4 && ajax.status == 200 && (key == null || secret == null)){
                    fnCallback(-1,"Neispravni key ili secret");
                }
                else{
                    fnCallback(null,JSON.parse(ajax.responseText).access_token);
                }
            }
            ajax.open("POST","https://bitbucket.org/site/oauth2/access_token",true);
            ajax.setRequestHeader("Content-Tyoe", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization","Basic "+btoa(key+':'+secret));
            ajax.send('grant_type='+encodeURIComponent('client_credentials'));
        },
        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
                if(ajax.status != 200 && ajax.readyState == 4){
                    fnCallback(ajax.status,null);
                }
                if(ajax.readyState == 4 && ajax.status == 200){
                    var json = JSON.parse(ajax.responseText).values;
                    var temp =[];
                    for(let i =0; i<json.length; i++) temp.push(JSON.stringify(json[i].links.clone[1].href));
                    fnCallback(null,temp);
                }
            }
            ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member"+query,true);
            ajax.setRequestHeader("Authorization",'Bearer' + token);
            ajax.send();
        },
        dohvatiBranch:function(token,url,naziv,fnCallback){
            var ajax = new XMLHttpRequest(); 
            ajax.onreadystatechange= function(){
                if(ajax.readyState < 4 && ajax.status != 200){
                    fnCallback(ajax.status,null);
                }
                var json = JSON.parse(ajax.responseText).values;
                if(ajax.status == 200 && ajax.readyState == 4){
                    var temp = false;
                    for(var i=0;i<json.length;i++){
                        if(json[i].links.branches.href == naziv){
                            temp=!temp;
                            fnCallback(null,true);
                            break;
                        }
                    }
                    if(!temp) fnCallback(null,false);
                }
            }
            ajax.open('GET',url,true);
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
        }
    }
})();
