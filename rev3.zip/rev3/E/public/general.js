$(document).ready(function() {
    $('#content').load('index.html');
    $('#sadrzaj').load('login.html');
    $('ul#meni li a').click(function(){
        var page = $(this).attr('href');
        $('#sadrzaj').load(page +'.html');
        return false;
    });

});