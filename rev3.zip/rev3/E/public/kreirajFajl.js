var KreirajFajl=(function(){
    return {
        kreirajKomentar: function(spirala, index, sadrzaj, fnCallback){
            let sendData = new Object();
            var spirala1= document.getElementById(spiralaKomentar).value;
            var index1= document.getElementById(index).value;
            if (index1 == "") {
            alert("Unesite index");
            return false;
            }
            if(index1.length!=5) { 
            alert("Index mora sadrzavati 5 brojeva");
            return false;
            } else if(!index1.startsWith('1')) { 
            alert("Index mora poceti sa 1");
            return false;
           }
           else {

            sendData.spirala = spirala1;
            sendData.index = index1;
            sendData.sadrzaj = sadrzaj;
            $.ajax({
                type: 'POST',
                data: JSON.stringify(sendData),
                contentType: 'application/json',
                url: 'http://localhost:3000/komentar',						
                success: function(data) {
                    fnCallback.error = null;
                    fnCallback.data = data;
                    console.log('success');
                    console.log(JSON.stringify(data));
                },
                error: function(data) {
                    fnCallback.error = data;
                    fnCallback.data = 'Error happened';
                } 
            });
        }
        },
        kreirajListu: function(godina, nizRepozitorija, fnCallback){
            let sendData = new Object();
            var godina1= document.getElementById(godina).value;
            if (godina1 == "") {
                alert("Unesite godinu");
                return false;
                }
                if(godina1.length!=4) { 
                alert("Godina mora sadrzavati 4 broja");
                return false;
                } else if(!godina1.startsWith('20')) { 
                alert("Godina mora poceti sa 20");
                return false;
               }
               else {
            sendData.godina = godina1;
            sendData.nizRepozitorija = nizRepozitorija;
            $.ajax({
                type: 'POST',
                data: JSON.stringify(sendData),
                contentType: 'application/json',
                url: 'http://localhost:3000/lista',						
                success: function(data) {
                    fnCallback.error = null;
                    fnCallback.data = data;
                    console.log('success');
                    console.log(JSON.stringify(data));
                },
                error: function(data) {
                    fnCallback.error = data;
                    fnCallback.data = 'Error happened';
                }
            });
        }
        },
        kreirajIzvjestaj: function(spirala,index, fnCallback){
            let sendData = new Object();
            var spirala1= document.getElementById(spiralaKomentar).value;
            var index1= document.getElementById(index).value;
            if (index1 == "") {
            alert("Unesite index");
            return false;
            }
            if(index1.length!=5) { 
            alert("Index mora sadrzavati 5 brojeva");
            return false;
            } else if(!index1.startsWith('1')) { 
            alert("Index mora poceti sa 1");
            return false;
           }
           else {

            sendData.spirala = spirala1;
            sendData.index = index1;
            $.ajax({
                type: 'POST',
                data: JSON.stringify(sendData),
                contentType: 'application/json',
                url: 'http://localhost:3000/komentar',						
                success: function(data) {
                    fnCallback.error = null;
                    fnCallback.data = data;
                    console.log('success');
                    console.log(JSON.stringify(data));
                },
                error: function(data) {
                    fnCallback.error = data;
                    fnCallback.data = 'Error happened';
                } 
            });
        }
        },
        kreirajBodove: function(spirala,index, fnCallback){
            let sendData = new Object();
            var spirala1= document.getElementById(spiralaKomentar).value;
            var index1= document.getElementById(index).value;
            if (index1 == "") {
            alert("Unesite index");
            return false;
            }
            if(index1.length!=5) { 
            alert("Index mora sadrzavati 5 brojeva");
            return false;
            } else if(!index1.startsWith('1')) { 
            alert("Index mora poceti sa 1");
            return false;
           }
           else {

            sendData.spirala = spirala1;
            sendData.index = index1;
            $.ajax({
                type: 'POST',
                data: JSON.stringify(sendData),
                contentType: 'application/json',
                url: 'http://localhost:3000/komentar',						
                success: function(data) {
                    fnCallback.error = null;
                    fnCallback.data = data;
                    console.log('success');
                    console.log(JSON.stringify(data));
                },
                error: function(data) {
                    fnCallback.error = data;
                    fnCallback.data = 'Error happened';
                } 
            });
        }
        }
    }
})();
