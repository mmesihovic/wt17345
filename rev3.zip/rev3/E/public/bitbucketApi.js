var BitbucketApi = (function(){
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){
            var keyData = document.getElementById(key).value;
            var secretData = document.getElementById(secret).value;
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200){
                    fnCallback.error = null;
                    fnCallback.data = JSON.parse(ajax.responseText).access_token;
                    console.log(fnCallback.data);
                }
                else if (ajax.readyState == 4){
                    fnCallback.error = ajax.status;
                    console.log(fnCallback.error);
                }
            }
            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization", 'Basic ' + btoa(keyData+':'+secretData));
            ajax.send("grant_type="+encodeURIComponent("client_credentials"));
        },
        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback){
            if(error) throw error;
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200)
                    {
                        console.log(ajax.responseText);
                        console.log(JSON.parse(ajax.responseText).values[0].name);
                        console.log(JSON.parse(ajax.responseText).values[0].owner.username);
                        //Dodajte dio koji će u HTML ispisati tabelu sa repozitorijima
                        //Podatke parsirajte sa var podaci = JSON.parse(ajax.responseText);
                        //Imena repozitorija možete dobiti sa podaci.values[i].name
                        //Imena vlasnika repozitorija sa podaci.values[i].owner.username
                        }
                        else if (ajax.readyState == 4)
                            console.log(ajax.status);
                    }
                    ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member");
                    ajax.setRequestHeader("Authorization", 'Bearer ' + token);
                    ajax.send();
        },
        dohvatiBranch: function(token, url, naziv, fnCallback){}
    }
})();
