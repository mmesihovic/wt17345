var Validacija=(function(){
    var maxGrupa=7;
    var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar
    var dt = new Date();
    var trenutnaGodina = dt.getFullYear();
    var regex;
    var semestar;
    var validirajLogin = function(fakultetskiEmailId, passwordId) {
        validirajFakultetski(fakultetskiEmailId);
        validirajPassword(passwordId);

    }
    var validirajRegistraciju = function(fakultetskiEmailId, indexId, grupaId, passwordId, potvrdaId, akGodId, bbUrlId, bbSSHId, repozitorijId,imeiPrezimeId) {
        validirajFakultetski(fakultetskiEmailId);
        validirajIndex(indexId);
        validirajGrupu(grupaId);
        validirajPassword(passwordId);
        validirajPotvrdu(passwordId, potvrdaId);
        validirajAkGodStudent(akGodId);
        validirajBitbucketURL(bbUrlId);
        validirajBitbucketSSH(bbSSHId);
        validirajNazivRepozitorija(regex,repozitorijId);
        validirajImeiPrezime(imeiPrezimeId)
        
    }
    var validirajRegistracijuProfesora = function(imeiPrezimeId, usernameId,passwordId, potvrdaId,fakultetskiEmailId, grupaId, regexId, semestarId, akGodId ) {
        validirajImeiPrezime(imeiPrezimeId);
        validirajPassword(passwordId);
        validirajPotvrdu(passwordId, potvrdaId);
        validirajFakultetski(fakultetskiEmailId);
        validirajGrupu(grupaId);
        validirajRepozitorij(regexId);
        validirajSemestar(semestarId);
        validirajAkGod(akGodId);
    }
    var validirajFakultetski = function(fakultetskiEmailId) {
        var fakultetskiEmail = document.getElementById(fakultetskiEmailId);
        
        if (fakultetskiEmail.value == "") {
            alert("Unesite email");
            return false;
        }
        else {
            var re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if(!re.test(fakultetskiEmail.value)){
                alert("Email nije validan");
                return false;
            }
            if (!fakultetskiEmail.value.endsWith('@etf.unsa.ba')){
                alert("Email nema poddomenu: etf.unsa.ba");
                return false;
            }
        }
        return true;
    }
    var validirajPassword = function(passwordId) {
        var password = document.getElementById(passwordId);
        
        var upperCaseLetters = /[A-Z]/g;
        var lowerCaseLetters = /[a-z]/g;
        var numbers = /[0-9]/g;
        if (password.value == "") {
            alert("Unesite password");
            return false;
        }
        else if(!password.value.match(upperCaseLetters)) { 
            alert("Password mora sadrzavati velika slova");
            return false;
        }else if(!password.value.match(lowerCaseLetters)) { 
            alert("Password mora sadrzavati mala slova");
            return false;
        }else if(!password.value.match(numbers)) { 
            alert("Password mora sadrzavati bar jedan broj");
            return false;
        }else if(password.value.length<7) { 
            alert("Password mora imati bar 8 karaktera");
            return false;
        }else if(password.value.length>20) { 
            alert("Password ne moze imati preko 20 karaktera");
            return false;
        }
        return true;
    }
    var validirajIndex = function(indexId) {
        var index = document.getElementById(indexId);
        if (index.value == "") {
            alert("Unesite index");
            return false;
        }
        if(index.value.length!=5) { 
            alert("Index mora sadrzavati 5 brojeva");
            return false;
        }else if(!index.value.startsWith('1')) { 
            alert("Index mora poceti sa 1");
            return false;
        }
        return true;
    }
    var validirajGrupu = function(grupaId) {
        var grupa = document.getElementById(grupaId);
        if(grupa.value<1 && grupa.value>maxGrupa) { 
            alert("Maximalan broj grupa moze biti 7");
            return false;
        }
        return true;
    }
    var validirajPotvrdu = function(passwordId, potvrdaId) {
        var password = document.getElementById(passwordId);
        var potvrda = document.getElementById(potvrdaId);
         if (potvrda.value == "") {
            alert("Password se mora potvrditi");
            return false;
        }
        else if(password.value!=potvrda.value) { 
            alert("Passwordi nisu isti");
            return false;
        }
        return true;
    }
    var validirajAkGodStudent = function(akGodId) {
        var akGod = document.getElementById(akGodId);
        var prvaGod = akGod.value.substring(0,4);
        var drugaGod = akGod.value.substring(5,9);
        if(akGod.value === ''){
            alert('Unesite akademsku godinu');
            return false;
        }
        if(parseInt(prvaGod)<2000 && parseInt(prvaGod)>2100){
            alert('Unesena prva akademska godina nije validna');
            return false;
        }
        else if(parseInt(drugaGod)<2000 && parseInt(drugaGod)>2100){
            alert('Unesena druga akademska godina nije validna');
            return false;
        }
        else if((parseInt(prvaGod) + 1) != parseInt(drugaGod)){
            alert('Unesena akademska godina nije validna');
            return false;
        }
        else if(akGod.value.substring(4,5)!='/'){
            alert('Separator godina nije validan');
            return false;
        }
        return true;
    }
    var validirajBitbucketURL = function(bbUrlId) {
        var bbUrl = document.getElementById(bbUrlId);
        var re = /(^(https):\/\/)[a-zA-Z0-9.]{1,}[@]bitbucket\.org\/[a-zA-Z0-9.]{1,}\/[a-zA-Z0-9]{1,}\.git$/;
        if (re.test(bbUrl.value)){
            return true;
        }
        else {
            alert('BitBucket url nije validan');
            return false;
        }
    }
    var validirajBitbucketSSH = function(bbSSHId) {
        var bbSSH = document.getElementById(bbSSHId);
        var re = /^git[@]bitbucket\.org:[a-zA-Z0-9.]{1,}\/[a-zA-Z0-9]{1,}\.git$/;
        if (re.test(bbSSH.value)){
            return true;
        }
        else {
            alert('BitBucket SSH nije validan');
            return false;
        }
    }
    var validirajNazivRepozitorija = function(regexId,repozitorijId) {
        var regex =document.getElementById(regexId);
        var repozitorij = document.getElementById(repozitorijId);
        var re = /^(wtProjekat|wtprojekat)[0-9]{5}$/;
        if(regex.value !=""){
            re=new RegExp(regex.value); 
        }
        if (re.test(repozitorij.value)){
            return true;
        }
        else {
            alert('Repozitorij nije validan');
            return false;
        }
    }
    var validirajImeiPrezime = function(imeiPrezimeId) {
        var imeiPrezime =document.getElementById(imeiPrezimeId);
        var re = /(^[A-ZŠĐČĆŽ](-|')*([a-zšđčćž'-]+)(-|')*\s([A-ZŠĐČĆŽ](-|')*([a-zšđčćž'-]+)))|(^[A-ZŠĐČĆŽ](-|')*([a-zšđčćž'-]{2,11}))/;
        if(imeiPrezime.value ==""){
            alert('Unesite ime i prezime');
        }
        else if (re.test(imeiPrezime.value)){
            return true;
        }
        else {
            alert('Ime i prezime nije validno');
            return false;
        }
    }
    var validirajRepozitorij = function(regexRepozitorijaId){
        var regexRepozitorija = document.getElementById(regexRepozitorijaId);
        regex = regexRepozitorija.value;
    }
    var validirajMaxBrojGrupa = function (maxBrojId){
        var maxBroj = document.getElementById(maxBrojId);
        maxGrupa = maxBroj.value;
    }
    
    var validirajAkGod = function(akGodId) {
        var akGod = document.getElementById(akGodId);
        var prvaGod = akGod.value.substring(0,4);
        var drugaGod = akGod.value.substring(5,9);
        if(akGod.value === ''){
            alert('Unesite akademsku godinu');
            return false;
        }
        if(parseInt(prvaGod)<2000 && parseInt(prvaGod)>2100){
            alert('Unesena prva akademska godina nije validna');
            return false;
        }
        else if(parseInt(drugaGod)<2000 && parseInt(drugaGod)>2100){
            alert('Unesena druga akademska godina nije validna');
            return false;
        }
        else if((parseInt(prvaGod) + 1) != parseInt(drugaGod)){
            alert('Unesena akademska godina nije validna');
            return false;
        }
        else if(akGod.value.substring(4,5)!='/'){
            alert('Separator godina nije validan');
            return false;
        }
        if(semestar.includes('imski')){
            if(parseInt(prvaGod) != trenutnaGodina){
            alert('Unesena prva akademska godina nije validna');
            return false;
            }
        }
        else if (semestar.includes('etni')){
            if(parseInt(drugaGod) != trenutnaGodina){
            alert('Unesena druga akademska godina nije validna');
            return false;
            }
        }
        return true;
    }
    var validirajSemestar = function(semestarId) {
        var sem = document.getElementById(semestarId);
        semestar = sem.value;
    }
    return{
        validirajLogin: validirajLogin,
        validirajRegistraciju: validirajRegistraciju,
        validirajRegistracijuProfesora: validirajRegistracijuProfesora,
        validirajIndex: validirajIndex,
        validirajGrupu: validirajGrupu,
        validirajPotvrdu: validirajPotvrdu,
        validirajFakultetski: validirajFakultetski,
        validirajAkGodStudent: validirajAkGodStudent,
        validirajPassword: validirajPassword,
        validirajBitbucketURL: validirajBitbucketURL,
        validirajBitbucketSSH: validirajBitbucketSSH,
        validirajNazivRepozitorija: validirajNazivRepozitorija,
        validirajImeiPrezime: validirajImeiPrezime,
        validirajRepozitorij: validirajRepozitorij,
        validirajAkGod: validirajAkGod
    }
}());