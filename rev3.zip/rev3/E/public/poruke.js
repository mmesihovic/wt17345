var Poruke=(function(){
    var idDivaPoruka;
    var mogucePoruke=[];
    var porukeZaIspis=[];
    var ispisiGreske = function ()
    {
    }
    return{
        ispisiGreske: ispisiGreske
    }
    }());
    