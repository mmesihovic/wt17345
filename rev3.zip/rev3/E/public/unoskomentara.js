function get_previoussibling(n) {
    if (n != null && n.previousSibling != null && n.previousSibling.nodeType != null) {
        x = n.previousSibling;
        while (x != null && x.nodeType != 1) {
            x = x.previousSibling;
        }
        return x;
    }
}

function get_nextsibling(n) {
    if (n != null && n.nextSibling != null && n.nextSibling.nodeType != null) {
        x = n.nextSibling;
        while (x != null && x.nodeType != 1) {
            x = x.nextSibling;
        }
        return x;
    }
}
function MoveUp() {
    var table,
        row = this.parentNode;
    if (row.rowIndex != 0) {

        while (row != null) {
            if (row.nodeName == 'TR') {
                break;
            }
            row = row.parentNode;
        }
        table = row.parentNode;
        table.insertBefore(row, get_previoussibling(row));
    }
}

function MoveDown() {
    var table,
        row = this.parentNode;

    while (row != null) {
        if (row.nodeName == 'TR') {
            break;
        }
        row = row.parentNode;
    }
    table = row.parentNode;
    table.insertBefore(row, get_nextsibling(get_nextsibling(row)));
}

function getSadrzaj(){
    var table = document.getElementsByClassName('myTable')[0];
    var rowLength = table.rows.length;
    var listaSadrzaja = [];
    for (i = 0; i < rowLength; i++) {
        var cellLength = table.rows[i].cells.length;
        var sadrzaj = new Sadrzaj();
        for (j = 0; j < cellLength; j++) {
            var cellValue = table.rows[i].cells[j].children[0].value;
            if (j === 0) {
                sadrzaj.sifra_studenta = cellValue;
            }
            else if (j === 1) {
                sadrzaj.tekst = cellValue;
            }
            else if (j === 2) {
                sadrzaj.ocjena = cellValue;
            }
        }
        listaSadrzaja.push(sadrzaj);
    }
    return listaSadrzaja;
}
function getFnCallback () {
    var fncb = new FnCallback();
    return fncb;
}
function Sadrzaj () {//‘sifra_studenta’:’A’,’tekst’:’Neki tekst’,’ocjena’:0}
    this.sifra_studenta = '';
    this.tekst = '';
    this.ocjena = '';
}
function nizRepozitorija () {
    this.repozitorij = '';
}
function FnCallback () {
    this.error = '';
    this.data = '';
}
function getRepozitorij(){
    var table = document.getElementsByClassName('myRepositoryTable')[0];
    var rowLength = table.rows.length;
    var listaRepozitorija = [];
    for (i = 0; i < rowLength; i++) {
        var cellLength = table.rows[i].cells.length;
        var repozitorij = new nizRepozitorija();
        for (j = 0; j < cellLength; j++) {
            var cellValue = table.rows[i].cells[j].children[0].value;
            if (j === 0) {
                repozitorij = cellValue;
            }
        }
        listaRepozitorija.push(repozitorij);
    }
    return listaRepozitorija;
}