function toggleRegistracija(toggle) {
    var x = document.getElementById("registracijaStudenta");
    var y = document.getElementById("registracijaProfesora");
    if(toggle === 'student'){
        if (x.style.display === "none") {
            x.style.display = "block";
            y.style.display = "none"
        } else {
            x.style.display = "none";
            y.style.display = "block";
        }
    }
    else if (toggle === 'profesor'){
        if (y.style.display === "none") {
            y.style.display = "block";
            x.style.display = "none"
        } else {
            y.style.display = "none";
            x.style.display = "block";
        }
    }
}