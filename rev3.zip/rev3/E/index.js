var express = require('express');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
var fs = require('fs');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

app.set('view engine', 'pug');

app.use('/', express.static('public'));

app.post('/komentar', function (req, res) {
    console.log(req);
    console.log(res);
    res.contentType('json');
    res.send(req.body);
    fs.writeFile('./public/data/markS' + req.body.spirala + req.body.index + '.json', JSON.stringify(req.body.sadrzaj), res);
});
app.post('/lista', function (req, res) {
    console.log(req);
    console.log(res);
    res.contentType('json');
    res.send(req.body);
    var text = '';
    req.body.nizRepozitorija.forEach(element => {
        text += element + '\n';
    });
    if (fs.existsSync('./public/data/spisak' + req.body.godina + '.txt')) {
        fs.appendFile('./public/data/spisak' + req.body.godina + '.txt', text, function (err) {
            if (err) throw err;
            //res.json({ message: "Uspješno dodan red", data: text });
        });
    }
    else {fs.writeFile('./public/data/spisak'+req.body.godina+'.txt', text, res);}
});
app.post('/izvjestaj', function (req, res) {
    console.log(req);
    console.log(res);
    res.contentType('json');
    res.send(req.body);
});
app.post('/bodovi', function (req, res) {
    console.log(req);
    console.log(res);
    res.contentType('json');
    res.send(req.body);
});
app.listen(3000, function () {
    console.log('Example app listening on port 3000!');
});
