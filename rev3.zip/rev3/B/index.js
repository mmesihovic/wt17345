const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const path = require('path');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/static", express.static(path.join(__dirname, "public")));
app.get('',function(req,res)
{
    res.sendFile(__dirname + '/public/index.html');  
});
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.post('/unosspiska',function(req,res){
   let tijelo = req.body;
   let datoteka = 'spisakS'+tijelo['spirala']+'.json';
   fs.writeFile(datoteka,tijelo['textarea'],function(err){
       if(err) throw err;
       res.json({message:"Uspješno odrađen posao",data:tijelo['textarea']});
   });
});
app.post('/komentar',function(req,res){
    let tijelo = req.body;
    let datoteka = 'marksS'+tijelo['spirala']+tijelo['index']+'.json';
    spirala=tijelo['spirala'];
    index=tijelo['index'];
    sadrzaj=tijelo['sadrzaj'];
    function ssadrzaj(sadrzaj1){
        let sadrzaj2 = JSON.parse(sadrzaj1);
        var ok=0;
        let sadrzaj = sadrzaj2.sadrzaj;
        for(var i=0; i<sadrzaj.length; i++){
            if(sadrzaj[i].sifra_studenta && sadrzaj[i].tekst && sadrzaj[i].ocjena){}
            else ok=1;
            if(ok===1) return false;
        }
        return true;
    }
    if(spirala.length>0 && spirala!=null && typeof(spirala)==='string' && typeof(index)==='string' && index!=null && index.length>0
    && ssadrzaj(sadrzaj) && JSON.parse(sadrzaj).sadrzaj instanceof Array){
    fs.writeFile(datoteka,JSON.stringify(JSON.parse(sadrzaj).sadrzaj),function(err){
        if(err) throw err;
        res.json({message:"Uspješno kreirana datoteka!",data:tijelo['sadrzaj']});
    });
    }
    else{
        res.json({message:"Podaci nisu u traženom formatu!",data:null});
    }
 });
 app.post('/lista',function(req,res){
    let tijelo = req.body;
    let datoteka = 'spisak'+tijelo['godina']+'.txt';
    godina=tijelo['godina'];
    nizRepozitorija=tijelo['nizRepozitorija'];
    if(godina!=null && godina.length>0 && nizRepozitorija instanceof Array && nizRepozitorija.length>0){
        let redovi = [];
        for(let i=0; i<nizRepozitorija.length; i++){
            if(nizRepozitorija[i].includes(godina))
            redovi.push(nizRepozitorija[i]);
        }
    fs.writeFile(datoteka,redovi,function(err){
        if(err) throw err;
        res.json({message:"Lista uspješno kreirana",data:100});
    });
    }
    else{
        res.json({message:"Podaci nisu u traženom formatu!",data:null})
    }
 });
 app.post('/izvjestaj',function(req,res){
    let tijelo = req.body;
    let datoteka = 'izvjestaj'+tijelo['spirala']+tijelo['index']+'.txt';
    spirala=tijelo['spirala'];
    index=tijelo['index'];
    
    if(index!=null && index.length>0){

    fs.readdir('./',function(err,files){
        if(files.includes('spisakS'+spirala+'.json')){
        fs.writeFile(datoteka,'',function(err){
        });
        let krajnjadatoteka="";
        let brojac=0;
        let spisak = './spisakS'+spirala+'.json';
        fs.readFile(spisak,function(err,data){
            let a = JSON.parse(data.toString());
            for (let i=0; i<a.length; i++){
                if (a[i][0]!==index && a[i].includes(index)){
                    let noviindex=a[i][0];
                    let iod = a[i].indexOf(index);
                    let slovo;
                    if(iod==1) slovo='A';
                    else if(iod==2) slovo='B';
                    else if(iod==3) slovo='C';
                    else if(iod==4) slovo='D';
                    else if(iod==5) slovo='E';
                    if(files.includes('marksS'+spirala+noviindex+'.json')){
                    fs.readFile('./marksS'+spirala+noviindex+'.json',function(err,data){
                        if(err){
                            throw err;
                        }
                        else{
                        let str = JSON.parse(data.toString());
                        let izvrsilose=false;
                        for(let i=0; i<str.length; i++){
                            if(str[i]['sifra_studenta']===slovo){
                                let stri='';
                                stri+=str[i]['tekst']+'\n'+'##########'+'\n';
                                krajnjadatoteka+=stri;
                                brojac++;
                                if(brojac==5){
                                    res.json({message:"",data:krajnjadatoteka});
                                }
                                fs.appendFile(datoteka,stri,function(err){
                                    if(err) throw err;
                                });
                                izvrsilose=true;
                            }
                        }
                        if(!izvrsilose){
                            let stri='\n'+'##########'+'\n';
                            krajnjadatoteka+=stri;
                            brojac++;
                                if(brojac==5){
                                    res.json({message:"",data:krajnjadatoteka});
                                }
                            fs.appendFile(datoteka,stri,function(err){
                            if(err) throw err;
                            });
                        }
                        }
                    });
                }
                else{
                    let stri='\n'+'##########'+'\n';
                    krajnjadatoteka+=stri;
                    brojac++;
                    if(brojac==5){
                        res.json({message:"",data:krajnjadatoteka});
                    }
                    fs.appendFile(datoteka,stri,function(err){
                        if(err) throw err;
                    });
                }
                }
            }
        });
    }
    });
    }
    else{
        res.json({message:"Podaci nisu u traženom formatu!",data:null})
    }
 });

 app.post('/bodovi',function(req,res){
    let navrh=0;
    let tijelo = req.body;
    //let datoteka = 'izvjestaj'+tijelo['spirala']+tijelo['index']+'.txt';
    spirala=tijelo['spirala'];
    index=tijelo['index'];
    if(index!=null && index.length>0 && spirala!=null && spirala.length>0){

    fs.readdir('./',function(err,files){
        if(files.includes('spisakS'+spirala+'.json')){
        let spisak = './spisakS'+spirala+'.json';
        fs.readFile(spisak,function(err,data){
            if(err) throw err;
            let a = JSON.parse(data.toString());
            for (let i=0; i<a.length; i++){
                if (a[i][0]!==index && a[i].includes(index)){
                    let noviindex=a[i][0];
                    let iod = a[i].indexOf(index);
                    let slovo;
                    let marks=0;
                    let br=0;
                    if(iod==1) slovo='A';
                    else if(iod==2) slovo='B';
                    else if(iod==3) slovo='C';
                    else if(iod==4) slovo='D';
                    else if(iod==5) slovo='E';
                    if(files.includes('marksS'+spirala+noviindex+'.json')){
                    fs.readFile('./marksS'+spirala+noviindex+'.json',function(err,data){
                        if(err){
                            throw err;
                        }
                        else{
                        navrh++;
                        let str = JSON.parse(data.toString());
                        let izvrsilose=false;
                        for(let i=0; i<str.length; i++){
                            if(str[i]['sifra_studenta']===slovo){
                                br++;
                                marks = marks + parseInt(str[i].ocjena);
                            }
                        }
                        if(navrh==a.length-1){
                            marks=marks/br+1;
                            let izlaz = 'Student '+index+' je ostvario u prosjeku '+marks+' mjesto';
                            res.json({message:"Bodovi ostvareni",data:izlaz});
                        }
                        }
                    });
                }
                else{
                    navrh++;
                }
                }
            }
        });
    }
    });
    }
    else{
        res.json({message:"Podaci nisu u traženom formatu!",data:null})
    }
 });


app.listen(3000);