function generisilistu(){
    let k = document.getElementById("key").value;
    let n = document.getElementById("naziv").value;
    let g = document.getElementById("godina").value;
    let s = document.getElementById("secret").value;
    let b = document.getElementById("branch").value;

    BitbucketApi.dohvatiAccessToken(k,s,function(err,data){
        if(data && !err){
            BitbucketApi.dohvatiRepozitorije(data,g,n,b,function(err,data){
                if(data && !err){
                    KreirajFajl.kreirajListu(g.toString(),data,function(err,data){
                        if(data && !err){
                            alert(JSON.parse(data.toString()).message);
                        }
                        else{
                            alert(data.toString());
                        }
                    })
                }
            });
        }
    });
}