function pritisnutRS(ref){
	document.getElementById('formazastudenta').style.display="block";
	document.getElementById('formazanastavnika').style.display="none";
}
function pritisnutRN(ref){
	document.getElementById('formazastudenta').style.display="none";
	document.getElementById('formazanastavnika').style.display="block";
}