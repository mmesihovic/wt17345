function izvjestaj(){
    index = document.getElementById("index").value;
    spirala = document.getElementById("spirala").value;
    KreirajFajl.kreirajIzvjestaj(spirala,index,(err,data)=>{
        if(!err && data){
            filename='izvjestaj'+spirala+index;
            text=JSON.parse(data.toString()).data;
            var element = document.createElement('a');
            element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
            element.setAttribute('download', filename);

            element.style.display = 'none';
            document.body.appendChild(element);

            element.click();

            document.body.removeChild(element);
        }
    });
}
function bodovi(){
    index = document.getElementById("index").value;
    spirala = document.getElementById("spirala").value;
    KreirajFajl.kreirajBodove(spirala,index,(err,data)=>{
        if(data && !err)
        alert(JSON.parse(data.toString()).data);
    });
}