var Validacija=(function(){
var maxGrupa=7;
var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar
return{
validirajFakultetski:function validirajFakultetski(string){
	var regex = /^[\w\._]+@etf.unsa.ba/;
	if(string.match(regex)) return true;
	return false;
},
validirajIndex:function validirajIndex(broj){
	var regex = /^1[\d]{4}/;
	broj = String(broj);
	if(broj.match(regex) && broj.length == 5) return true;
	return false;
},
validirajGrupu:function validirajGrupu(grupa){
	grupa1 = String(grupa);
	var regex = /[0-9]+/;
	if(grupa1.match(regex) && grupa<=maxGrupa) return true;
	return false;
},
validirajAkGod:function validirajAkGod(akgrupa){
	var regex =  /20[0-9]{2}[\/]20[0-9]{2}/;
	if(akgrupa.match(regex)){
		var prvibroj=akgrupa.substr(0,akgrupa.indexOf('/'));
		var b = akgrupa.indexOf('/');
		var drugibroj=akgrupa.substr(b+1,akgrupa.length);
		prvibroj=Number(prvibroj);
		drugibroj=Number(drugibroj);
		var godina = (new Date()).getFullYear();
		if((trenutniSemestar==0 && prvibroj!=godina )||(trenutniSemestar==1 && drugibroj!=godina)) return false;
		if(prvibroj+1==drugibroj) return true;
		return false;
	}
	return false;
},
validirajPassword:function validirajPassword(sifra){
	var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{7,20}$/;
	if(sifra.match(regex)) return true;
	return false;
},
validirajPotvrdu:function validirajPotvrdu(potvrda1, potvrda2){
	if(potvrda1===potvrda2)return true;
	return false;
},
validirajBitbucketURL:function validirajBitbucketURL(url){
	var regex = /https:\/\/[A-Za-z0-9]+@bitbucket\.org\/[A-Za-z0-9]+\/[A-Za-z0-9]+\.git/;
	if(url.match(regex)) return true;
	return false;
},
validirajBitbucketSSH:function validirajBitbucketSSH(ssh){
	var regex = /git@bitbucket\:[A-Za-z0-9]+\/[A-Za-z0-9]+\.git/;
	if(ssh.match(regex)) return true;
	return false;
},
validirajNazivRepozitorija:function validirajNazivRepozitorija(rep, regex){
	if(!regex){
		regex = /wtProjekat1[0-9]+|wtprojekat1[0-9]+/;
		if(rep.match(regex)){
			indekskece = rep.indexOf('1');
			var indeks = validirajIndex(rep.substr(indekskece,rep.length));
			if(indeks) return true;
			return false;
		}
		return false;
		
	}
	else{
		if(rep.match(regex)) return true;
		return false;
	}
},
validirajImeiPrezime:function validirajImeiPrezime(iip){
	var regex = /^(?=.*(?:^|\s)[a-zšđčćžA-ZČĆŽŠĐ]{3,12}(?:$|\s))(?:[A-ZČŠĐĆŽ][a-zčćžšđ\-']*\s+)*[A-ZĆŽČŠĐ][a-zšđčćž\-']*$/;
	if(iip.match(regex)) return true;
	return false;
},
postaviMaxGrupa:function postaviMaxGrupa(mg){
	maxGrupa=mg;
	return true;
},
postaviTrenSemestar:function postaviTrenSemestar(semestar){
	if(semestar<0 || semestar >1) return false;
	trenutniSemestar=semestar;
	return true;
}
}
}());

function Validiraj(ref, tip, ref1){
	if(tip=='iip'){
		if(!(Validacija.validirajImeiPrezime(ref.value))) Poruke.dodajPoruku(3);
		else(Poruke.ocistiGresku(3));
	}
	if(tip=='bi'){
		if(!(Validacija.validirajIndex(ref.value))) Poruke.dodajPoruku(1);
		else(Poruke.ocistiGresku(1));
	}
	if(tip=='bg'){
		if(!(Validacija.validirajGrupu(ref.value))) Poruke.dodajPoruku(2);
		else(Poruke.ocistiGresku(2));
	}
	if(tip=='ag'){
		if(!(Validacija.validirajAkGod(ref.value))) Poruke.dodajPoruku(4);
		else(Poruke.ocistiGresku(4));
	}
	if(tip=='pass'){
		if(!(Validacija.validirajPassword(ref.value))) Poruke.dodajPoruku(5);
		else(Poruke.ocistiGresku(5));
	}
	if(tip=='potpass'){
		if(!(Validacija.validirajPassword(ref.value) && Validacija.validirajPotvrdu(ref.value, ref1.value))) Poruke.dodajPoruku(6);
		else(Poruke.ocistiGresku(6));
	}
	if(tip=='bburl'){
		if(!(Validacija.validirajBitbucketURL(ref.value))) Poruke.dodajPoruku(7);
		else(Poruke.ocistiGresku(7));
	}
	if(tip=='bbssh'){
		if(!(Validacija.validirajBitbucketSSH(ref.value))) Poruke.dodajPoruku(8);
		else(Poruke.ocistiGresku(8));
	}
	if(tip=='nazivrep'){
		if(!(Validacija.validirajNazivRepozitorija(ref.value))) Poruke.dodajPoruku(9);
		else(Poruke.ocistiGresku(9));
	}
	if(tip=='email'){
		if(!(Validacija.validirajFakultetski(ref.value))) Poruke.dodajPoruku(0);
		else(Poruke.ocistiGresku(0));
	}
	if(tip=='mbg'){
		Validacija.postaviMaxGrupa(ref.value);
	}
	if(tip=='trenutnisemestar'){
		if(!(Validacija.postaviTrenSemestar(ref.value))) Poruke.dodajPoruku(11);
		else(Poruke.ocistiGresku(11));
	}
	// REGEX NAZIV REPOZITORIJA STA KAKO???
	Poruke.postaviIdDiva("divzaispisporuke");
	Poruke.ispisiGreske();
}