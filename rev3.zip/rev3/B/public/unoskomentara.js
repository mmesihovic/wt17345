function zamjenigore(ref){
	var red=ref;
	var red1 = ref.previousElementSibling;
	
	for(var i=0; i<red.cells.length-1; i++){
		var primarni = red1.cells[i].innerHTML;
		red1.cells[i].innerHTML=red.cells[i].innerHTML;
		red.cells[i].innerHTML=primarni;
	}
}
function zamjenidolje(ref){
	var red=ref;
	var red1 = ref.nextElementSibling;
	
	for(var i=0; i<red.cells.length-1; i++){
		var primarni = red1.cells[i].innerHTML;
		red1.cells[i].innerHTML=red.cells[i].innerHTML;
		red.cells[i].innerHTML=primarni;
	}
}
function kreirajmarks(){
	let spirala = document.getElementById("spirala").value.toString();
	let index = document.getElementById("index").value.toString();
	let grupa1 = document.getElementById("grupe1").innerHTML;
	let grupa2 = document.getElementById("grupe2").innerHTML;
	let grupa3 = document.getElementById("grupe3").innerHTML;
	let grupa4 = document.getElementById("grupe4").innerHTML;
	let grupa5 = document.getElementById("grupe5").innerHTML;

	let tekstarea1 = document.getElementById("tekstarea1").value;
	let tekstarea2 = document.getElementById("tekstarea2").value;
	let tekstarea3 = document.getElementById("tekstarea3").value;
	let tekstarea4 = document.getElementById("tekstarea4").value;
	let tekstarea5 = document.getElementById("tekstarea5").value;

	let sadrzaj = [];
	sadrzaj.push({sifra_studenta: grupa1, tekst: tekstarea1, ocjena:'0'});
	sadrzaj.push({sifra_studenta: grupa2, tekst: tekstarea2, ocjena:'1'});
	sadrzaj.push({sifra_studenta: grupa3, tekst: tekstarea3, ocjena:'2'});
	sadrzaj.push({sifra_studenta: grupa4, tekst: tekstarea4, ocjena:'3'});
	sadrzaj.push({sifra_studenta: grupa5, tekst: tekstarea5, ocjena:'4'});
	uJSON1 = JSON.stringify({sadrzaj:sadrzaj});
	KreirajFajl.kreirajKomentar(spirala, index, uJSON1, (err,data)=>{
		if(data && !err){
			alert(JSON.parse(data.toString()).message);
		}
		else{
			
		}
	});
}