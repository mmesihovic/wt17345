var Poruke=(function(){
var idDivaPoruka;
var mogucePoruke=["Email adresa nije validna",
"Indeks nije validan",
"Nastavna grupa nije validna",
"Ime i prezime nije validno",
"Akademska godina nije validna",
"Password nije validan",
"Ponovljeni password nije validan ili se ne poklapa",
"BitBucket URL nije validan",
"BitBucket SSH nije validan",
"Naziv repozitorija nije validan",
"Korisnicko ime nije validno",
"Trenutni semestar nije validan"];
var porukeZaIspis=[];
return{
ispisiGreske: function ispisiGreske(){
	document.getElementById(idDivaPoruka).innerHTML=porukeZaIspis.join('<br>');
},
postaviIdDiva: function postaviIdDiva(id){
	idDivaPoruka=id;
},
dodajPoruku: function dodajPoruku(broj){
	porukeZaIspis[broj]=mogucePoruke[broj];
},
ocistiGresku: function ocistiGresku(broj){
	porukeZaIspis[broj]="";
}
}
}());