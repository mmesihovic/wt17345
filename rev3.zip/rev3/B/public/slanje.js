function login(){
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "/static/login.html", true);
    ajax.send();
    ajax.onreadystatechange = function(){
	  	if (this.readyState == 4 && this.status == 200){
	  	  	document.getElementById("prikaz").innerHTML = ajax.responseText;
	  	}
	};
}
function unoskomentara(){
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "/static/unoskomentara.html", true);
    ajax.send();
    ajax.onreadystatechange = function(){
	  	if (this.readyState == 4 && this.status == 200){
	  	  	document.getElementById("prikaz").innerHTML = ajax.responseText;

	  	}
	};
}
function statistika(){
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "/static/statistika.html", true);
    ajax.send();
    ajax.onreadystatechange = function(){
	  	if (this.readyState == 4 && this.status == 200){
	  	  	document.getElementById("prikaz").innerHTML = ajax.responseText;

	  	}
	};
}
function unosspiska(){
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "/static/unosSpiska.html", true);
    ajax.send();
    ajax.onreadystatechange = function(){
	  	if (this.readyState == 4 && this.status == 200){
	  	  	document.getElementById("prikaz").innerHTML = ajax.responseText;

	  	}
	};
}
function nastavnik(){
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "/static/nastavnik.html", true);
    ajax.send();
    ajax.onreadystatechange = function(){
	  	if (this.readyState == 4 && this.status == 200){
	  	  	document.getElementById("prikaz").innerHTML = ajax.responseText;

	  	}
	};
}
function bitbucketpozivi(){
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "/static/bitbucketPozivi.html", true);
    ajax.send();
    ajax.onreadystatechange = function(){
	  	if (this.readyState == 4 && this.status == 200){
	  	  	document.getElementById("prikaz").innerHTML = ajax.responseText;

	  	}
	};
}