function potvrdisubmit(){
    var textarea=document.getElementById("tekstarea").value;
    var spirala=document.getElementById("spirala").value;
    var regex = /^([a-z0-9]+(?:,[a-z0-9]+)*)$/g;
    var redovi = textarea.split("\n");
    var matrix = [['1']];
    for (var i=0; i<redovi.length; i++){
        matrix[i]=redovi[i].split(',');
    }
    let radili=true;
    if(textarea!=null && textarea.length>0){
        for(var i=0; i<redovi.length; i++){
            if(!(redovi[i].match(regex))){
                // ugl. nije ispravan csv
                radili=false;
            }
            else{
                var elementreda=redovi[i].split(",");
                if(elementreda.length!=6) radili=false;
            }
        }
    }

    let redkojinezadovoljavauslove=0;
    for(var i=0; i<redovi.length; i++){
        elementreda=redovi[i].split(",");
        for(var j=0; j<elementreda.length; j++){
            for(var z=j+1; z<elementreda.length; z++){
                if(elementreda[j]==elementreda[z]){
                    radili=false;
                    redkojinezadovoljavauslove=i;
                    break;
                }
            }
            if(!radili) break;
        }
        if(!radili) break;
    }
    if(radili){
    let uJSON=JSON.stringify(matrix);
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
	    if (ajax.status == 200 && ajax.readyState==4){
            error = null;
            data = ajax.responseText;
            alert("Datoteka je uspjesno kreirana");
        }
	    else{
            error = ajax.status;
            data = ajax.responseText;
        }
    }
    ajax.open("POST", "/unosspiska", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify({spirala: spirala, textarea: uJSON}));
    }
    else
    alert("U redu "+(redkojinezadovoljavauslove+1)+" je greska");
}