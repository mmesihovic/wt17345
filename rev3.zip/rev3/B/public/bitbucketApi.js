var BitbucketApi = (function(){
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){
            if(!key || !secret) fnCallback(-1,"Key ili secret nisu pravilno proslijeđeni!");
            else{
                var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.status == 200 && ajax.readyState==4){
                    data=JSON.parse(ajax.responseText).access_token;
                    error=null;
                }
                else{
                    error=ajax.status;
                    data=null;
                }
                fnCallback(error,data);
            }
            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            // moguca da je ispod KEY:SECRET i bez apostrofa
            ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+':'+secret));
            ajax.send("grant_type="+encodeURIComponent("client_credentials"));
        }
        },
        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
            if (ajax.readyState == 4 && ajax.status == 200)
            {
                let br=0;
                let p1=0;
                let p2=0;
                let preciscenalista=[];
                let lista = JSON.parse(ajax.responseText);
                lista.values.forEach(obj=>{
                    if(new Date(obj.created_on).getFullYear()===parseInt(godina) || new Date(obj.created_on).getFullYear()===(parseInt(godina)+1)){
                        p1++;
                        BitbucketApi.dohvatiBranch(token,obj.links.branches.href,branch,function(e,data){
                            p2++;
                            if(data){
                                obj.links.clone.forEach(objekat=>{
                                    if(objekat.name==="ssh"){
                                        preciscenalista[br]=objekat.href;
                                        br++;
                                    }
                                })
                            }
                            if(p1===p2)
                            fnCallback(null,preciscenalista)
                        });
                    }
                });
            }
            else if (ajax.readyState == 4)
                fnCallback(ajax.status,null);
            }
            ajax.open("GET",'https://api.bitbucket.org/2.0/repositories?role=member&q=name~"'+naziv+'"',true);
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
        },
        dohvatiBranch: function(token, url, naziv, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
            if (ajax.readyState == 4 && ajax.status == 200)
            {
                let bio=false;
                let obj=JSON.parse(ajax.responseText).values;
                obj.forEach(objekat=>{
                    if(objekat.name===naziv){
                        fnCallback(null,true);
                        bio=true;
                    }
                });
                if(!bio)
                fnCallback(null,false);
            }
            else if (ajax.readyState == 4)
                fnCallback(ajax.status,false);
            }
            ajax.open("GET",url,true);
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
        }
    }
})();
