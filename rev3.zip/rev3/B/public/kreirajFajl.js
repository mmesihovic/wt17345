var KreirajFajl=(function(){
    
    return {
        kreirajKomentar:function kreirajKomentar(spirala, index, sadrzaj, fnCallback){
            var daLiJeOk=0;
            function ssadrzaj(sadrzaj1){
                let sadrzaj2 = JSON.parse(sadrzaj1);
                var ok=0;
                let sadrzaj3 = sadrzaj2.sadrzaj;
                for(var i=0; i<sadrzaj3.length; i++){
                    if(sadrzaj3[i].sifra_studenta && sadrzaj3[i].tekst && sadrzaj3[i].ocjena){}
                    else ok=1;
                    if(ok===1) return false;
                }
                return true;
            }
            
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
	            if (ajax.status == 200  && ajax.readyState==4){
                    error = null;
                    data = ajax.responseText;
                }
	            else{
                    error = ajax.status;
                    data = ajax.responseText;
                }
                fnCallback(error,data);
            }
            if (spirala.length>0 && spirala!=null && typeof(spirala)==='string' && typeof(index)==='string' && index!=null && index.length>0
                && ssadrzaj(sadrzaj) && JSON.parse(sadrzaj).sadrzaj instanceof Array){
                    ajax.open("POST", "/komentar", true);
                    ajax.setRequestHeader("Content-Type", "application/json");
                    ajax.send(JSON.stringify({spirala: spirala, index: index, sadrzaj: sadrzaj}));
            }
            else{
                error = -1;
                data = "Neispravni parametri";
                fnCallback(error,data);
            }
        },
        kreirajListu:function kreirajListu(godina, nizRepozitorija, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
	            if (ajax.status == 200 && ajax.readyState==4){
                    error = null;
                    data = ajax.responseText;
                }
	            else{
                    error = ajax.status;
                    data = ajax.responseText;
                }
                fnCallback(error,data);
            }
            if(godina!=null && godina.length>0 && nizRepozitorija instanceof Array && nizRepozitorija.length>0)
            {
                ajax.open("POST", "/lista", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify({godina: godina, nizRepozitorija: nizRepozitorija}));
            }
            else{
                error = -1;
                data = "Neispravni parametri";
                fnCallback(error,data);
            }
        },
        kreirajIzvjestaj:function kreirajIzvjestaj(spirala,index, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
	            if (ajax.status == 200 && ajax.readyState==4){
                    error = null;
                    data = ajax.responseText;
                }
	            else{
                    error = ajax.status;
                    data = ajax.responseText;
                }
                fnCallback(error,data);
            }
            if(index!=null && index.length>0){
                ajax.open("POST", "/izvjestaj", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify({spirala: spirala, index: index}));
            }
            else{
                error = -1;
                data = "Neispravni parametri";
                fnCallback(error,data);
            }
        },
        kreirajBodove:function kreirajBodove(spirala,index, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
	            if (ajax.status == 200 && ajax.readyState==4){
                    error = null;
                    data = ajax.responseText;
                }
	            else{
                    error = ajax.status;
                    data = ajax.responseText;
                }
                fnCallback(error,data);
            }
            if(index!=null && index.length>0 && spirala!=null && spirala.length>0){
                ajax.open("POST", "/bodovi", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify({spirala: spirala, index: index}));
            }
            else{
                error = -1;
                data = "Neispravni parametri";
                fnCallback(error,data);
            }
        }        
    }
})();