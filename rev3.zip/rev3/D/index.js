var express =require('express');
var app=express();
var bodyParse = require('body-parser');
var fileS = require('fs');
app.use(express.static('public'));

app.use(bodyParse.urlencoded({extended: true}));
app.use(bodyParse.json());

app.get('/', function(request, response){
    response.sendFile(__dirname+'index.html');
});
app.post('/spisak',function(request,response){
  fileS.appendFile('spisakS' + request.body.spirala + '.json', JSON.stringify(request.body.result), function(error){
    if(error) console.log("Nije uspjeno dodan red");
    else
    response.json({message:"Uspjesno dodan red",data:null});
  })
})
app.post('/komentar',function(request,response){
  const { spirala, sadrzaj, index } = request.body

  if (!spirala || !sadrzaj || !index) { 
    response.json({message:"Podaci nisu u trazenom formatu!",data:null});
    return    
  }

  fileS.appendFile(
    'markS'+spirala + index+ '.json',
    JSON.stringify(sadrzaj),
    function() {
      response.json({message:"Uspjesno kreirana datoteka!",data:sadrzaj});
    }
  )
})
app.post('/lista', function(request, response) {
  const { godina, nizRepozitorija } = request.body

  if (!godina || !nizRepozitorija) {
    response.json({message:"Podaci nisu u trazenom formatu!",data:null});    
  }

  fileS.appendFile(
    'spisak' + godina + '.txt',
    nizRepozitorija.filter(link => link.indexOf(godina) >= 0).join("\n"),
    function () {
      response.json({message:"Uspjesno kreirana datoteka!",data:request.body.sadrzajKljuc});
    }
  )
})
app.post('/izvjestaj', function(request, response) {
  const pozicije = ['', 'A', 'B', 'C', 'D', 'E']
  const { spirala, index } = request.body

  if (!spirala || !index) {
    response.json({message:"Podaci nisu u trazenom formatu!",data:null});    
  }

  fileS.readFile('spisakS' + spirala + '.json', function (error, data) {
    const lista = JSON.parse(data)
    let komentari = []
    for (let i = 0; i < lista.length; i++) {
      const pozicija = lista[i].indexOf(index)
      if (pozicija > 0) {
        const komentariStudenta = JSON.parse(fileS.readFileSync('markS' + spirala + lista[i][0] + '.json', 'utf-8'))
        const komentarStudenta = komentariStudenta.filter(komentar => komentar.sifra_studenta === pozicije[pozicija])
        if (komentarStudenta.length > 0) {
          komentari.push(komentarStudenta[0].tekst)
        } else {
          komentari.push('')
        }
      }
    }

    fileS.appendFile(
      'izvjestajS' + spirala + index + '.txt',
      komentari.join("\n##########\n"),
      function () { response.json({success: true}) }
    )
  })
})
app.post('/bodovi', function (request, response) {
  const pozicije = ['', 'A', 'B', 'C', 'D', 'E']
  const { spirala, index } = request.body

  if (!spirala || !index) {
    response.json({message:"Podaci nisu u trazenom formatu!",data:null});    
  }

  fileS.readFile('spisakS' + spirala + '.json', function (error, data) {
    const lista = JSON.parse(data)
    let ocjene = []
    for (let i = 0; i < lista.length; i++) {
      const pozicija = lista[i].indexOf(index)
      if (pozicija > 0) {
        const ocjeneStudenta = JSON.parse(fileS.readFileSync('markS' + spirala + lista[i][0] + '.json', 'utf-8'))
        const ocjenaStudenta = ocjeneStudenta.filter(ocjena => ocjena.sifra_studenta === pozicije[pozicija])
        if (ocjenaStudenta.length > 0) {
          ocjene.push(parseInt(ocjenaStudenta[0].ocjena))
        }
      }
    }

    const avgBodovi = Math.floor(ocjene.reduce((ocjena, total) => total + ocjena, 0) / ocjene.length) + 1
    response.json({poruka: 'Student ' + index + ' je ostvario u prosjeku ' + avgBodovi + ' mjesto'})
  })
})
app.listen(3000);