var ajax=(function(){
  return{
    login:function()
      {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(){
          if (xhttp.readyState == 4 && xhttp.status == 200) {
            document.getElementById("container").innerHTML = xhttp.responseText;
         }
         if (xhttp.readyState == 4 && xhttp.status == 404)
         document.getElementById("container").innerHTML = "Greska: Nepostojeci URL";
      };
      xhttp.open("GET", "login.html", true);
      xhttp.send();
      },
      statistika:function(){
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(){
            if (xhttp.readyState == 4 && xhttp.status == 200) {
            document.getElementById("container").innerHTML = xhttp.responseText;
            }
            if (xhttp.readyState == 4 && xhttp.status == 404)
            document.getElementById("container").innerHTML = "Greska: Nepostojeci URL";
        };
        xhttp.open("GET", "statistika.html", true);
        xhttp.send(); 
    },
    komentari:function(){
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(){
            if (xhttp.readyState == 4 && xhttp.status == 200) {
            document.getElementById("container").innerHTML = xhttp.responseText;
            }
            if (xhttp.readyState == 4 && xhttp.status == 404)
            document.getElementById("container").innerHTML = "Greska: Nepostojeci URL";
        };
        xhttp.open("GET", "unoskomentara.html", true);
        xhttp.send(); 
    },
    unosSpiska:function(){
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
          if (xhttp.readyState == 4 && xhttp.status == 200) {
          document.getElementById("container").innerHTML = xhttp.responseText;
          }
          if (xhttp.readyState == 4 && xhttp.status == 404)
          document.getElementById("container").innerHTML = "Greska: Nepostojeci URL";
      };
      xhttp.open("GET", "unosSpiska.html", true);
      xhttp.send(); 
    },
    nastavnik:function(){
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
          if (xhttp.readyState == 4 && xhttp.status == 200) {
          document.getElementById("container").innerHTML = xhttp.responseText;
          }
          if (xhttp.readyState == 4 && xhttp.status == 404)
          document.getElementById("container").innerHTML = "Greska: Nepostojeci URL";
      };
      xhttp.open("GET", "nastavnik.html", true);
      xhttp.send(); 
    },
    bitbucketPozivi:function(){
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
          if (xhttp.readyState == 4 && xhttp.status == 200) {
          document.getElementById("container").innerHTML = xhttp.responseText;
          }
          if (xhttp.readyState == 4 && xhttp.status == 404)
          document.getElementById("container").innerHTML = "Greska: Nepostojeci URL";
      };
      xhttp.open("GET", "bitbucketPozivi.html", true);
      xhttp.send(); 
    }
  }
}());