var Poruke = (function() {
    var idDivaPoruka;
    var mogucePoruke = [
        "Email nije validan fakultetski email",
        "Indeks nije validan",
        "Nastavna grupa nije validna",
        "Akademska godina nije validna",
        "Password nije validan",
        "Passwordi se ne slazu",
        "Bitbucket url nije validan",
        "Bitbucket SSH nije validan",
        "Naziv repozitorija nije validan",
        "Ime i prezime nije valdino"
    ]

    var porukeZaIspis = [];

    return {
        ispisGreske : function() {
            document.getElementById(idDivaPoruka).innerHTML=porukeZaIspis.join(" <br> ");
        },
        postaviIdDiva : function(divnaziv) {
            idDivaPoruka = divnaziv;      
        },
        dodajPoruku : function(place) {
            if(!porukeZaIspis.includes(mogucePoruke[place]))
                porukeZaIspis.push(mogucePoruke[place]);
        },
        ocistiGresku : function(place) {
                porukeZaIspis.splice(porukeZaIspis.indexOf(mogucePoruke[place]),1);
        }
    }
}());