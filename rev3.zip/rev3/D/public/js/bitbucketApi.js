var BitbucketApi = (function(){
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){
            
            if(key==null || secret==null){
                fnCallback(-1,"Key ili secret nisu pravilno proslijedjeni!")
            }
            
            var ajax = new XMLHttpRequest();
            
             ajax.onreadystatechange = function() {// Anonimna funkcija
                   if (ajax.readyState == 4 && ajax.status == 200)
                       fnCallback(null,JSON.parse(ajax.responseText).access_token);
                   else if (ajax.readyState == 4)
                       fnCallback(ajax.status,null);
               }
               ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
               ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
               ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key + ':' + secret));
               ajax.send("grant_type="+encodeURIComponent("client_credentials"));
        },
        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200)
                    {
                        var rezultat = []
                        var repozitoriji = JSON.parse(ajax.responseText).values
                        repozitoriji = repozitoriji
                            .filter(repo => repo.created_on.indexOf(godina) === 0 || repo.created_on.indexOf(godina + 1) === 0)
                            .filter(repo => repo.name.indexOf(naziv) >= 0)
                        var pozivi = 0
                        
                        if (repozitoriji.length === 0) {
                            fnCallback(null, []);                                                    
                        } else {
                            for (var i = 0; i < repozitoriji.length; i++) {
                                var repo = repozitoriji[i]

                                BitbucketApi.dohvatiBranch(token, repo.links.branches.href, branch, function(error, data) {
                                    pozivi++
                                    if (data) {
                                        rezultat.push('git@bitbucket.org:' + this.repo.full_name)
                                    }
                                    if (pozivi === repozitoriji.length) {
                                        fnCallback(null, rezultat);                                    
                                    }
                                }.bind({repo: repo}))
                            }
                        }
                    }
                    else if (ajax.readyState == 4)
                        console.log(ajax.status);
                }
                ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member");
                ajax.setRequestHeader("Authorization", 'Bearer ' + token);
                ajax.send();
             
        },
        dohvatiBranch: function(token, url, naziv, fnCallback){
            if(token==null || url==null){
                fnCallback(-1,"Key ili secret nisu pravilno proslijedjeni!")
            }
            
            var ajax = new XMLHttpRequest();
            
             ajax.onreadystatechange = function() {// Anonimna funkcija
                   if (ajax.readyState == 4 && ajax.status == 200)
                   {
                    var tmp=JSON.parse(ajax.responseText).values.filter(branch => branch.name === naziv);
                    fnCallback(null, tmp.length === 1)
                   }
                   else if (ajax.readyState == 4)
                       fnCallback(ajax.status, false);
               }
               ajax.open("GET", url, true);
               ajax.setRequestHeader("Authorization", 'Bearer ' + token);
               ajax.send();
            
        }
    }
})();
