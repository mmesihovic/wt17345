function shift(element, smjer) {
    if(smjer == "up") {
        var trenutni = element.parentNode.parentNode;
        var iznad = element.parentNode.parentNode.previousElementSibling;
        if(iznad.className!="header") {
            iznad.parentNode.insertBefore(trenutni, iznad);
            const stari = trenutni.getElementsByClassName('pozicija')[0].value
            trenutni.getElementsByClassName('pozicija')[0].value = iznad.getElementsByClassName('pozicija')[0].value
            iznad.getElementsByClassName('pozicija')[0].value = stari
        }
    } else {
        var trenutni = element.parentNode.parentNode;
        var ispod = element.parentNode.parentNode.nextElementSibling;
        if(ispod!=null) {
            trenutni.parentNode.insertBefore(ispod, trenutni);
            const stari = trenutni.getElementsByClassName('pozicija')[0].value
            trenutni.getElementsByClassName('pozicija')[0].value = ispod.getElementsByClassName('pozicija')[0].value
            ispod.getElementsByClassName('pozicija')[0].value = stari
        }
    }
}