var potvrdiListu = function() {
    var key = document.getElementById('key').value
    var secret = document.getElementById('secret').value
    var godina = parseInt(document.getElementById('godina').value)
    var naziv = document.getElementById('naziv').value
    var branch = document.getElementById('branch').value
    
    BitbucketApi.dohvatiAccessToken(key, secret, function (error, data) {
        if (error) {
            console.log('Greska pri dohvatanju tokena')
            return
        }

        BitbucketApi.dohvatiRepozitorije(data, godina, naziv, branch, function (error, data) {
            KreirajFajl.kreirajListu(godina, data, function (error, data) {
                if (error) console.log('Greska pri kreiranju liste')
                else console.log('Kreirana lista')
            })     
        })
    })
}