var unosKomentara = (function() {
    var pozicije = ['A', 'B', 'C', 'D', 'E']
    var spirala = document.getElementById('unosKom_spirala').value
    var index = document.getElementById('unosKom_index').value
    var sadrzaj = []

    for (var i = 0; i < pozicije.length; i++) {
        const pozicija = document.getElementById(pozicije[i].toLowerCase() + '_pozicija').value
        const tekst = document.getElementById(pozicije[i].toLowerCase() + '_text').value
        sadrzaj.push({ sifra_studenta: pozicije[i], ocjena: pozicija, tekst: tekst })
    }

    KreirajFajl.kreirajKomentar(spirala, index, sadrzaj, function (error, data) {
        if (error) console.log('Greska pri unosu komentara')
        else console.log('Uspjesno spaseni komentari')
    })
})