var unosSpiska=(function(){
    return{
        kreirajSpisak:function(){
            var indexi=document.getElementById("indexi").value;
            var spirala=document.getElementById("spirala").value;
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
              if (xhttp.readyState == 4 && xhttp.status == 200) {
                  console.log("Uspjesno kreiran fajl");
             }
             if (xhttp.readyState == 4 && xhttp.status == 404)
             console.log("Greska pri kreiranju fajla");
          };
          xhttp.open("POST","http://localhost:3000/spisak", true);
          xhttp.setRequestHeader("Content-Type", "application/json");
          var lines=indexi.split("\n");
          var result = [];
          
          for(var i=0;i<lines.length;i++){  
                
                var currentline=lines[i].split(",");
                result.push(currentline);
          }
          console.log(result);
          var odgovor2={
              result,
              spirala
          }
          xhttp.send(JSON.stringify(odgovor2));
        }
    }
}());