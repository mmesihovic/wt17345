var Validacija = (function () {
    var maxGrupa = 7;
    var trenutniSemestar = 0;

    return {
        validirajFakultetski : function(email) {
            var parts = email.split("@");
            if(parts.length != 2 || parts[1] !== "etf.unsa.ba") return false;
            else return true;
        },
        validirajIndex : function(index) {
            if(index > 19999 || index < 10000 || isNaN(index)) return false;
            return true;
        },
        validirajGrupu : function(grupa)  {
            if(parseInt(grupa) < 1 || parseInt(grupa) > maxGrupa || isNaN(grupa)) return false;
            return true;
        },
        validirajAkGod : function(akgodina) {
            var parts = akgodina.split("/");
            if(parts.length!=2 || parseInt(parts[0])+1!=parseInt(parts[1])) return false;
            if(trenutniSemestar==0 && (parseInt((new Date()).getFullYear()))!=parseInt(parts[0]))return false;
            if(trenutniSemestar==1 && (parseInt((new Date()).getFullYear()))!=parseInt(parts[1])) return false;
            return true;
        },
        validirajPassword : function(password) {
            var regularExpression = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}$/;
            
            return regularExpression.test(password);
        },
        validirajPotvrdu : function(pass, rep) {
          

            return pass === rep;
        },
        validirajBitbucketURL : function(url) {
            var regex = /(https:\/\/)[a-zA-Z0-9-]{3,13}(@bitbucket\.org\/)[a-zA-Z0-9-]{3,13}\/(wtProjekat|wtprojekat)[1][0-9][0-9][0-9][0-9]\.git$/;

            return regex.test(url);
        }, 
        validirajBitbucketSSH : function(ssh) {
            var regex = /git@bitbucket\.org:[a-zA-Z0-9-]{3,13}\/(wtProjekat|wtprojekat)[1][0-9]{1,4}(\.git)$/;
            return regex.test(ssh);
        },
        validirajNazivRepozitorija : function(regex, string) {
            if(regex === null)
                regex = /(wtProjekat|wtprojekat)[1][0-9][0-9][0-9][0-9]$/; 
            else{
                regex="/"+regex+"$/";
            }     
            return regex.test(string);
        },
        validirajImeiPrezime : function(string) {
            var regex=/^([A-ZŠĐČĆŽ][a-zšđčćž\-' ]{2,11}){1,}$/;
            return regex.test(string);        
        },
        postaviMaxGrupa:function(broj){
            maxGrupa=broj;
        },
        postaviTrenSemestar:function(trenutni){
            if(trenutni>1)
            {
                trenutni=1;
            }
            else if(trenutni<0){
                trenutni=0
            }
            trenutniSemestar=trenutni;
            
        }
    }
}());
