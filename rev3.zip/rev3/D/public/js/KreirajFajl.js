var KreirajFajl=(function(){
    function IsJsonString(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    }
    return {
        kreirajKomentar : function(spirala, index, sadrzaj, fnCallback){

            if(IsJsonString(sadrzaj) && (spirala==null || index==null) && (!sadrzaj.hasOwnProperty('sifra_studenta') 
            || !sadrzaj.hasOwnProperty('teskt')|| !sadrzaj.hasOwnProperty('ocjena'))){
                fnCallback(-1,"Neispravni parametri");
               }

            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
              if (xhttp.readyState == 4 && xhttp.status == 200) {
                fnCallback(null,xhttp.responseText);
             }
             else if (xhttp.readyState == 4 && xhttp.status!=200){
                fnCallback(xhttp.status,xhttp.responseText);
             }
          };
          var odgovor = {
              spirala: spirala,
              index: index,
              sadrzaj: sadrzaj
          };
          xhttp.open("POST","http://localhost:3000/komentar", true);
          xhttp.setRequestHeader("Content-Type", "application/json");
          xhttp.send(JSON.stringify(odgovor));
          
        },
        kreirajListu : function(godina, nizRepozitorija, fnCallback){
            if((godina==null || nizRepozitorija.length==0)){
                fnCallback(-1,"Neispravni parametri");
                return;
               }

            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
              if (xhttp.readyState == 4 && xhttp.status == 200) {
                fnCallback(null,xhttp.responseText);
             }
             else if (xhttp.readyState == 4 && xhttp.status!=200){
                fnCallback(xhttp.status,xhttp.responseText);
             }
          };
          var odgovor = {
              godina: godina,
              nizRepozitorija: nizRepozitorija,
          };
          xhttp.open("POST","http://localhost:3000/lista", true);
          xhttp.setRequestHeader("Content-Type", "application/json");
          xhttp.send(JSON.stringify(odgovor));
        },
        kreirajIzvjestaj : function(spirala,index, fnCallback){
            if((spirala==null || index==null)){
                fnCallback(-1,"Neispravni parametri");
               }

            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
              if (xhttp.readyState == 4 && xhttp.status == 200) {
                fnCallback(null,xhttp.responseText);
             }
             else if (xhttp.readyState == 4 && xhttp.status!=200){
                fnCallback(xhttp.status,xhttp.responseText);
             }
          };
          var odgovor = {
              spirala: spirala,
              index: index,
          };
          xhttp.open("POST","http://localhost:3000/izvjestaj", true);
          xhttp.setRequestHeader("Content-Type", "application/json");
          xhttp.send(JSON.stringify(odgovor));
        },
        kreirajBodove : function(spirala,index, fnCallback){
            if((spirala==null || index==null)){
                fnCallback(-1,"Neispravni parametri");
               }

            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
              if (xhttp.readyState == 4 && xhttp.status == 200) {
                fnCallback(null,xhttp.responseText);
             }
             else if (xhttp.readyState == 4 && xhttp.status!=200){
                fnCallback(xhttp.status,xhttp.responseText);
             }
          };
          var odgovor = {
              spirala: spirala,
              index: index,
          };
          xhttp.open("POST","http://localhost:3000/bodovi", true);
          xhttp.setRequestHeader("Content-Type", "application/json");
          xhttp.send(JSON.stringify(odgovor));
        }        
    }
})();
