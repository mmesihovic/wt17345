var express = require('express');
var fs = require('fs');
var bodyParser = require('body-parser');


var app = express();

app.use(express.static('public'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.get('/', function(req,res){
    res.sendFile(__dirname + '/index.html');
}); 

app.get('/unosSpiska',function(req,res)
{   
    res.sendFile(__dirname + "/public/unosSpiska.html");
});

app.get('/login',function(req,res)
{   
    res.sendFile(__dirname + "/public/login.html");
});

app.get('/komentari',function(req,res)
{   
    res.sendFile(__dirname + "/public/unoskomentara.html");
});
app.get('/statistika',function(req,res)
{   
    res.sendFile(__dirname + "/public/statistika.html");
});
/** */
app.post("/unosSpiska/podaci", function(req, res)
{
		fs.writeFile('spisakS' + req.body.unosSpirala + '.json',JSON.stringify(require.body.unosText),function(err){
            if(err) throw err;
        });      
        /*res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
        res.end(JSON.stringify(vrijednosti));  */
});

app.listen(3000, function(){
    console.log('Server pokrenut!'); //obrisati 
});