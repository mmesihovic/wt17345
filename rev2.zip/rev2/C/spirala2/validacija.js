

var Validacija=(function(){
var maxGrupa=7;
var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar


return{
	
	validirajFakultetski: function validirajFakultetski( mail) {
		var regex = /\w+@etf.unsa.ba/;
		if ( mail.match(regex)) {
			Poruke.ocistiGresku(0);
			Poruke.ispisiGreske();
			return true;
		}
		Poruke.dodajPoruku(0);
		Poruke.ispisiGreske();
		  //document.getElementById('porukas').innerHTML="poruka";
		return false;
	},
	validirajIndex: function validirajIndex( index) {
		var regex = /1\d{4}/;
		if(index.match(regex)) {
			Poruke.ocistiGresku(1);
			Poruke.ispisiGreske();
			return true;
			
		}
		 	Poruke.dodajPoruku(1);
		Poruke.ispisiGreske();
		  //document.getElementById('porukas').innerHTML="poruka";
		  return false;
	},
	validirajGrupu: function validirajGrupu(grupa) {
		var regex = new RegExp("[1-" + maxGrupa + "]");
		if(grupa.match(regex)) {
			Poruke.ocistiGresku(2);
			Poruke.ispisiGreske();
			return true;
		}
		Poruke.dodajPoruku(2);
		Poruke.ispisiGreske();
		  //document.getElementById('porukas').innerHTML="poruka";
		return false;
	},
	validirajAkGod: function validirajAkGod(akgod) {
	
		var regex = /20\d{2}\/20\d{2}/;
		if(akgod.match(regex) ) {
			Poruke.ocistiGresku(3);
			Poruke.ispisiGreske();
			return true;
		}
		Poruke.dodajPoruku(3);
		Poruke.ispisiGreske();
		  //document.getElementById('porukas').innerHTML="poruka";
		return false;
	},
	validirajPassword: function validirajPassword( password) {
		var regex= /^(.{0,7}|.{20,}|[^0-9]*|[^A-Z]*|[^a-z]*)$/
		if(!password.match(regex)) {
			Poruke.ocistiGresku(4);
			Poruke.ispisiGreske();
			return true;
		}
		Poruke.dodajPoruku(4);
		Poruke.ispisiGreske();
		  //document.getElementById('porukas').innerHTML="poruka";
		return false;
	},
	validirajPotvrdu: function validirajPotvrdu(pass1, pass2) {
		if(pass1 == pass2) {
			Poruke.ocistiGresku(5);
			Poruke.ispisiGreske();
			return true;
		}
		 Poruke.dodajPoruku(5);
		Poruke.ispisiGreske();
		  //document.getElementById('porukas').innerHTML="poruka";
		return false;
	},
	validirajImeiPrezime: function validirajImeiPrezime(ime) {
		
		var regex = /([A-ZČĆŠĐŽ])+([a-zA-ZČĆĐŽŠžćđč\-']{2,12}\s*)*/;
		
		if(ime.match(regex)) {
			Poruke.ocistiGresku(6);
			Poruke.ispisiGreske();
			return true;
		}
		Poruke.dodajPoruku(6);
		Poruke.ispisiGreske();
		  //document.getElementById('porukas').innerHTML="poruka";
		return false;
	},
	postaviMaxGrupa: function postaviMaxGrupa(m_g) {
		maxGrupa = m_g;
	},
	postaviTrenSemestar: function postaviTrenSemestar( semestar) {
		trenutniSemestar = semestar;
	},
	validirajNazivRepozitorija: function validirajNazivRepozitorija( regex, rep) {
		var reg_index = /1\d{4}/;
		var reg = /wtprojekat1\d{4}|wtProjekat1\d{4}/;
		if(regex != null && rep.match(regex)) {
			Poruke.ocistiGresku(8);
			Poruke.ispisiGreske();
			return true;
			
		}
		else if (regex== null && rep.match(reg)) {
			Poruke.ocistiGresku(8);
			Poruke.ispisiGreske();
			return true;
		}
		else {
			Poruke.dodajPoruku(8);
		Poruke.ispisiGreske();
		  //document.getElementById('porukas').innerHTML="poruka";
			return false;
		}
	},
	validirajBitbucketSSH: function validirajBitbucketSSH( ssh ) {
		regex = /git@bitbucket.org:.+\/(wtprojekat1\d{4}|wtProjekat1\d{4})\.git/;
		if(ssh.match(regex)) {
				Poruke.ocistiGresku(9);
			Poruke.ispisiGreske();
			return true;
		}
			Poruke.dodajPoruku(9);
		Poruke.ispisiGreske();
		return false;
	},
	validirajBitbucketURL: function validirajBitbucketURL( url ) {
		regex = /https:\/\/.+@bitbucket.org\/.+\/(wtprojekat1\d{4}|wtProjekat1\d{4})\.git/;
		if(url.match(regex)) {
			Poruke.ocistiGresku(10);
			Poruke.ispisiGreske();
			return true;
		}
			Poruke.dodajPoruku(10);
		Poruke.ispisiGreske();
		return false;
	}
}
}());