document.getElementById("akgod").addEventListener("blur", myFunction1);

function myFunction1() {
   Validacija.validirajAkGod(document.getElementById("akgod").value);
}

document.getElementById("akgod2").addEventListener("blur", myFunction2);

function myFunction2() {
   Validacija.validirajAkGod(document.getElementById("akgod2").value);
}

document.getElementById("index1").addEventListener("blur", myFunction3);

function myFunction3() {
   Validacija.validirajIndex(document.getElementById("index1").value);
}

document.getElementById("imeiprezime1").addEventListener("blur", myFunction4);

function myFunction4() {
	Validacija.validirajImeiPrezime(document.getElementById("imeiprezime1").value);
}

document.getElementById("imeiprezime2").addEventListener("blur", myFunction11);

function myFunction11() {
	Validacija.validirajImeiPrezime(document.getElementById("imeiprezime2").value);
}

document.getElementById("password1").addEventListener("blur", myFunction5);

function myFunction5() {
   Validacija.validirajPassword(document.getElementById("password1").value);
}

document.getElementById("password2").addEventListener("blur", myFunction12);

function myFunction12() {
   Validacija.validirajPassword(document.getElementById("password2").value);
}

document.getElementById("potvrdapassworda1").addEventListener("blur", myFunction6);

function myFunction6() {
	Validacija.validirajPotvrdu(document.getElementById("potvrdapassworda1").value,document.getElementById("password1").value);
}
document.getElementById("potvrdapassworda2").addEventListener("blur", myFunction13);

function myFunction13() {
	Validacija.validirajPotvrdu(document.getElementById("potvrdapassworda2").value,document.getElementById("password2").value);
}

document.getElementById("emailf2").addEventListener("blur", myFunction14);

function myFunction14() {
	Validacija.validirajFakultetski(document.getElementById("emailf2").value);
}

document.getElementById("maxgrupa2").addEventListener("blur", myFunction15);

function myFunction15() {
	Validacija.postaviMaxGrupa(document.getElementById("maxgrupa2").value);
  
}
document.getElementById("brojsemestra2").addEventListener("blur", myFunction16);

function myFunction16() {
	Validacija.postaviTrenSemestar(document.getElementById("brojsemestra2").value);
}

document.getElementById("biturl").addEventListener("blur", myFunction7);

function myFunction7() {
   Validacija.validirajBitbucketURL(document.getElementById("biturl").value);
}

document.getElementById("bitssh").addEventListener("blur", myFunction9);

function myFunction9() {
   Validacija.validirajBitbucketSSH(document.getElementById("bitssh").value);
}

document.getElementById("bazivrep").addEventListener("blur", myFunction8);

function myFunction8() {
	Validacija.validirajNazivRepozitorija(null, document.getElementById("bazivrep").value);
 
}




