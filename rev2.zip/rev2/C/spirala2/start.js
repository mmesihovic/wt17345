


window.onload = function () {
  document.getElementById('forma_registracija2').style.display="none";

}



function nastavnikf() {

	 document.getElementById('forma_registracija').style.display="none";
	
	document.getElementById('forma_registracija2').style.display="block";
	Poruke.postaviIdDiva('porukan');
}	
function studentf() {
	document.getElementById('forma_registracija2').style.display="none";

	 document.getElementById('forma_registracija').style.display="block";
	Poruke.postaviIdDiva('porukn');
	
}	
