function idigore(sender ) {
	if(sender.parentNode.parentNode.getAttribute('id') == 'drugi') { 
	  var temp = document.getElementById('prvi').innerHTML;
	  document.getElementById('prvi').innerHTML = document.getElementById('drugi').innerHTML;
	  document.getElementById('drugi').innerHTML = temp;
	}
	else if(sender.parentNode.parentNode.getAttribute('id') == 'treci') { 
	  var temp = document.getElementById('drugi').innerHTML;
	  document.getElementById('drugi').innerHTML = document.getElementById('treci').innerHTML;
	  document.getElementById('treci').innerHTML = temp;
	}
	else if(sender.parentNode.parentNode.getAttribute('id') == 'cetvrti') { 
	  var temp = document.getElementById('treci').innerHTML;
	  document.getElementById('treci').innerHTML = document.getElementById('cetvrti').innerHTML;
	  document.getElementById('cetvrti').innerHTML = temp;
	}
	else if(sender.parentNode.parentNode.getAttribute('id') == 'peti') { 
	  var temp = document.getElementById('cetvrti').innerHTML;
	  document.getElementById('cetvrti').innerHTML = document.getElementById('peti').innerHTML;
	  document.getElementById('peti').innerHTML = temp;
	}
}

function ididole(sender ) {
	if(sender.parentNode.parentNode.getAttribute('id') == 'prvi') { 
	  var temp = document.getElementById('prvi').innerHTML;
	  document.getElementById('prvi').innerHTML = document.getElementById('drugi').innerHTML;
	  document.getElementById('drugi').innerHTML = temp;
	}
	else if(sender.parentNode.parentNode.getAttribute('id') == 'drugi') { 
	  var temp = document.getElementById('drugi').innerHTML;
	  document.getElementById('drugi').innerHTML = document.getElementById('treci').innerHTML;
	  document.getElementById('treci').innerHTML = temp;
	}
	else if(sender.parentNode.parentNode.getAttribute('id') == 'treci') { 
	  var temp = document.getElementById('treci').innerHTML;
	  document.getElementById('treci').innerHTML = document.getElementById('cetvrti').innerHTML;
	  document.getElementById('cetvrti').innerHTML = temp;
	}
	else if(sender.parentNode.parentNode.getAttribute('id') == 'cetvrti') { 
	  var temp = document.getElementById('cetvrti').innerHTML;
	  document.getElementById('cetvrti').innerHTML = document.getElementById('peti').innerHTML;
	  document.getElementById('peti').innerHTML = temp;
	}
}

