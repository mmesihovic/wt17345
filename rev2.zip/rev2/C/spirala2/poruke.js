var Poruke=(function(){
var idDivaPoruka = 'porukas';
var mogucePoruke=["Email koji ste napisali nije validan fakultetski email",
	"Indeks kojeg ste napisali nije validan",
	"Nastavna grupa koju ste napisali nije validna",
	"Akademska godina nije ispravna",
	"Password nije validan",
	"Passwordi se ne poklapaju",
	"Ime i prezime nije validno",
	"Grupa nije validna",
	"Naziv repozitorija nije validan",
	"ssh nije validan",
	"url nije validan" ];
	var porukeZaIspis=[];

	return{
		ispisiGreske: function ispisiGreske() {
			  document.getElementById(idDivaPoruka).innerHTML=porukeZaIspis;
		},
		postaviIdDiva: function postaviIdDiva(id) {
			idDivaPoruka = id;
		},
		dodajPoruku: function dodajPoruku(brojP) {
			if(porukeZaIspis.indexOf(mogucePoruke[brojP]) === -1) {
				porukeZaIspis.push(mogucePoruke[brojP]);
			}
		},
		ocistiGresku: function ocistiGresku(brojP) {
			for (i=0; i< porukeZaIspis.length; i++) {
				if(porukeZaIspis[i] == mogucePoruke[brojP]) {
					porukeZaIspis.splice(i,1);
				}
			}
		}
	}
}());