function funkcija()
{
	if(document.getElementById("desni").style.display === "none")
	{
		document.getElementById("desni").style.display="block";
		document.getElementById("desniProfesor").style.display="none";
	}
	else
	{
		document.getElementById("desni").style.display="none";
		document.getElementById("desniProfesor").style.display="block";
	}
}