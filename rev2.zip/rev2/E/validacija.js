
var Validacija = (function(){
	var maxGrupa = 7;
	var trenutniSemestar = 0; //0 za zimski, 1 za ljetni semestar
	return{
		validirajFakultetski: function (mail) {
			return /^[A-Za-z.-_0-9]*.\@(etf\.unsa\.ba)/.test(mail);
		},
		validirajIndex: function (ind) {
			return /^1[0-9]{4,4}$/.test(ind);
		},
		validirajGrupu: function (grupa) {
			return grupa >= 1 && grupa <= maxGrupa;
		},
		validirajAkGod: function (god) {
			if (!(/^20[0-9]{2,2}\/20[0-9]{2,2}/.test(god))) //kupi godinu ali prihvata ako je razlika veca od jedan
				return false;
			if (god[2] > god[7])
				
				return false;
			if (Number(god[3]) != Number(god[8]) - 1)
				return false;
			return true;
		},
		validirajPassword: function (pass1) {
			return /^(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])[a-zA-Z0-9!@#$%^&*]{7,20}$/.test(pass1)
		},
		validirajPotvrdu: function (pass1, pass2) {
			if (/*validirajPassword(pass1) && validirajPassword(pass2) && */pass1 == pass2)
				return true;
			else
				return false;
		},
		validirajBitbucketURL: function (url) {
			if (!(/^https::\/\/\w+@bitbucket\.org\/\w+\/\w+\.git/.test(url)))
				return false;
			username1 = '';
			pozicija = 0
			for (var i = 9, j = url.length; i < j; i++) {
			    if (url(i) != '@')
					username1 += url(i);
				else {
					pozicija = i + 15;
					break;
				}
			}
			username2 = '';
			for (var i = pozicija, j = url.length; i < j; i++) {
				if (url(i) != '/')
					username2 += url(i)
				else {
					pozicija = i + 1;
					break;
				}
			}
			repoz = '';
			for (var i = pozicija, j = url.length; i < j; i++) {
				if (url(i) != '.')
					repoz += url(i)
				else 
					break;
			}
			return validirajNazivRepozitorija(null, repoz) && validirajImeiPrezime(username1) && validirajImeiPrezime(username2);
		},
		validirajBitbucketSSH: function (ssh) {
			return /^git@bitbucket\.org\:\w+\/\w+\.git/.test(ssh);
		},
		validirajNazivRepozitorija: function (reg, naziv) {
			if (reg != null)
				if(reg==naziv)
					return true;
				else return false;
			else
				return /^wtprojekat1\d{4,4}$/.test(naziv) || /^wtProjekat1\d{4,4}$/.test(naziv);
		},
		validirajImeiPrezime: function (imePr) {
			console.log( /([A-ZŠĐČĆŽ][a-zšđčćž\'\-]{2,11}){1,2}$/.test(imePr));
		},
		postaviMaxGrupa: function (maxGr) {
			this.maxGrupa = maxGr;
		},
		postaviTrenSemestar: function (sem) {
			this.trenutniSemestar = sem;
		}
	
	}
	
}());

/*document.getElementById("imeprezime").addEventListener("blur", Validacija.validirajImeiPrezime);
document.getElementById("br_indexa").addEventListener("blur", Validacija.validirajIndex);
document.getElementById("br_grupe").addEventListener("blur", Validacija.validirajGrupu);
document.getElementById("godina").addEventListener("blur", Validacija.validirajAkGod);
document.getElementById("pssw").addEventListener("blur", Validacija.validirajPassword);
document.getElementById("ppssw").addEventListener("blur", Validacija.validirajPotvrdu);
document.getElementById("url").addEventListener("blur", Validacija.validirajBitbucketURL);
document.getElementById("ssh").addEventListener("blur", Validacija.validirajBitbucketSSH);
document.getElementById("repozitorij").addEventListener("blur", Validacija.validirajNazivRepozitorija);

document.getElementById("imeprezime1").addEventListener("blur", Validacija.validirajImeiPrezime);
document.getElementById("trenutna_godina1").addEventListener("blur", Validacija.validirajAkGod);
document.getElementById("pssw1").addEventListener("blur", Validacija.validirajPassword);
document.getElementById("ppssw1").addEventListener("blur", Validacija.validirajPotvrdu);
document.getElementById("email1").addEventListener("blur", Validacija.validirajFakultetski);
document.getElementById("trenutni_semestar1").addEventListener("blur", Validacija.postaviTrenSemestar);
document.getElementById("max_broj1").addEventListener("blur", Validacija.postaviMaxGrupa);*/