﻿function validirajBitbucketUR (url) {
    // string split("/") kreira niz stringova ciji broj clanova zavisi od broja "/" u stringu
    // ako je premalo znakova u stringu, izaci ce van opsega sa toks[index]
    //https://​ ​protokolom​ ​nakon​ ​čega​ ​slijedi username@bitbucket.org/username2/nazivRepozitorija.git
    alert("zdravo");
    document.getElementById("nebitno").value = "pozvana validacija";
    var toks = url.split("/"); // 0 - https:, 1 - , 2 - username@bitbucket.org, 3 - username2, 4 - nazivRepozitorija.git
    if (toks.length !== 5) {
        return false;

    }
    if (toks[0] !== "https:" || toks[1] !== "") return false;      // možda bi trebalo i ovdje biti toLowerCase
    var username = toks[2].split("@")[0];
    var domena = toks[2].split("@")[1];
    for (var i = 0; i < username.length; i++) {
        var slovo = username.toLowerCase()[i];
        if (!((slovo >= '0' && slovo <= '9') || (slovo >= 'a' && slovo <= 'z'))) return false;
    }
    if (domena !== "@bitbucket.org") return false;        // možda bi trebalo i ovdje biti toLowerCase
    for (i = 0; i < toks[3].length; i++) {
        slovo = toks[3].toLowerCase()[i];
        if (!((slovo >= '0' && slovo <= '9') || (slovo >= 'a' && slovo <= 'z'))) return false;   //moglo bi se fakat raditi refaktoring
    }
    if (!toks[4].endsWith(".git")) return false;
    var repo = toks[4].split(".")[0];
    alert("prošao validaciju");
    document.getElementById("nebitno").value = "prošao validaciju";
    return this.validirajNazivRepozitorija(repo);