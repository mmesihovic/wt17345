﻿var Validacija = (function () {
    var maxGrupa = 7;
    var trenutniSemestar = 0; // 0 za zimski, 1 za ljetni semestar

    return {
        validirajFakultetski: function (mail) {
            mail = mail.toLowerCase(); // da budem konzistentan
            var domena = "@etf.unsa.ba";
            return mail.endsWith(domena) && mail.length > domena.length;       

        },
        validirajIndex: function (index) {
            return /^1\d{4}$/.test(index);   
        },
        validirajGrupu: function (grupa) {
            return grupa > 0 && grupa <= maxGrupa;
        },
        validirajAkGod: function (god) {
            var godine = god.split("/");
            if (!godine[0].startsWith("20")) return false;
            if (godine[0].length !== 4) {
                return false;
            }
            var g1 = parseInt(godine[0]);
            if (Number.isInteger(g1)===false) {
                return false;
            }
            var g2 = parseInt(godine[1]);
            if (Number.isInteger(g2) === false) {
                return false;
            }
            return g2 - g1 === 1;
        },
        validirajPassword: function (pass) {
            //return /^(?=.*\d)(?=.*[a - z])(?=.*[A - Z]).{7,20}$/.test(pass);
            if (pass.length < 7 || pass.length > 20) return false;
            if (!/\d/.test(pass)) return false;
            if (!/\[a-z]/.test(pass)) return false;
            return /[A-Z]/.test(pass);
        },
        validirajPotvrdu: function (pass, conf) {
            return this.validirajPassword(pass) && pass === conf;   
        },
        validirajBitbucketURL: function (url) {
            // string split("/") kreira niz stringova ciji broj clanova zavisi od broja "/" u stringu
            // ako je premalo znakova u stringu, izaci ce van opsega sa toks[index]
            //https://​ ​protokolom​ ​nakon​ ​čega​ ​slijedi username@bitbucket.org/username2/nazivRepozitorija.git
            //document.getElementById("nebitno").value = "pozvana validacija";
            var toks = url.split("/"); // 0 - https:, 1 - , 2 - username@bitbucket.org, 3 - username2, 4 - nazivRepozitorija.git
            if (toks.length !== 5) {
                return false;

            }
            if (toks[0] !== "https:" || toks[1] !== "") return false;      // možda bi trebalo i ovdje biti toLowerCase
            var username = toks[2].split("@")[0];
            var domena = toks[2].split("@")[1];
            for (var i = 0; i < username.length; i++) {
                var slovo = username.toLowerCase()[i];
                if (!((slovo >= '0' && slovo <= '9') || (slovo >= 'a' && slovo <= 'z'))) return false;
            }
            if (domena !== "@bitbucket.org") return false;        // možda bi trebalo i ovdje biti toLowerCase
            for (i = 0; i < toks[3].length; i++) {
                slovo = toks[3].toLowerCase()[i];
                if (!((slovo >= '0' && slovo <= '9') || (slovo >= 'a' && slovo <= 'z'))) return false;   //moglo bi se fakat raditi refaktoring
            }
            if (!toks[4].endsWith(".git")) return false;
            var repo = toks[4].split(".")[0];
            //alert("prošao validaciju");
            //document.getElementById("nebitno").value = "prošao validaciju";
            return this.validirajNazivRepozitorija(repo);
        },
        validirajBitbucketSSH: function (ssh) {
            // git@bitbucket.org:korisnickoIme/nazivRepozitorija.git  
            if (ssh.split(":").length !== 2) {
                return false;
            }
            if (ssh.split(":")[0] !== "git@bitbucket.org") return false;
            var ime_repo = ssh.split(":")[1];
            var ime = ime_repo.split("/")[0];
            var repo = ime_repo.split("/")[1];
            for (var i = 0; i < ime.length; i++) {
                var slovo = ime.toLowerCase()[i];
                if (!((slovo >= '0' && slovo <= '9') || (slovo >= 'a' && slovo <= 'z'))) return false; // mogao bi se uraditi refaktoring
            }
            if (!repo.endsWith(".git")) return false;
            return (this.validirajNazivRepozitorija(repo.split(".")[0]));
        },                                        
        validirajNazivRepozitorija: function (reg, naziv) {
            if (reg === null) reg = /^wt[Pp]rojekat1\d{4}$/;
            return reg.test(naziv);
        },
        validirajImeiPrezime: function (ime) {
            //mogao bi se uraditi refaktoring metode, jer je nastala na silu - jer se regex dio i .length podudaraju, kao i dio toUpperCase
            var imena = ime.split(" ");
            for (var i = 0; i < imena.length; i++) {
                if (imena[i] === "-" &&i>0) continue;
                if (imena[i].length < 3 || imena[i].length > 12 && imena[i] !== '-' && imena[i] !== "'" && imena[i] !== ' ') return false;
                if (isUpperCase(imena[i][0])===false) return false;
                // /^[A-ZČĆŠĐŽ]{1}[\a-zčćšđž\-']{2,11}$/.test(imena[i]);
                if (imena[i].length > 1) {
                    if (/^[A-ZČĆŠĐŽ]{1}[\a-zčćšđž\-']{2,11}$/i.test(imena[i]) === false) {
                        return false;
                    } 
                }
            }
            return true;
        },
        postaviMaxGrupa: function (broj) {
            if (broj > 0) maxGrupa = broj;
        },
        postaviTrenSemestar: function (broj) {
            if (broj === 0 || broj === 1) trenutniSemestar = broj;
        }
    };
}());
function isUpperCase(myString) {
    return (myString === myString.toUpperCase());
} 

function dugmeRegistracijaNastavnika() {
    alert("Nije implementirana");

}
function dugmeRegistracijaStudenta() {
    alert("Nije implementirana");

}