﻿var Poruke = (function () {
    var idDivaPoruka;
    var mogucePoruke = ["Fakultetski email nije validan", "Indeks kojeg ste unijeli nije validan", "Grupa nije validna", "Akademska godina nije validna", "Unesena šifra nije valdina", "Unesena šifra nije valdina jer niste unijeli 2x validnu šifru", "Bitbucket URL nije validan", "Bitbucket SSH nije validan", "Naziv repozitorija nije validan", "Ime ili prezime koje je uneseno nije validno"];
    var porukeZaIspis = [];

    return {
        ispisiGreske: function () {
            document.getElementById(idDivaPoruka).innerHTML = porukeZaIspis.join("! <br>");
        },
        postaviIdDiva: function (id) {
            if (id !== null && id.length > 0) idDivaPoruka = id;
        },
        dodajPoruku: function (broj) {
            var postoji = false;
            if (broj > 0 && broj < mogucePoruke.length) {
                for (var i = 0; i < porukeZaIspis.length; i++) {
                    if (porukeZaIspis[i] === mogucePoruke[broj]) {
                        postoji = true;
                        break;
                    }
                }
                if (!postoji) porukeZaIspis.push(mogucePoruke[broj]);
            }
        },
        ocistiGresku: function (broj) {
            if (broj > 0 && broj < mogucePoruke.length) {
                for (var i = 0; i < porukeZaIspis.length; i++) {
                    if (porukeZaIspis[i] === mogucePoruke[broj]) {
                        porukeZaIspis.splice(i, 1);
                        //break;
                    }
                }
            }
        }
    }
}());