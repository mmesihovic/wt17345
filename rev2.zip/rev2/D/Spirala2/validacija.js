 var Validacija = (function() {
 	var maxGrupa = 7;
 	var trenutniSemestar = 1; //0 zimski, 1 ljetni
 	var trenutnaGodina = 17; 
 	var reg = null;
 	return {
 		validirajFakultetski: function(email) {
 			var regex = /\w+\@\etf.unsa.ba$/ig
 			if(!regex.test(email)) {
 				Poruke.dodajPoruku(0);
 			} else {
 				Poruke.ocistiGresku(0);
 			}
 			return regex.test(email);
 		},
 		validirajIndex: function(indeks) {
 			var regex =  /^1\d{4}$/ig
 			if(!regex.test(indeks)) {
 				Poruke.dodajPoruku(1);
 			} else {
 				Poruke.ocistiGresku(1);
 			}
 			return regex.test(indeks);
 		} ,
 		validirajGrupu: function(grupa) {
 			var regex = /^[1-7]$/ig
 			if(!regex.test(grupa)) {
 				Poruke.dodajPoruku(2);
 			}else {
 				Poruke.ocistiGresku(2);
 			}
 			return regex.test(grupa)
 		},
 		validirajAkGod: function(akaGodina) {
 			if(trenutniSemestar == 0) {
 				var patt = new RegExp("20"+ trenutnaGodina.toString() + "[/]20" + (Number(trenutnaGodina) + 1).toString());
 				return patt.test(akaGodina);
 			} 
 			var patt = new RegExp("20"+ (Number(trenutnaGodina) - 1).toString() + "[/]20" + Number(trenutnaGodina).toString());
 			if(!patt.test(akaGodina)) {
 				Poruke.dodajPoruku(3);
 			} else {
 				Poruke.ocistiGresku(3);
 			}
			return patt.test(akaGodina);
 		},
 		validirajPassword: function(password) {
 			var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}$/ig
 			if(!regex.test(password)) {
 				Poruke.dodajPoruku(4);
 			} else {
 				Poruke.ocistiGresku(4);
 			}
 			return regex.test(password); 			
 		},
 		validirajPotvrdu: function(pw, pwPotvrda) {
 			if(Validacija.validirajPassword(pw)) {
 				if(pw == pwPotvrda) 
 					Poruke.ocistiGresku(5);	
 					return true;
 			} else {
 				Poruke.dodajPoruku(5)
 			}
 			return false;
 		},
 		validirajBitbucketURL: function(bitbucketURL) {
 			var regex = /^https:[/][/](\w|[_-])+@bitbucket.org[/](\w|[_-])+[/]wt(p|P)rojekat1\d{4}.git$/ig
 			if(!regex.test(bitbucketURL)) {
 				Poruke.dodajPoruku(6);
 			}else {
 				Poruke.ocistiGresku(6);
 			}
 			return regex.test(bitbucketURL);
 		},
 		validirajBitbucketSSH: function(sshAdresa) {
 			var regex = /^git@bitbucket.org[:](\w|[_-])+[/]wt(p|P)rojekat1\d{4}.git$/ig
 			if(!regex.test(sshAdresa)) {
 				Poruke.dodajPoruku(7);
 			} else {
 				Poruke.ocistiGresku(7);
 			}
 			return regex.test(sshAdresa);

 		},
 		validirajNazivRepozitorija: function(naziv, regex) {
 			var regex = /^wt(p|P)rojekat1\d{4}$/ig
 			if(reg != null) {
 				regex = new RegExp(reg);
 			}
 			if(!regex.test(naziv)) {
 				Poruke.dodajPoruku(8);
 			} else {
 				Poruke.ocistiGresku(8);
 			}
 			return regex.test(naziv);
 		},
 		validirajImeiPrezime: function(ime) {
 			var patt = new RegExp("(^[A-ZČĆŽŠĐ]([A-Za-zČĆŽŠĐčćžšđ]|[-]|[']){2,12}\[A-ZČĆŽŠĐ]([A-Za-zČĆŽŠĐčćžšđ]|[-]|['])*)|(^[A-ZČĆŽŠĐ]([A-Za-zČĆŽŠĐčćžšđ]|[-]|['])*\[A-ZČĆŽŠĐ]([A-Za-zČĆŽŠĐčćžšđ]|[-]|[']){2,12})");
 			if(!patt.test(ime)) {
 				Poruke.dodajPoruku(9);
 			} else {
 				Poruke.ocistiGresku(9);
 			}
 			return patt.test(ime);
 		}
 	}
 }());

function dodajRegex() {
	Validacija.regex = document.getElementById('regex').value;
}
