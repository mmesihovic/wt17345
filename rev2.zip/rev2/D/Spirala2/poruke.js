var Poruke=(function(){
	var idDivaPoruka = null;
	var mogucePoruke = ["Email koji ste napisali nije validan fakultetski email", "Indeks kojeg ste napisali nije validan",
	"Nastavna grupa koju ste napisali nije validna", "Akademska godinu koju ste napisali nije validna", "Password kojeg ste napisali nije validan",
	"Passwordi se ne poklapaju","Bitbucket URL kojeg ste napisali nije validan", "SSH adresa koju ste napisali nije validna",
	"Naziv repozitorija kojeg ste napisali nije validan", "Ime i prezime koje ste napisali nisu validni"];
	var porukeZaIspis=["", "", "", "", "", "", "", "", "", ""];

	return{
		ispisiGreske: function() {
			var foo = document.getElementById(idDivaPoruka);
			while (foo.firstChild) foo.removeChild(foo.firstChild);
			for (var i = porukeZaIspis.length - 1; i >= 0; i--) {
					if(porukeZaIspis[i] !="") {
					var p = document.createElement("p")
					p.appendChild(document.createTextNode(porukeZaIspis[i]));
					document.getElementById(idDivaPoruka).appendChild(p);
				}
			}
		},
		postaviIdDiva: function(idDiva) {
			if(idDiva == idDivaPoruka) {
				return;
			} else {
				idDivaPoruka = idDiva;
			}
		},
		dodajPoruku: function(brojPoruke) {
			porukeZaIspis.splice(brojPoruke, 1,mogucePoruke[brojPoruke]);
			Poruke.ispisiGreske();
		},
		ocistiGresku: function(brojPoruke) {
			porukeZaIspis.splice(brojPoruke, 1, "");
			Poruke.ispisiGreske();
		}
	}
}());

