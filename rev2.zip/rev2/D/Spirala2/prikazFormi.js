window.onload = function (){
	var nastavnik = document.getElementById("registracijaFormaNastavnika");
	nastavnik.style.display = 'none';
	var student = document.getElementById("registracijaFormaStudent");
	student.style.display = 'none';

}

function onclickNastavnik() {
	 var nastavnik = document.getElementById("registracijaFormaNastavnika");
	 nastavnik.style.display = 'block';
	 var student = document.getElementById("registracijaFormaStudent");
	student.style.display = 'none';
}

function onclickStudent() {
	 var student = document.getElementById("registracijaFormaStudent");
	 student.style.display = 'block';
	 var nastavnik = document.getElementById("registracijaFormaNastavnika");
	nastavnik.style.display = 'none';
}
