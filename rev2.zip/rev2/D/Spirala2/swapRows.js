function getRowIndex( el ) {
    while( (el = el.parentNode) && el.nodeName.toLowerCase() !== 'tr' );

    if( el ) 
        return el.rowIndex;
}

function swapRowUp( button ) {
    var idRow = getRowIndex( button );
    if(idRow == 1) {
		return;
	} else {
		var table = document.getElementById("t");
        table.rows[1].parentNode.insertBefore(table.rows[idRow],table.rows[idRow-1]);
        document.getElementById(idRow.toString()).id = (idRow-1).toString();
        document.getElementById((idRow-1).toString()).id = idRow.toString();
	}
}
function swapRowDown( button ) {
    var idRow = getRowIndex( button );
	if(idRow == 5) {
		return;
	} else {
		var table = document.getElementById("t");
        table.rows[1].parentNode.insertBefore(table.rows[idRow+1],table.rows[idRow]);
        document.getElementById(idRow.toString()).id = (idRow + 1).toString();
        document.getElementById((idRow+1).toString()).id = idRow.toString();
	}
}