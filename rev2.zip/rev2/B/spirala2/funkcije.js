function button_nastavnik()
{
	document.getElementById("row-3").style.display="none";
	document.getElementById("row-2").style.display="block";
	document.getElementById("ispis").style.display="none";
	Poruke.porukeZaIspis = [];
	document.getElementById("imeNas").focus();
}

function button_student()
{
	document.getElementById("row-2").style.display="none";
	document.getElementById("row-3").style.display="block";
	document.getElementById("ispis").style.display="none";
	Poruke.porukeZaIspis = [];
	document.getElementById("studIme").focus();
}

function svidja(broj)
{
	var tabela,red;

	if(broj == 1)
		return;

	tabela = document.getElementById("tabelaKomentari");	
	red = tabela.getElementsByTagName("TR");

	red[broj].parentNode.insertBefore(red[broj],red[broj-1]);
}

function ne_svidja(broj)
{
	var tabela,red;
	tabela = document.getElementById("tabelaKomentari");
	red = tabela.getElementsByTagName("TR");	

	if(broj == red.length)
		return;

	red[broj].parentNode.insertBefore(red[broj+1],red[broj]);
}

function validiraj(funkcija,indeks_poruke,ime)
{
	if(!funkcija)
		{	
			Poruke.dodajPoruku(indeks_poruke);	
			document.getElementById(ime).focus();
		}
	else
		Poruke.ocistiGresku(indeks_poruke);

	Poruke.ispisiGreske(); //provjeriti poziv ove f-je
}